"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all2) => {
  for (var name in all2)
    __defProp(target, name, { get: all2[name], enumerable: true });
};
var __copyProps = (to, from2, except, desc) => {
  if (from2 && typeof from2 === "object" || typeof from2 === "function") {
    for (let key of __getOwnPropNames(from2))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from2[key], enumerable: !(desc = __getOwnPropDesc(from2, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

var plugin_exports = {};
__export(plugin_exports, {
  default: () => RealtimeLab
});
module.exports = __toCommonJS(plugin_exports);

var K = new Uint32Array([1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]);
var r = (v, n) => v >>> n | v << 32 - n;
var Sha256 = class {
  constructor() {
    this.h = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
    this.block = new Uint8Array(64);
    this.w = new Uint32Array(64);
    this.used = 0;
    this.length = 0;
    this.done = false;
  }
  compress() {
    const w = this.w, b = this.block;
    for (let i = 0; i < 16; i++) w[i] = b[i * 4] << 24 | b[i * 4 + 1] << 16 | b[i * 4 + 2] << 8 | b[i * 4 + 3];
    for (let i = 16; i < 64; i++) {
      const x = w[i - 15], y = w[i - 2];
      w[i] = w[i - 16] + (r(x, 7) ^ r(x, 18) ^ x >>> 3) + w[i - 7] + (r(y, 17) ^ r(y, 19) ^ y >>> 10) >>> 0;
    }
    let [a, c, d, e, f, g, h, j] = this.h;
    for (let i = 0; i < 64; i++) {
      const t = j + (r(f, 6) ^ r(f, 11) ^ r(f, 25)) + (f & g ^ ~f & h) + K[i] + w[i] >>> 0, u = (r(a, 2) ^ r(a, 13) ^ r(a, 22)) + (a & c ^ a & d ^ c & d) >>> 0;
      j = h;
      h = g;
      g = f;
      f = e + t >>> 0;
      e = d;
      d = c;
      c = a;
      a = t + u >>> 0;
    }
    const v = [a, c, d, e, f, g, h, j];
    for (let i = 0; i < 8; i++) this.h[i] = this.h[i] + v[i] >>> 0;
  }
  update(bytes) {
    if (this.done) throw Error("Hash already finished");
    this.length += bytes.byteLength;
    for (let p = 0; p < bytes.length; ) {
      const n = Math.min(64 - this.used, bytes.length - p);
      this.block.set(bytes.subarray(p, p + n), this.used);
      this.used += n;
      p += n;
      if (this.used === 64) {
        this.compress();
        this.used = 0;
      }
    }
    return this;
  }
  hex() {
    if (this.done) throw Error("Hash already finished");
    const n = this.length;
    this.update(new Uint8Array([128]));
    while (this.used !== 56) this.update(new Uint8Array([0]));
    const bits = n * 8, tail = new Uint8Array(8), v = new DataView(tail.buffer);
    v.setUint32(0, Math.floor(bits / 4294967296));
    v.setUint32(4, bits >>> 0);
    this.update(tail);
    this.done = true;
    return Array.from(this.h, (v2) => v2.toString(16).padStart(8, "0")).join("");
  }
};
var CHUNK_BYTES = 32 * 1024;
async function hashSource(source, signal) {
  const h = new Sha256();
  for (let p = 0; p < source.size; p += CHUNK_BYTES) {
    signal?.throwIfAborted();
    const n = Math.min(CHUNK_BYTES, source.size - p), bytes = await source.read(p, n);
    if (!(bytes instanceof Uint8Array) || bytes.length !== n) throw Error("Source changed or short read");
    h.update(bytes);
  }
  return h.hex();
}

var SMALL_BATCH_CAPABILITY = "small-blob-batch-v1";
var BATCH_COUNT = 16;
var BATCH_BYTES = 256 * 1024;
function batchRefs(refs) {
  if (!Array.isArray(refs) || !refs.length || refs.length > BATCH_COUNT) throw Error("Invalid batch count");
  let size2 = 0;
  const seen = /* @__PURE__ */ new Set();
  for (const r2 of refs) {
    if (!r2 || !/^[a-f0-9]{64}$/.test(r2.hash) || !Number.isSafeInteger(r2.size) || r2.size < 0 || r2.size > CHUNK_BYTES || seen.has(r2.hash)) throw Error("Invalid batch reference");
    seen.add(r2.hash);
    size2 += r2.size;
  }
  if (size2 > BATCH_BYTES) throw Error("Batch exceeds byte limit");
  return size2;
}
async function verifyBatch(refs, bytes, signal) {
  if (bytes.length !== batchRefs(refs)) throw Error("Batch response length mismatch");
  const result = /* @__PURE__ */ new Map();
  let offset = 0;
  for (const ref of refs) {
    signal?.throwIfAborted();
    const data = bytes.subarray(offset, offset + ref.size);
    offset += ref.size;
    if (await hashSource({ size: data.length, read: async (p, n) => data.subarray(p, p + n) }, signal) !== ref.hash) throw Error("Batch hash mismatch");
    result.set(ref.hash, data);
  }
  return result;
}
var SmallBlobPipeline = class {
  /** @param {any[]} refs @param {Function} fetchBatch @param {{canRun?:()=>boolean}} options */
  constructor(refs, fetchBatch, { canRun = () => true } = {}) {
    this.fetchBatch = fetchBatch;
    this.canRun = canRun;
    this.groups = [];
    this.indexByHash = /* @__PURE__ */ new Map();
    this.index = -1;
    this.closed = false;
    const seen = /* @__PURE__ */ new Set();
    let group = [], size2 = 0;
    for (const r2 of refs) {
      if (r2.size > CHUNK_BYTES || seen.has(r2.hash)) continue;
      seen.add(r2.hash);
      if (group.length && (group.length >= BATCH_COUNT || size2 + r2.size > BATCH_BYTES)) {
        this.groups.push(group);
        group = [];
        size2 = 0;
      }
      this.indexByHash.set(r2.hash, this.groups.length);
      group.push(r2);
      size2 += r2.size;
    }
    if (group.length) this.groups.push(group);
  }
  start(index) {
    if (this.closed || !this.canRun() || index >= this.groups.length) return;
    this.nextIndex = index;
    this.next = Promise.resolve().then(() => this.fetchBatch(this.groups[index])).then((value) => ({ value }), (error) => ({ error }));
  }
  async idle() {
    if (this.next) await this.next;
  }
  async take(ref) {
    if (this.closed || !this.canRun()) return null;
    const index = this.indexByHash.get(ref.hash);
    if (index === void 0 || index < this.index) return null;
    if (index !== this.index) {
      if (this.next && this.nextIndex !== index) {
        await this.next;
        this.next = null;
      }
      if (!this.next) this.start(index);
      if (!this.next) return null;
      this.current = await this.next;
      this.next = null;
      this.index = index;
      this.start(index + 1);
    }
    if (this.current.error) throw this.current.error;
    return this.current.value.get(ref.hash) || null;
  }
  async close() {
    this.closed = true;
    await this.idle();
    this.next = null;
    this.current = null;
  }
};

var PERFORMANCE_CAPABILITY = "device-performance-v1";
var PERFORMANCE_KINDS = ["network", "cache", "vault", "config"];
var empty = () => ({ count: 0, ms: 0, maxMs: 0, bytes: 0, errors: 0, wallMs: 0 });
var PerformanceCounters = class {
  constructor({ now = () => performance.now() } = {}) {
    this.now = now;
    this.started = now();
    this.active = Object.fromEntries(PERFORMANCE_KINDS.map((k) => [k, { count: 0, start: 0 }]));
    this.buckets = Object.fromEntries(PERFORMANCE_KINDS.map((k) => [k, empty()]));
  }
  add(kind, ms, bytes = 0, error = false) {
    const b = this.buckets[kind];
    if (!b) return;
    b.count++;
    b.ms += Math.max(0, Math.round(ms));
    b.maxMs = Math.max(b.maxMs, Math.max(0, Math.round(ms)));
    b.bytes += Math.max(0, bytes);
    if (error) b.errors++;
  }
  record(kind, ms, bytes = 0, error = false) {
    this.add(kind, ms, bytes, error);
    if (this.buckets[kind]) this.buckets[kind].wallMs += Math.max(0, Math.round(ms));
  }
  begin(kind) {
    const t = this.now(), a = this.active[kind];
    if (!a) return () => {
    };
    if (a.count++ === 0) a.start = t;
    let done = false;
    return (bytes = 0, error = false) => {
      if (done) return;
      done = true;
      const now = this.now();
      this.add(kind, now - t, bytes, error);
      if (--a.count === 0) this.buckets[kind].wallMs += Math.max(0, Math.round(now - a.start));
    };
  }
  async measure(kind, fn) {
    const done = this.begin(kind);
    let failed = false;
    try {
      return await fn();
    } catch (e) {
      failed = true;
      throw e;
    } finally {
      done(0, failed);
    }
  }
  snapshot() {
    return { elapsedMs: Math.min(1e12, Math.max(0, Math.round(this.now() - this.started))), ...Object.fromEntries(PERFORMANCE_KINDS.map((k) => [k, { ...this.buckets[k], wallMs: this.buckets[k].wallMs + (this.active[k].count ? Math.max(0, Math.round(this.now() - this.active[k].start)) : 0) }])) };
  }
};

var create = () => /* @__PURE__ */ new Map();
var copy = (m) => {
  const r2 = create();
  m.forEach((v, k) => {
    r2.set(k, v);
  });
  return r2;
};
var setIfUndefined = (map2, key, createT) => {
  let set = map2.get(key);
  if (set === void 0) {
    map2.set(key, set = createT());
  }
  return set;
};
var map = (m, f) => {
  const res = [];
  for (const [key, value] of m) {
    res.push(f(value, key));
  }
  return res;
};
var any = (m, f) => {
  for (const [key, value] of m) {
    if (f(value, key)) {
      return true;
    }
  }
  return false;
};

var create2 = () => /* @__PURE__ */ new Set();

var last = (arr) => arr[arr.length - 1];
var appendTo = (dest, src) => {
  for (let i = 0; i < src.length; i++) {
    dest.push(src[i]);
  }
};
var from = Array.from;
var every = (arr, f) => {
  for (let i = 0; i < arr.length; i++) {
    if (!f(arr[i], i, arr)) {
      return false;
    }
  }
  return true;
};
var some = (arr, f) => {
  for (let i = 0; i < arr.length; i++) {
    if (f(arr[i], i, arr)) {
      return true;
    }
  }
  return false;
};
var unfold = (len, f) => {
  const array = new Array(len);
  for (let i = 0; i < len; i++) {
    array[i] = f(i, array);
  }
  return array;
};
var isArray = Array.isArray;

var ObservableV2 = class {
  constructor() {
    this._observers = create();
  }
  /**
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name
   * @param {EVENTS[NAME]} f
   */
  on(name, f) {
    setIfUndefined(
      this._observers,
      /** @type {string} */
      name,
      create2
    ).add(f);
    return f;
  }
  /**
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name
   * @param {EVENTS[NAME]} f
   */
  once(name, f) {
    const _f = (...args2) => {
      this.off(
        name,
        /** @type {any} */
        _f
      );
      f(...args2);
    };
    this.on(
      name,
      /** @type {any} */
      _f
    );
  }
  /**
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name
   * @param {EVENTS[NAME]} f
   */
  off(name, f) {
    const observers = this._observers.get(name);
    if (observers !== void 0) {
      observers.delete(f);
      if (observers.size === 0) {
        this._observers.delete(name);
      }
    }
  }
  /**
   * Emit a named event. All registered event listeners that listen to the
   * specified name will receive the event.
   *
   * @todo This should catch exceptions
   *
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name The event name.
   * @param {Parameters<EVENTS[NAME]>} args The arguments that are applied to the event listener.
   */
  emit(name, args2) {
    return from((this._observers.get(name) || create()).values()).forEach((f) => f(...args2));
  }
  destroy() {
    this._observers = create();
  }
};

var floor = Math.floor;
var abs = Math.abs;
var min = (a, b) => a < b ? a : b;
var max = (a, b) => a > b ? a : b;
var isNaN = Number.isNaN;
var isNegativeZero = (n) => n !== 0 ? n < 0 : 1 / n < 0;

var BIT1 = 1;
var BIT2 = 2;
var BIT3 = 4;
var BIT4 = 8;
var BIT6 = 32;
var BIT7 = 64;
var BIT8 = 128;
var BIT18 = 1 << 17;
var BIT19 = 1 << 18;
var BIT20 = 1 << 19;
var BIT21 = 1 << 20;
var BIT22 = 1 << 21;
var BIT23 = 1 << 22;
var BIT24 = 1 << 23;
var BIT25 = 1 << 24;
var BIT26 = 1 << 25;
var BIT27 = 1 << 26;
var BIT28 = 1 << 27;
var BIT29 = 1 << 28;
var BIT30 = 1 << 29;
var BIT31 = 1 << 30;
var BIT32 = 1 << 31;
var BITS5 = 31;
var BITS6 = 63;
var BITS7 = 127;
var BITS17 = BIT18 - 1;
var BITS18 = BIT19 - 1;
var BITS19 = BIT20 - 1;
var BITS20 = BIT21 - 1;
var BITS21 = BIT22 - 1;
var BITS22 = BIT23 - 1;
var BITS23 = BIT24 - 1;
var BITS24 = BIT25 - 1;
var BITS25 = BIT26 - 1;
var BITS26 = BIT27 - 1;
var BITS27 = BIT28 - 1;
var BITS28 = BIT29 - 1;
var BITS29 = BIT30 - 1;
var BITS30 = BIT31 - 1;
var BITS31 = 2147483647;

var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER;
var MIN_SAFE_INTEGER = Number.MIN_SAFE_INTEGER;
var LOWEST_INT32 = 1 << 31;
var isInteger = Number.isInteger || ((num) => typeof num === "number" && isFinite(num) && floor(num) === num);
var isNaN2 = Number.isNaN;
var parseInt = Number.parseInt;

var fromCharCode = String.fromCharCode;
var fromCodePoint = String.fromCodePoint;
var MAX_UTF16_CHARACTER = fromCharCode(65535);
var toLowerCase = (s) => s.toLowerCase();
var trimLeftRegex = /^\s*/g;
var trimLeft = (s) => s.replace(trimLeftRegex, "");
var fromCamelCaseRegex = /([A-Z])/g;
var fromCamelCase = (s, separator) => trimLeft(s.replace(fromCamelCaseRegex, (match2) => `${separator}${toLowerCase(match2)}`));
var _encodeUtf8Polyfill = (str) => {
  const encodedString = unescape(encodeURIComponent(str));
  const len = encodedString.length;
  const buf = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    buf[i] = /** @type {number} */
    encodedString.codePointAt(i);
  }
  return buf;
};
var utf8TextEncoder = (
  /** @type {TextEncoder} */
  typeof TextEncoder !== "undefined" ? new TextEncoder() : null
);
var _encodeUtf8Native = (str) => utf8TextEncoder.encode(str);
var encodeUtf8 = utf8TextEncoder ? _encodeUtf8Native : _encodeUtf8Polyfill;
var utf8TextDecoder = typeof TextDecoder === "undefined" ? null : new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
if (utf8TextDecoder && utf8TextDecoder.decode(new Uint8Array()).length === 1) {
  utf8TextDecoder = null;
}
var repeat = (source, n) => unfold(n, () => source).join("");

var Encoder = class {
  constructor() {
    this.cpos = 0;
    this.cbuf = new Uint8Array(100);
    this.bufs = [];
  }
};
var createEncoder = () => new Encoder();
var length = (encoder) => {
  let len = encoder.cpos;
  for (let i = 0; i < encoder.bufs.length; i++) {
    len += encoder.bufs[i].length;
  }
  return len;
};
var toUint8Array = (encoder) => {
  const uint8arr = new Uint8Array(length(encoder));
  let curPos = 0;
  for (let i = 0; i < encoder.bufs.length; i++) {
    const d = encoder.bufs[i];
    uint8arr.set(d, curPos);
    curPos += d.length;
  }
  uint8arr.set(new Uint8Array(encoder.cbuf.buffer, 0, encoder.cpos), curPos);
  return uint8arr;
};
var verifyLen = (encoder, len) => {
  const bufferLen = encoder.cbuf.length;
  if (bufferLen - encoder.cpos < len) {
    encoder.bufs.push(new Uint8Array(encoder.cbuf.buffer, 0, encoder.cpos));
    encoder.cbuf = new Uint8Array(max(bufferLen, len) * 2);
    encoder.cpos = 0;
  }
};
var write = (encoder, num) => {
  const bufferLen = encoder.cbuf.length;
  if (encoder.cpos === bufferLen) {
    encoder.bufs.push(encoder.cbuf);
    encoder.cbuf = new Uint8Array(bufferLen * 2);
    encoder.cpos = 0;
  }
  encoder.cbuf[encoder.cpos++] = num;
};
var writeUint8 = write;
var writeVarUint = (encoder, num) => {
  while (num > BITS7) {
    write(encoder, BIT8 | BITS7 & num);
    num = floor(num / 128);
  }
  write(encoder, BITS7 & num);
};
var writeVarInt = (encoder, num) => {
  const isNegative = isNegativeZero(num);
  if (isNegative) {
    num = -num;
  }
  write(encoder, (num > BITS6 ? BIT8 : 0) | (isNegative ? BIT7 : 0) | BITS6 & num);
  num = floor(num / 64);
  while (num > 0) {
    write(encoder, (num > BITS7 ? BIT8 : 0) | BITS7 & num);
    num = floor(num / 128);
  }
};
var _strBuffer = new Uint8Array(3e4);
var _maxStrBSize = _strBuffer.length / 3;
var _writeVarStringNative = (encoder, str) => {
  if (str.length < _maxStrBSize) {
    const written = utf8TextEncoder.encodeInto(str, _strBuffer).written || 0;
    writeVarUint(encoder, written);
    for (let i = 0; i < written; i++) {
      write(encoder, _strBuffer[i]);
    }
  } else {
    writeVarUint8Array(encoder, encodeUtf8(str));
  }
};
var _writeVarStringPolyfill = (encoder, str) => {
  const encodedString = unescape(encodeURIComponent(str));
  const len = encodedString.length;
  writeVarUint(encoder, len);
  for (let i = 0; i < len; i++) {
    write(
      encoder,
      /** @type {number} */
      encodedString.codePointAt(i)
    );
  }
};
var writeVarString = utf8TextEncoder && /** @type {any} */
utf8TextEncoder.encodeInto ? _writeVarStringNative : _writeVarStringPolyfill;
var writeUint8Array = (encoder, uint8Array) => {
  const bufferLen = encoder.cbuf.length;
  const cpos = encoder.cpos;
  const leftCopyLen = min(bufferLen - cpos, uint8Array.length);
  const rightCopyLen = uint8Array.length - leftCopyLen;
  encoder.cbuf.set(uint8Array.subarray(0, leftCopyLen), cpos);
  encoder.cpos += leftCopyLen;
  if (rightCopyLen > 0) {
    encoder.bufs.push(encoder.cbuf);
    encoder.cbuf = new Uint8Array(max(bufferLen * 2, rightCopyLen));
    encoder.cbuf.set(uint8Array.subarray(leftCopyLen));
    encoder.cpos = rightCopyLen;
  }
};
var writeVarUint8Array = (encoder, uint8Array) => {
  writeVarUint(encoder, uint8Array.byteLength);
  writeUint8Array(encoder, uint8Array);
};
var writeOnDataView = (encoder, len) => {
  verifyLen(encoder, len);
  const dview = new DataView(encoder.cbuf.buffer, encoder.cpos, len);
  encoder.cpos += len;
  return dview;
};
var writeFloat32 = (encoder, num) => writeOnDataView(encoder, 4).setFloat32(0, num, false);
var writeFloat64 = (encoder, num) => writeOnDataView(encoder, 8).setFloat64(0, num, false);
var writeBigInt64 = (encoder, num) => (
  /** @type {any} */
  writeOnDataView(encoder, 8).setBigInt64(0, num, false)
);
var floatTestBed = new DataView(new ArrayBuffer(4));
var isFloat32 = (num) => {
  floatTestBed.setFloat32(0, num);
  return floatTestBed.getFloat32(0) === num;
};
var writeAny = (encoder, data) => {
  switch (typeof data) {
    case "string":
      write(encoder, 119);
      writeVarString(encoder, data);
      break;
    case "number":
      if (isInteger(data) && abs(data) <= BITS31) {
        write(encoder, 125);
        writeVarInt(encoder, data);
      } else if (isFloat32(data)) {
        write(encoder, 124);
        writeFloat32(encoder, data);
      } else {
        write(encoder, 123);
        writeFloat64(encoder, data);
      }
      break;
    case "bigint":
      write(encoder, 122);
      writeBigInt64(encoder, data);
      break;
    case "object":
      if (data === null) {
        write(encoder, 126);
      } else if (isArray(data)) {
        write(encoder, 117);
        writeVarUint(encoder, data.length);
        for (let i = 0; i < data.length; i++) {
          writeAny(encoder, data[i]);
        }
      } else if (data instanceof Uint8Array) {
        write(encoder, 116);
        writeVarUint8Array(encoder, data);
      } else {
        write(encoder, 118);
        const keys2 = Object.keys(data);
        writeVarUint(encoder, keys2.length);
        for (let i = 0; i < keys2.length; i++) {
          const key = keys2[i];
          writeVarString(encoder, key);
          writeAny(encoder, data[key]);
        }
      }
      break;
    case "boolean":
      write(encoder, data ? 120 : 121);
      break;
    default:
      write(encoder, 127);
  }
};
var RleEncoder = class extends Encoder {
  /**
   * @param {function(Encoder, T):void} writer
   */
  constructor(writer) {
    super();
    this.w = writer;
    this.s = null;
    this.count = 0;
  }
  /**
   * @param {T} v
   */
  write(v) {
    if (this.s === v) {
      this.count++;
    } else {
      if (this.count > 0) {
        writeVarUint(this, this.count - 1);
      }
      this.count = 1;
      this.w(this, v);
      this.s = v;
    }
  }
};
var flushUintOptRleEncoder = (encoder) => {
  if (encoder.count > 0) {
    writeVarInt(encoder.encoder, encoder.count === 1 ? encoder.s : -encoder.s);
    if (encoder.count > 1) {
      writeVarUint(encoder.encoder, encoder.count - 2);
    }
  }
};
var UintOptRleEncoder = class {
  constructor() {
    this.encoder = new Encoder();
    this.s = 0;
    this.count = 0;
  }
  /**
   * @param {number} v
   */
  write(v) {
    if (this.s === v) {
      this.count++;
    } else {
      flushUintOptRleEncoder(this);
      this.count = 1;
      this.s = v;
    }
  }
  /**
   * Flush the encoded state and transform this to a Uint8Array.
   *
   * Note that this should only be called once.
   */
  toUint8Array() {
    flushUintOptRleEncoder(this);
    return toUint8Array(this.encoder);
  }
};
var flushIntDiffOptRleEncoder = (encoder) => {
  if (encoder.count > 0) {
    const encodedDiff = encoder.diff * 2 + (encoder.count === 1 ? 0 : 1);
    writeVarInt(encoder.encoder, encodedDiff);
    if (encoder.count > 1) {
      writeVarUint(encoder.encoder, encoder.count - 2);
    }
  }
};
var IntDiffOptRleEncoder = class {
  constructor() {
    this.encoder = new Encoder();
    this.s = 0;
    this.count = 0;
    this.diff = 0;
  }
  /**
   * @param {number} v
   */
  write(v) {
    if (this.diff === v - this.s) {
      this.s = v;
      this.count++;
    } else {
      flushIntDiffOptRleEncoder(this);
      this.count = 1;
      this.diff = v - this.s;
      this.s = v;
    }
  }
  /**
   * Flush the encoded state and transform this to a Uint8Array.
   *
   * Note that this should only be called once.
   */
  toUint8Array() {
    flushIntDiffOptRleEncoder(this);
    return toUint8Array(this.encoder);
  }
};
var StringEncoder = class {
  constructor() {
    this.sarr = [];
    this.s = "";
    this.lensE = new UintOptRleEncoder();
  }
  /**
   * @param {string} string
   */
  write(string) {
    this.s += string;
    if (this.s.length > 19) {
      this.sarr.push(this.s);
      this.s = "";
    }
    this.lensE.write(string.length);
  }
  toUint8Array() {
    const encoder = new Encoder();
    this.sarr.push(this.s);
    this.s = "";
    writeVarString(encoder, this.sarr.join(""));
    writeUint8Array(encoder, this.lensE.toUint8Array());
    return toUint8Array(encoder);
  }
};

var create3 = (s) => new Error(s);
var methodUnimplemented = () => {
  throw create3("Method unimplemented");
};
var unexpectedCase = () => {
  throw create3("Unexpected case");
};

var errorUnexpectedEndOfArray = create3("Unexpected end of array");
var errorIntegerOutOfRange = create3("Integer out of Range");
var subarray = (arr, begin, len) => {
  if (begin < 0 || len < 0 || begin + len > arr.length) {
    throw errorUnexpectedEndOfArray;
  }
  return new Uint8Array(arr.buffer, arr.byteOffset + begin, len);
};
var subdataview = (arr, begin, len) => {
  if (begin < 0 || len < 0 || begin + len > arr.length) {
    throw errorUnexpectedEndOfArray;
  }
  return new DataView(arr.buffer, arr.byteOffset + begin, len);
};
var Decoder = class {
  /**
   * @param {Uint8Array<Buf>} uint8Array Binary data to decode
   */
  constructor(uint8Array) {
    this.arr = uint8Array;
    this.pos = 0;
  }
};
var createDecoder = (uint8Array) => new Decoder(uint8Array);
var hasContent = (decoder) => decoder.pos !== decoder.arr.length;
var readUint8Array = (decoder, len) => {
  const view = subarray(decoder.arr, decoder.pos, len);
  decoder.pos += len;
  return view;
};
var readVarUint8Array = (decoder) => readUint8Array(decoder, readVarUint(decoder));
var readUint8 = (decoder) => decoder.arr[decoder.pos++];
var readVarUint = (decoder) => {
  let num = 0;
  let mult = 1;
  const len = decoder.arr.length;
  while (decoder.pos < len) {
    const r2 = decoder.arr[decoder.pos++];
    num = num + (r2 & BITS7) * mult;
    mult *= 128;
    if (r2 < BIT8) {
      return num;
    }
    if (num > MAX_SAFE_INTEGER) {
      throw errorIntegerOutOfRange;
    }
  }
  throw errorUnexpectedEndOfArray;
};
var readVarInt = (decoder) => {
  let r2 = decoder.arr[decoder.pos++];
  let num = r2 & BITS6;
  let mult = 64;
  const sign = (r2 & BIT7) > 0 ? -1 : 1;
  if ((r2 & BIT8) === 0) {
    return sign * num;
  }
  const len = decoder.arr.length;
  while (decoder.pos < len) {
    r2 = decoder.arr[decoder.pos++];
    num = num + (r2 & BITS7) * mult;
    mult *= 128;
    if (r2 < BIT8) {
      return sign * num;
    }
    if (num > MAX_SAFE_INTEGER) {
      throw errorIntegerOutOfRange;
    }
  }
  throw errorUnexpectedEndOfArray;
};
var _readVarStringPolyfill = (decoder) => {
  let remainingLen = readVarUint(decoder);
  if (remainingLen === 0) {
    return "";
  } else {
    let encodedString = String.fromCodePoint(readUint8(decoder));
    if (--remainingLen < 100) {
      while (remainingLen--) {
        encodedString += String.fromCodePoint(readUint8(decoder));
      }
    } else {
      while (remainingLen > 0) {
        const nextLen = remainingLen < 1e4 ? remainingLen : 1e4;
        const bytes = decoder.arr.subarray(decoder.pos, decoder.pos + nextLen);
        decoder.pos += nextLen;
        encodedString += String.fromCodePoint.apply(
          null,
          /** @type {any} */
          bytes
        );
        remainingLen -= nextLen;
      }
    }
    return decodeURIComponent(escape(encodedString));
  }
};
var _readVarStringNative = (decoder) => (
  /** @type any */
  utf8TextDecoder.decode(readVarUint8Array(decoder))
);
var readVarString = utf8TextDecoder ? _readVarStringNative : _readVarStringPolyfill;
var readFromDataView = (decoder, len) => {
  const dv = subdataview(decoder.arr, decoder.pos, len);
  decoder.pos += len;
  return dv;
};
var readFloat32 = (decoder) => readFromDataView(decoder, 4).getFloat32(0, false);
var readFloat64 = (decoder) => readFromDataView(decoder, 8).getFloat64(0, false);
var readBigInt64 = (decoder) => (
  /** @type {any} */
  readFromDataView(decoder, 8).getBigInt64(0, false)
);
var readAnyLookupTable = [
  (decoder) => void 0,
  // CASE 127: undefined
  (decoder) => null,
  // CASE 126: null
  readVarInt,
  // CASE 125: integer
  readFloat32,
  // CASE 124: float32
  readFloat64,
  // CASE 123: float64
  readBigInt64,
  // CASE 122: bigint
  (decoder) => false,
  // CASE 121: boolean (false)
  (decoder) => true,
  // CASE 120: boolean (true)
  readVarString,
  // CASE 119: string
  (decoder) => {
    const len = readVarUint(decoder);
    const obj = {};
    for (let i = 0; i < len; i++) {
      const key = readVarString(decoder);
      obj[key] = readAny(decoder);
    }
    return obj;
  },
  (decoder) => {
    const len = readVarUint(decoder);
    const arr = [];
    for (let i = 0; i < len; i++) {
      arr.push(readAny(decoder));
    }
    return arr;
  },
  readVarUint8Array
  // CASE 116: Uint8Array
];
var readAny = (decoder) => readAnyLookupTable[127 - readUint8(decoder)](decoder);
var RleDecoder = class extends Decoder {
  /**
   * @param {Uint8Array} uint8Array
   * @param {function(Decoder):T} reader
   */
  constructor(uint8Array, reader) {
    super(uint8Array);
    this.reader = reader;
    this.s = null;
    this.count = 0;
  }
  read() {
    if (this.count === 0) {
      this.s = this.reader(this);
      if (hasContent(this)) {
        this.count = readVarUint(this) + 1;
      } else {
        this.count = -1;
      }
    }
    this.count--;
    return (
      /** @type {T} */
      this.s
    );
  }
};
var UintOptRleDecoder = class extends Decoder {
  /**
   * @param {Uint8Array} uint8Array
   */
  constructor(uint8Array) {
    super(uint8Array);
    this.s = 0;
    this.count = 0;
  }
  read() {
    if (this.count === 0) {
      this.s = readVarInt(this);
      const isNegative = isNegativeZero(this.s);
      this.count = 1;
      if (isNegative) {
        this.s = -this.s;
        this.count = readVarUint(this) + 2;
      }
    }
    this.count--;
    return (
      /** @type {number} */
      this.s
    );
  }
};
var IntDiffOptRleDecoder = class extends Decoder {
  /**
   * @param {Uint8Array} uint8Array
   */
  constructor(uint8Array) {
    super(uint8Array);
    this.s = 0;
    this.count = 0;
    this.diff = 0;
  }
  /**
   * @return {number}
   */
  read() {
    if (this.count === 0) {
      const diff = readVarInt(this);
      const hasCount = diff & 1;
      this.diff = floor(diff / 2);
      this.count = 1;
      if (hasCount) {
        this.count = readVarUint(this) + 2;
      }
    }
    this.s += this.diff;
    this.count--;
    return this.s;
  }
};
var StringDecoder = class {
  /**
   * @param {Uint8Array} uint8Array
   */
  constructor(uint8Array) {
    this.decoder = new UintOptRleDecoder(uint8Array);
    this.str = readVarString(this.decoder);
    this.spos = 0;
  }
  /**
   * @return {string}
   */
  read() {
    const end = this.spos + this.decoder.read();
    const res = this.str.slice(this.spos, end);
    this.spos = end;
    return res;
  }
};

var subtle = crypto.subtle;
var getRandomValues = crypto.getRandomValues.bind(crypto);

var uint32 = () => getRandomValues(new Uint32Array(1))[0];
var uuidv4Template = "10000000-1000-4000-8000" + -1e11;
var uuidv4 = () => uuidv4Template.replace(
  /[018]/g,
  /** @param {number} c */
  (c) => (c ^ uint32() & 15 >> c / 4).toString(16)
);

var getUnixTime = Date.now;

var create4 = (f) => (
  /** @type {Promise<T>} */
  new Promise(f)
);
var all = Promise.all.bind(Promise);

var undefinedToNull = (v) => v === void 0 ? null : v;

var VarStoragePolyfill = class {
  constructor() {
    this.map = /* @__PURE__ */ new Map();
  }
  /**
   * @param {string} key
   * @param {any} newValue
   */
  setItem(key, newValue) {
    this.map.set(key, newValue);
  }
  /**
   * @param {string} key
   */
  getItem(key) {
    return this.map.get(key);
  }
};
var _localStorage = new VarStoragePolyfill();
var usePolyfill = true;
try {
  if (typeof localStorage !== "undefined" && localStorage) {
    _localStorage = localStorage;
    usePolyfill = false;
  }
} catch (e) {
}
var varStorage = _localStorage;

var EqualityTraitSymbol = Symbol("Equality");
var equals = (a, b) => a === b || !!a?.[EqualityTraitSymbol]?.(b) || false;

var isObject = (o) => typeof o === "object";
var assign = Object.assign;
var keys = Object.keys;
var forEach = (obj, f) => {
  for (const key in obj) {
    f(obj[key], key);
  }
};
var size = (obj) => keys(obj).length;
var isEmpty = (obj) => {
  for (const _k in obj) {
    return false;
  }
  return true;
};
var every2 = (obj, f) => {
  for (const key in obj) {
    if (!f(obj[key], key)) {
      return false;
    }
  }
  return true;
};
var hasProperty = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
var equalFlat = (a, b) => a === b || size(a) === size(b) && every2(a, (val, key) => (val !== void 0 || hasProperty(b, key)) && equals(b[key], val));
var freeze = Object.freeze;
var deepFreeze = (o) => {
  for (const key in o) {
    const c = o[key];
    if (typeof c === "object" || typeof c === "function") {
      deepFreeze(o[key]);
    }
  }
  return freeze(o);
};

var callAll = (fs, args2, i = 0) => {
  try {
    for (; i < fs.length; i++) {
      fs[i](...args2);
    }
  } finally {
    if (i < fs.length) {
      callAll(fs, args2, i + 1);
    }
  }
};
var id = (a) => a;
var equalityDeep = (a, b) => {
  if (a === b) {
    return true;
  }
  if (a == null || b == null || a.constructor !== b.constructor && (a.constructor || Object) !== (b.constructor || Object)) {
    return false;
  }
  if (a[EqualityTraitSymbol] != null) {
    return a[EqualityTraitSymbol](b);
  }
  switch (a.constructor) {
    case ArrayBuffer:
      a = new Uint8Array(a);
      b = new Uint8Array(b);
    // eslint-disable-next-line no-fallthrough
    case Uint8Array: {
      if (a.byteLength !== b.byteLength) {
        return false;
      }
      for (let i = 0; i < a.length; i++) {
        if (a[i] !== b[i]) {
          return false;
        }
      }
      break;
    }
    case Set: {
      if (a.size !== b.size) {
        return false;
      }
      for (const value of a) {
        if (!b.has(value)) {
          return false;
        }
      }
      break;
    }
    case Map: {
      if (a.size !== b.size) {
        return false;
      }
      for (const key of a.keys()) {
        if (!b.has(key) || !equalityDeep(a.get(key), b.get(key))) {
          return false;
        }
      }
      break;
    }
    case void 0:
    case Object:
      if (size(a) !== size(b)) {
        return false;
      }
      for (const key in a) {
        if (!hasProperty(a, key) || !equalityDeep(a[key], b[key])) {
          return false;
        }
      }
      break;
    case Array:
      if (a.length !== b.length) {
        return false;
      }
      for (let i = 0; i < a.length; i++) {
        if (!equalityDeep(a[i], b[i])) {
          return false;
        }
      }
      break;
    default:
      return false;
  }
  return true;
};
var isOneOf = (value, options) => options.includes(value);

var isNode = typeof process !== "undefined" && process.release && /node|io\.js/.test(process.release.name) && Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]";
var isMac = typeof navigator !== "undefined" ? /Mac/.test(navigator.platform) : false;
var params;
var args = [];
var computeParams = () => {
  if (params === void 0) {
    if (isNode) {
      params = create();
      const pargs = process.argv;
      let currParamName = null;
      for (let i = 0; i < pargs.length; i++) {
        const parg = pargs[i];
        if (parg[0] === "-") {
          if (currParamName !== null) {
            params.set(currParamName, "");
          }
          currParamName = parg;
        } else {
          if (currParamName !== null) {
            params.set(currParamName, parg);
            currParamName = null;
          } else {
            args.push(parg);
          }
        }
      }
      if (currParamName !== null) {
        params.set(currParamName, "");
      }
    } else if (typeof location === "object") {
      params = create();
      (location.search || "?").slice(1).split("&").forEach((kv) => {
        if (kv.length !== 0) {
          const [key, value] = kv.split("=");
          params.set(`--${fromCamelCase(key, "-")}`, value);
          params.set(`-${fromCamelCase(key, "-")}`, value);
        }
      });
    } else {
      params = create();
    }
  }
  return params;
};
var hasParam = (name) => computeParams().has(name);
var getVariable = (name) => isNode ? undefinedToNull(process.env[name.toUpperCase().replaceAll("-", "_")]) : undefinedToNull(varStorage.getItem(name));
var hasConf = (name) => hasParam("--" + name) || getVariable(name) !== null;
var production = hasConf("production");
var forceColor = isNode && isOneOf(process.env.FORCE_COLOR, ["true", "1", "2"]);
var supportsColor = forceColor || !hasParam("--no-colors") && // @todo deprecate --no-colors
!hasConf("no-color") && (!isNode || process.stdout.isTTY) && (!isNode || hasParam("--color") || getVariable("COLORTERM") !== null || (getVariable("TERM") || "").includes("color"));

var createUint8ArrayFromLen = (len) => new Uint8Array(len);
var copyUint8Array = (uint8Array) => {
  const newBuf = createUint8ArrayFromLen(uint8Array.byteLength);
  newBuf.set(uint8Array);
  return newBuf;
};

var Pair = class {
  /**
   * @param {L} left
   * @param {R} right
   */
  constructor(left, right) {
    this.left = left;
    this.right = right;
  }
};
var create5 = (left, right) => new Pair(left, right);
var forEach2 = (arr, f) => arr.forEach((p) => f(p.left, p.right));

var bool = (gen) => gen.next() >= 0.5;
var int53 = (gen, min2, max2) => floor(gen.next() * (max2 + 1 - min2) + min2);
var int32 = (gen, min2, max2) => floor(gen.next() * (max2 + 1 - min2) + min2);
var int31 = (gen, min2, max2) => int32(gen, min2, max2);
var letter = (gen) => fromCharCode(int31(gen, 97, 122));
var word = (gen, minLen = 0, maxLen = 20) => {
  const len = int31(gen, minLen, maxLen);
  let str = "";
  for (let i = 0; i < len; i++) {
    str += letter(gen);
  }
  return str;
};
var oneOf = (gen, array) => array[int31(gen, 0, array.length - 1)];

var schemaSymbol = Symbol("0schema");
var ValidationError = class {
  constructor() {
    this._rerrs = [];
  }
  /**
   * @param {string?} path
   * @param {string} expected
   * @param {string} has
   * @param {string?} message
   */
  extend(path, expected, has, message = null) {
    this._rerrs.push({ path, expected, has, message });
  }
  toString() {
    const s = [];
    for (let i = this._rerrs.length - 1; i > 0; i--) {
      const r2 = this._rerrs[i];
      s.push(repeat(" ", (this._rerrs.length - i) * 2) + `${r2.path != null ? `[${r2.path}] ` : ""}${r2.has} doesn't match ${r2.expected}. ${r2.message}`);
    }
    return s.join("\n");
  }
};
var shapeExtends = (a, b) => {
  if (a === b) return true;
  if (a == null || b == null || a.constructor !== b.constructor) return false;
  if (a[EqualityTraitSymbol]) return equals(a, b);
  if (isArray(a)) {
    return every(
      a,
      (aitem) => some(b, (bitem) => shapeExtends(aitem, bitem))
    );
  } else if (isObject(a)) {
    return every2(
      a,
      (aitem, akey) => shapeExtends(aitem, b[akey])
    );
  }
  return false;
};
var Schema = class {
  // this.shape must not be defined on Schema. Otherwise typecheck on metatypes (e.g. $$object) won't work as expected anymore
  /**
   * If true, the more things are added to the shape the more objects this schema will accept (e.g.
   * union). By default, the more objects are added, the the fewer objects this schema will accept.
   * @protected
   */
  static _dilutes = false;
  /**
   * @param {Schema<any>} other
   */
  extends(other) {
    let [a, b] = [
      /** @type {any} */
      this.shape,
      /** @type {any} */
      other.shape
    ];
    if (
      /** @type {typeof Schema<any>} */
      this.constructor._dilutes
    ) [b, a] = [a, b];
    return shapeExtends(a, b);
  }
  /**
   * Overwrite this when necessary. By default, we only check the `shape` property which every shape
   * should have.
   * @param {Schema<any>} other
   */
  equals(other) {
    return this.constructor === other.constructor && equalityDeep(this.shape, other.shape);
  }
  [schemaSymbol]() {
    return true;
  }
  /**
   * @param {object} other
   */
  [EqualityTraitSymbol](other) {
    return this.equals(
      /** @type {any} */
      other
    );
  }
  /**
   * Use `schema.validate(obj)` with a typed parameter that is already of typed to be an instance of
   * Schema. Validate will check the structure of the parameter and return true iff the instance
   * really is an instance of Schema.
   *
   * @param {T} o
   * @return {boolean}
   */
  validate(o) {
    return this.check(o);
  }
  /* c8 ignore start */
  /**
   * Similar to validate, but this method accepts untyped parameters.
   *
   * @param {any} _o
   * @param {ValidationError} [_err]
   * @return {_o is T}
   */
  check(_o, _err) {
    methodUnimplemented();
  }
  /* c8 ignore stop */
  /**
   * @type {Schema<T?>}
   */
  get nullable() {
    return $union(this, $null);
  }
  /**
   * @type {$Optional<Schema<T>>}
   */
  get optional() {
    return new $Optional(
      /** @type {Schema<T>} */
      this
    );
  }
  /**
   * Cast a variable to a specific type. Returns the casted value, or throws an exception otherwise.
   * Use this if you know that the type is of a specific type and you just want to convince the type
   * system.
   *
   * **Do not rely on these error messages!**
   * Performs an assertion check only if not in a production environment.
   *
   * @template OO
   * @param {OO} o
   * @return {Extract<OO, T> extends never ? T : (OO extends Array<never> ? T : Extract<OO,T>)}
   */
  cast(o) {
    assert(o, this);
    return (
      /** @type {any} */
      o
    );
  }
  /**
   * EXPECTO PATRONUM!! 🪄
   * This function protects against type errors. Though it may not work in the real world.
   *
   * "After all this time?"
   * "Always." - Snape, talking about type safety
   *
   * Ensures that a variable is a a specific type. Returns the value, or throws an exception if the assertion check failed.
   * Use this if you know that the type is of a specific type and you just want to convince the type
   * system.
   *
   * Can be useful when defining lambdas: `s.lambda(s.$number, s.$void).expect((n) => n + 1)`
   *
   * **Do not rely on these error messages!**
   * Performs an assertion check if not in a production environment.
   *
   * @param {T} o
   * @return {o extends T ? T : never}
   */
  expect(o) {
    assert(o, this);
    return o;
  }
};
var $ConstructedBy = class extends Schema {
  /**
   * @param {C} c
   * @param {((o:Instance<C>)=>boolean)|null} check
   */
  constructor(c, check) {
    super();
    this.shape = c;
    this._c = check;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is C extends ((...args:any[]) => infer T) ? T : (C extends (new (...args:any[]) => any) ? InstanceType<C> : never)} o
   */
  check(o, err = void 0) {
    const c = o?.constructor === this.shape && (this._c == null || this._c(o));
    !c && err?.extend(null, this.shape.name, o?.constructor.name, o?.constructor !== this.shape ? "Constructor match failed" : "Check failed");
    return c;
  }
};
var $constructedBy = (c, check = null) => new $ConstructedBy(c, check);
var $$constructedBy = $constructedBy($ConstructedBy);
var $Custom = class extends Schema {
  /**
   * @param {(o:any) => boolean} check
   */
  constructor(check) {
    super();
    this.shape = check;
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is any}
   */
  check(o, err) {
    const c = this.shape(o);
    !c && err?.extend(null, "custom prop", o?.constructor.name, "failed to check custom prop");
    return c;
  }
};
var $custom = (check) => new $Custom(check);
var $$custom = $constructedBy($Custom);
var $Literal = class extends Schema {
  /**
   * @param {Array<T>} literals
   */
  constructor(literals) {
    super();
    this.shape = literals;
  }
  /**
   *
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is T}
   */
  check(o, err) {
    const c = this.shape.some((a) => a === o);
    !c && err?.extend(null, this.shape.join(" | "), o.toString());
    return c;
  }
};
var $literal = (...literals) => new $Literal(literals);
var $$literal = $constructedBy($Literal);
var _regexEscape = (
  /** @type {any} */
  RegExp.escape || /** @type {(str:string) => string} */
  ((str) => str.replace(/[().|&,$^[\]]/g, (s) => "\\" + s))
);
var _schemaStringTemplateToRegex = (s) => {
  if ($string.check(s)) {
    return [_regexEscape(s)];
  }
  if ($$literal.check(s)) {
    return (
      /** @type {Array<string|number>} */
      s.shape.map((v) => v + "")
    );
  }
  if ($$number.check(s)) {
    return ["[+-]?\\d+.?\\d*"];
  }
  if ($$string.check(s)) {
    return [".*"];
  }
  if ($$union.check(s)) {
    return s.shape.map(_schemaStringTemplateToRegex).flat(1);
  }
  unexpectedCase();
};
var $StringTemplate = class extends Schema {
  /**
   * @param {T} shape
   */
  constructor(shape) {
    super();
    this.shape = shape;
    this._r = new RegExp("^" + shape.map(_schemaStringTemplateToRegex).map((opts) => `(${opts.join("|")})`).join("") + "$");
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is CastStringTemplateArgsToTemplate<T>}
   */
  check(o, err) {
    const c = this._r.exec(o) != null;
    !c && err?.extend(null, this._r.toString(), o.toString(), "String doesn't match string template.");
    return c;
  }
};
var $$stringTemplate = $constructedBy($StringTemplate);
var isOptionalSymbol = Symbol("optional");
var $Optional = class extends Schema {
  /**
   * @param {S} shape
   */
  constructor(shape) {
    super();
    this.shape = shape;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is (Unwrap<S>|undefined)}
   */
  check(o, err) {
    const c = o === void 0 || this.shape.check(o);
    !c && err?.extend(null, "undefined (optional)", "()");
    return c;
  }
  get [isOptionalSymbol]() {
    return true;
  }
};
var $$optional = $constructedBy($Optional);
var $Never = class extends Schema {
  /**
   * @param {any} _o
   * @param {ValidationError} [err]
   * @return {_o is never}
   */
  check(_o, err) {
    err?.extend(null, "never", typeof _o);
    return false;
  }
};
var $never = new $Never();
var $$never = $constructedBy($Never);
var $Object = class _$Object extends Schema {
  /**
   * @param {S} shape
   * @param {boolean} partial
   */
  constructor(shape, partial = false) {
    super();
    this.shape = shape;
    this._isPartial = partial;
  }
  static _dilutes = true;
  /**
   * @type {Schema<Partial<$ObjectToType<S>>>}
   */
  get partial() {
    return new _$Object(this.shape, true);
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is $ObjectToType<S>}
   */
  check(o, err) {
    if (o == null) {
      err?.extend(null, "object", "null");
      return false;
    }
    return every2(this.shape, (vv, vk) => {
      const c = this._isPartial && !hasProperty(o, vk) || vv.check(o[vk], err);
      !c && err?.extend(vk.toString(), vv.toString(), typeof o[vk], "Object property does not match");
      return c;
    });
  }
};
var $object = (def) => (
  /** @type {any} */
  new $Object(def)
);
var $$object = $constructedBy($Object);
var $objectAny = $custom((o) => o != null && (o.constructor === Object || o.constructor == null));
var $Record = class extends Schema {
  /**
   * @param {Keys} keys
   * @param {Values} values
   */
  constructor(keys2, values) {
    super();
    this.shape = {
      keys: keys2,
      values
    };
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is { [key in Unwrap<Keys>]: Unwrap<Values> }}
   */
  check(o, err) {
    return o != null && every2(o, (vv, vk) => {
      const ck = this.shape.keys.check(vk, err);
      !ck && err?.extend(vk + "", "Record", typeof o, ck ? "Key doesn't match schema" : "Value doesn't match value");
      return ck && this.shape.values.check(vv, err);
    });
  }
};
var $record = (keys2, values) => new $Record(keys2, values);
var $$record = $constructedBy($Record);
var $Tuple = class extends Schema {
  /**
   * @param {S} shape
   */
  constructor(shape) {
    super();
    this.shape = shape;
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is { [K in keyof S]: S[K] extends Schema<infer Type> ? Type : never }}
   */
  check(o, err) {
    return o != null && every2(this.shape, (vv, vk) => {
      const c = (
        /** @type {Schema<any>} */
        vv.check(o[vk], err)
      );
      !c && err?.extend(vk.toString(), "Tuple", typeof vv);
      return c;
    });
  }
};
var $tuple = (...def) => new $Tuple(def);
var $$tuple = $constructedBy($Tuple);
var $Array = class extends Schema {
  /**
   * @param {Array<S>} v
   */
  constructor(v) {
    super();
    this.shape = v.length === 1 ? v[0] : new $Union(v);
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is Array<S extends Schema<infer T> ? T : never>} o
   */
  check(o, err) {
    const c = isArray(o) && every(o, (oi) => this.shape.check(oi));
    !c && err?.extend(null, "Array", "");
    return c;
  }
};
var $array = (...def) => new $Array(def);
var $$array = $constructedBy($Array);
var $arrayAny = $custom((o) => isArray(o));
var $InstanceOf = class extends Schema {
  /**
   * @param {new (...args:any) => T} constructor
   * @param {((o:T) => boolean)|null} check
   */
  constructor(constructor, check) {
    super();
    this.shape = constructor;
    this._c = check;
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is T}
   */
  check(o, err) {
    const c = o instanceof this.shape && (this._c == null || this._c(o));
    !c && err?.extend(null, this.shape.name, o?.constructor.name);
    return c;
  }
};
var $instanceOf = (c, check = null) => new $InstanceOf(c, check);
var $$instanceOf = $constructedBy($InstanceOf);
var $$schema = $instanceOf(Schema);
var $Lambda = class extends Schema {
  /**
   * @param {Args} args
   */
  constructor(args2) {
    super();
    this.len = args2.length - 1;
    this.args = $tuple(...args2.slice(-1));
    this.res = args2[this.len];
  }
  /**
   * @param {any} f
   * @param {ValidationError} err
   * @return {f is _LArgsToLambdaDef<Args>}
   */
  check(f, err) {
    const c = f.constructor === Function && f.length <= this.len;
    !c && err?.extend(null, "function", typeof f);
    return c;
  }
};
var $$lambda = $constructedBy($Lambda);
var $function = $custom((o) => typeof o === "function");
var $Intersection = class extends Schema {
  /**
   * @param {T} v
   */
  constructor(v) {
    super();
    this.shape = v;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is Intersect<UnwrapArray<T>>}
   */
  check(o, err) {
    const c = every(this.shape, (check) => check.check(o, err));
    !c && err?.extend(null, "Intersectinon", typeof o);
    return c;
  }
};
var $$intersect = $constructedBy($Intersection, (o) => o.shape.length > 0);
var $Union = class extends Schema {
  static _dilutes = true;
  /**
   * @param {Array<Schema<S>>} v
   */
  constructor(v) {
    super();
    this.shape = v;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is S}
   */
  check(o, err) {
    const c = some(this.shape, (vv) => vv.check(o, err));
    err?.extend(null, "Union", typeof o);
    return c;
  }
};
var $union = (...schemas) => schemas.findIndex(($s) => $$union.check($s)) >= 0 ? $union(...schemas.map(($s) => $($s)).map(($s) => $$union.check($s) ? $s.shape : [$s]).flat(1)) : schemas.length === 1 ? schemas[0] : new $Union(schemas);
var $$union = (
  /** @type {Schema<$Union<any>>} */
  $constructedBy($Union)
);
var _t = () => true;
var $any = $custom(_t);
var $$any = (
  /** @type {Schema<Schema<any>>} */
  $constructedBy($Custom, (o) => o.shape === _t)
);
var $bigint = $custom((o) => typeof o === "bigint");
var $$bigint = (
  /** @type {Schema<Schema<BigInt>>} */
  $custom((o) => o === $bigint)
);
var $symbol = $custom((o) => typeof o === "symbol");
var $$symbol = (
  /** @type {Schema<Schema<Symbol>>} */
  $custom((o) => o === $symbol)
);
var $number = $custom((o) => typeof o === "number");
var $$number = (
  /** @type {Schema<Schema<number>>} */
  $custom((o) => o === $number)
);
var $string = $custom((o) => typeof o === "string");
var $$string = (
  /** @type {Schema<Schema<string>>} */
  $custom((o) => o === $string)
);
var $boolean = $custom((o) => typeof o === "boolean");
var $$boolean = (
  /** @type {Schema<Schema<Boolean>>} */
  $custom((o) => o === $boolean)
);
var $undefined = $literal(void 0);
var $$undefined = (
  /** @type {Schema<Schema<undefined>>} */
  $constructedBy($Literal, (o) => o.shape.length === 1 && o.shape[0] === void 0)
);
var $void = $literal(void 0);
var $null = $literal(null);
var $$null = (
  /** @type {Schema<Schema<null>>} */
  $constructedBy($Literal, (o) => o.shape.length === 1 && o.shape[0] === null)
);
var $uint8Array = $constructedBy(Uint8Array);
var $$uint8Array = (
  /** @type {Schema<Schema<Uint8Array>>} */
  $constructedBy($ConstructedBy, (o) => o.shape === Uint8Array)
);
var $primitive = $union($number, $string, $null, $undefined, $bigint, $boolean, $symbol);
var $json = (() => {
  const $jsonArr = (
    /** @type {$Array<$any>} */
    $array($any)
  );
  const $jsonRecord = (
    /** @type {$Record<$string,$any>} */
    $record($string, $any)
  );
  const $json2 = $union($number, $string, $null, $boolean, $jsonArr, $jsonRecord);
  $jsonArr.shape = $json2;
  $jsonRecord.shape.values = $json2;
  return $json2;
})();
var $ = (o) => {
  if ($$schema.check(o)) {
    return (
      /** @type {any} */
      o
    );
  } else if ($objectAny.check(o)) {
    const o2 = {};
    for (const k in o) {
      o2[k] = $(o[k]);
    }
    return (
      /** @type {any} */
      $object(o2)
    );
  } else if ($arrayAny.check(o)) {
    return (
      /** @type {any} */
      $union(...o.map($))
    );
  } else if ($primitive.check(o)) {
    return (
      /** @type {any} */
      $literal(o)
    );
  } else if ($function.check(o)) {
    return (
      /** @type {any} */
      $constructedBy(
        /** @type {any} */
        o
      )
    );
  }
  unexpectedCase();
};
var assert = production ? () => {
} : (o, schema) => {
  const err = new ValidationError();
  if (!schema.check(o, err)) {
    throw create3(`Expected value to be of type ${schema.constructor.name}.
${err.toString()}`);
  }
};
var PatternMatcher = class {
  /**
   * @param {Schema<State>} [$state]
   */
  constructor($state) {
    this.patterns = [];
    this.$state = $state;
  }
  /**
   * @template P
   * @template R
   * @param {P} pattern
   * @param {(o:NoInfer<Unwrap<ReadSchema<P>>>,s:State)=>R} handler
   * @return {PatternMatcher<State,Patterns|Pattern<Unwrap<ReadSchema<P>>,R>>}
   */
  if(pattern, handler) {
    this.patterns.push({ if: $(pattern), h: handler });
    return this;
  }
  /**
   * @template R
   * @param {(o:any,s:State)=>R} h
   */
  else(h) {
    return this.if($any, h);
  }
  /**
   * @return {State extends undefined
   *   ? <In extends Unwrap<Patterns['if']>>(o:In,state?:undefined)=>PatternMatchResult<Patterns,In>
   *   : <In extends Unwrap<Patterns['if']>>(o:In,state:State)=>PatternMatchResult<Patterns,In>}
   */
  done() {
    return (
      /** @type {any} */
      (o, s) => {
        for (let i = 0; i < this.patterns.length; i++) {
          const p = this.patterns[i];
          if (p.if.check(o)) {
            return p.h(o, s);
          }
        }
        throw create3("Unhandled pattern");
      }
    );
  }
};
var match = (state) => new PatternMatcher(
  /** @type {any} */
  state
);
var _random = (
  /** @type {any} */
  match(
    /** @type {Schema<prng.PRNG>} */
    $any
  ).if($$number, (_o, gen) => int53(gen, MIN_SAFE_INTEGER, MAX_SAFE_INTEGER)).if($$string, (_o, gen) => word(gen)).if($$boolean, (_o, gen) => bool(gen)).if($$bigint, (_o, gen) => BigInt(int53(gen, MIN_SAFE_INTEGER, MAX_SAFE_INTEGER))).if($$union, (o, gen) => random(gen, oneOf(gen, o.shape))).if($$object, (o, gen) => {
    const res = {};
    for (const k in o.shape) {
      let prop = o.shape[k];
      if ($$optional.check(prop)) {
        if (bool(gen)) {
          continue;
        }
        prop = prop.shape;
      }
      res[k] = _random(prop, gen);
    }
    return res;
  }).if($$array, (o, gen) => {
    const arr = [];
    const n = int32(gen, 0, 42);
    for (let i = 0; i < n; i++) {
      arr.push(random(gen, o.shape));
    }
    return arr;
  }).if($$literal, (o, gen) => {
    return oneOf(gen, o.shape);
  }).if($$null, (o, gen) => {
    return null;
  }).if($$lambda, (o, gen) => {
    const res = random(gen, o.res);
    return () => res;
  }).if($$any, (o, gen) => random(gen, oneOf(gen, [
    $number,
    $string,
    $null,
    $undefined,
    $bigint,
    $boolean,
    $array($number),
    $record($union("a", "b", "c"), $number)
  ]))).if($$record, (o, gen) => {
    const res = {};
    const keysN = int53(gen, 0, 3);
    for (let i = 0; i < keysN; i++) {
      const key = random(gen, o.shape.keys);
      const val = random(gen, o.shape.values);
      res[key] = val;
    }
    return res;
  }).done()
);
var random = (gen, schema) => (
  /** @type {any} */
  _random($(schema), gen)
);

var doc = (
  /** @type {Document} */
  typeof document !== "undefined" ? document : {}
);
var createElement = (name) => doc.createElement(name);
var createDocumentFragment = () => doc.createDocumentFragment();
var $fragment = $custom((el) => el.nodeType === DOCUMENT_FRAGMENT_NODE);
var createTextNode = (text2) => doc.createTextNode(text2);
var domParser = (
  /** @type {DOMParser} */
  typeof DOMParser !== "undefined" ? new DOMParser() : null
);
var setAttributes = (el, attrs) => {
  forEach2(attrs, (key, value) => {
    if (value === false) {
      el.removeAttribute(key);
    } else if (value === true) {
      el.setAttribute(key, "");
    } else {
      el.setAttribute(key, value);
    }
  });
  return el;
};
var fragment = (children) => {
  const fragment2 = createDocumentFragment();
  for (let i = 0; i < children.length; i++) {
    appendChild(fragment2, children[i]);
  }
  return fragment2;
};
var append = (parent, nodes) => {
  appendChild(parent, fragment(nodes));
  return parent;
};
var element = (name, attrs = [], children = []) => append(setAttributes(createElement(name), attrs), children);
var $element = $custom((el) => el.nodeType === ELEMENT_NODE);
var text = createTextNode;
var $text = $custom((el) => el.nodeType === TEXT_NODE);
var mapToStyleString = (m) => map(m, (value, key) => `${key}:${value};`).join("");
var appendChild = (parent, child) => parent.appendChild(child);
var ELEMENT_NODE = doc.ELEMENT_NODE;
var TEXT_NODE = doc.TEXT_NODE;
var CDATA_SECTION_NODE = doc.CDATA_SECTION_NODE;
var COMMENT_NODE = doc.COMMENT_NODE;
var DOCUMENT_NODE = doc.DOCUMENT_NODE;
var DOCUMENT_TYPE_NODE = doc.DOCUMENT_TYPE_NODE;
var DOCUMENT_FRAGMENT_NODE = doc.DOCUMENT_FRAGMENT_NODE;
var $node = $custom((el) => el.nodeType === DOCUMENT_NODE);

var create6 = Symbol;

var BOLD = create6();
var UNBOLD = create6();
var BLUE = create6();
var GREY = create6();
var GREEN = create6();
var RED = create6();
var PURPLE = create6();
var ORANGE = create6();
var UNCOLOR = create6();
var computeNoColorLoggingArgs = (args2) => {
  if (args2.length === 1 && args2[0]?.constructor === Function) {
    args2 = /** @type {Array<string|Symbol|Object|number>} */
    /** @type {[function]} */
    args2[0]();
  }
  const strBuilder = [];
  const logArgs = [];
  let i = 0;
  for (; i < args2.length; i++) {
    const arg = args2[i];
    if (arg === void 0) {
      break;
    } else if (arg.constructor === String || arg.constructor === Number) {
      strBuilder.push(arg);
    } else if (arg.constructor === Object) {
      break;
    }
  }
  if (i > 0) {
    logArgs.push(strBuilder.join(""));
  }
  for (; i < args2.length; i++) {
    const arg = args2[i];
    if (!(arg instanceof Symbol)) {
      logArgs.push(arg);
    }
  }
  return logArgs;
};
var lastLoggingTime = getUnixTime();

var _browserStyleMap = {
  [BOLD]: create5("font-weight", "bold"),
  [UNBOLD]: create5("font-weight", "normal"),
  [BLUE]: create5("color", "blue"),
  [GREEN]: create5("color", "green"),
  [GREY]: create5("color", "grey"),
  [RED]: create5("color", "red"),
  [PURPLE]: create5("color", "purple"),
  [ORANGE]: create5("color", "orange"),
  // not well supported in chrome when debugging node with inspector - TODO: deprecate
  [UNCOLOR]: create5("color", "black")
};
var computeBrowserLoggingArgs = (args2) => {
  if (args2.length === 1 && args2[0]?.constructor === Function) {
    args2 = /** @type {Array<string|Symbol|Object|number>} */
    /** @type {[function]} */
    args2[0]();
  }
  const strBuilder = [];
  const styles = [];
  const currentStyle = create();
  let logArgs = [];
  let i = 0;
  for (; i < args2.length; i++) {
    const arg = args2[i];
    const style = _browserStyleMap[arg];
    if (style !== void 0) {
      currentStyle.set(style.left, style.right);
    } else {
      if (arg === void 0) {
        break;
      }
      if (arg.constructor === String || arg.constructor === Number) {
        const style2 = mapToStyleString(currentStyle);
        if (i > 0 || style2.length > 0) {
          strBuilder.push("%c" + arg);
          styles.push(style2);
        } else {
          strBuilder.push(arg);
        }
      } else {
        break;
      }
    }
  }
  if (i > 0) {
    logArgs = styles;
    logArgs.unshift(strBuilder.join(""));
  }
  for (; i < args2.length; i++) {
    const arg = args2[i];
    if (!(arg instanceof Symbol)) {
      logArgs.push(arg);
    }
  }
  return logArgs;
};
var computeLoggingArgs = supportsColor ? computeBrowserLoggingArgs : computeNoColorLoggingArgs;
var print = (...args2) => {
  console.log(...computeLoggingArgs(args2));
  vconsoles.forEach((vc) => vc.print(args2));
};
var warn = (...args2) => {
  console.warn(...computeLoggingArgs(args2));
  args2.unshift(ORANGE);
  vconsoles.forEach((vc) => vc.print(args2));
};
var vconsoles = create2();

var createIterator = (next) => ({
  /**
   * @return {IterableIterator<T>}
   */
  [Symbol.iterator]() {
    return this;
  },
  // @ts-ignore
  next
});
var iteratorFilter = (iterator, filter) => createIterator(() => {
  let res;
  do {
    res = iterator.next();
  } while (!res.done && !filter(res.value));
  return res;
});
var iteratorMap = (iterator, fmap) => createIterator(() => {
  const { done, value } = iterator.next();
  return { done, value: done ? void 0 : fmap(value) };
});

var DeleteItem = class {
  /**
   * @param {number} clock
   * @param {number} len
   */
  constructor(clock, len) {
    this.clock = clock;
    this.len = len;
  }
};
var DeleteSet = class {
  constructor() {
    this.clients = /* @__PURE__ */ new Map();
  }
};
var iterateDeletedStructs = (transaction, ds, f) => ds.clients.forEach((deletes, clientid) => {
  const structs = (
    /** @type {Array<GC|Item>} */
    transaction.doc.store.clients.get(clientid)
  );
  if (structs != null) {
    const lastStruct = structs[structs.length - 1];
    const clockState = lastStruct.id.clock + lastStruct.length;
    for (let i = 0, del = deletes[i]; i < deletes.length && del.clock < clockState; del = deletes[++i]) {
      iterateStructs(transaction, structs, del.clock, del.len, f);
    }
  }
});
var findIndexDS = (dis, clock) => {
  let left = 0;
  let right = dis.length - 1;
  while (left <= right) {
    const midindex = floor((left + right) / 2);
    const mid = dis[midindex];
    const midclock = mid.clock;
    if (midclock <= clock) {
      if (clock < midclock + mid.len) {
        return midindex;
      }
      left = midindex + 1;
    } else {
      right = midindex - 1;
    }
  }
  return null;
};
var isDeleted = (ds, id2) => {
  const dis = ds.clients.get(id2.client);
  return dis !== void 0 && findIndexDS(dis, id2.clock) !== null;
};
var sortAndMergeDeleteSet = (ds) => {
  ds.clients.forEach((dels) => {
    dels.sort((a, b) => a.clock - b.clock);
    let i, j;
    for (i = 1, j = 1; i < dels.length; i++) {
      const left = dels[j - 1];
      const right = dels[i];
      if (left.clock + left.len >= right.clock) {
        dels[j - 1] = new DeleteItem(left.clock, max(left.len, right.clock + right.len - left.clock));
      } else {
        if (j < i) {
          dels[j] = right;
        }
        j++;
      }
    }
    dels.length = j;
  });
};
var mergeDeleteSets = (dss) => {
  const merged = new DeleteSet();
  for (let dssI = 0; dssI < dss.length; dssI++) {
    dss[dssI].clients.forEach((delsLeft, client) => {
      if (!merged.clients.has(client)) {
        const dels = delsLeft.slice();
        for (let i = dssI + 1; i < dss.length; i++) {
          appendTo(dels, dss[i].clients.get(client) || []);
        }
        merged.clients.set(client, dels);
      }
    });
  }
  sortAndMergeDeleteSet(merged);
  return merged;
};
var addToDeleteSet = (ds, client, clock, length2) => {
  setIfUndefined(ds.clients, client, () => (
    /** @type {Array<DeleteItem>} */
    []
  )).push(new DeleteItem(clock, length2));
};
var createDeleteSet = () => new DeleteSet();
var createDeleteSetFromStructStore = (ss) => {
  const ds = createDeleteSet();
  ss.clients.forEach((structs, client) => {
    const dsitems = [];
    for (let i = 0; i < structs.length; i++) {
      const struct = structs[i];
      if (struct.deleted) {
        const clock = struct.id.clock;
        let len = struct.length;
        if (i + 1 < structs.length) {
          for (let next = structs[i + 1]; i + 1 < structs.length && next.deleted; next = structs[++i + 1]) {
            len += next.length;
          }
        }
        dsitems.push(new DeleteItem(clock, len));
      }
    }
    if (dsitems.length > 0) {
      ds.clients.set(client, dsitems);
    }
  });
  return ds;
};
var writeDeleteSet = (encoder, ds) => {
  writeVarUint(encoder.restEncoder, ds.clients.size);
  from(ds.clients.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, dsitems]) => {
    encoder.resetDsCurVal();
    writeVarUint(encoder.restEncoder, client);
    const len = dsitems.length;
    writeVarUint(encoder.restEncoder, len);
    for (let i = 0; i < len; i++) {
      const item = dsitems[i];
      encoder.writeDsClock(item.clock);
      encoder.writeDsLen(item.len);
    }
  });
};
var readDeleteSet = (decoder) => {
  const ds = new DeleteSet();
  const numClients = readVarUint(decoder.restDecoder);
  for (let i = 0; i < numClients; i++) {
    decoder.resetDsCurVal();
    const client = readVarUint(decoder.restDecoder);
    const numberOfDeletes = readVarUint(decoder.restDecoder);
    if (numberOfDeletes > 0) {
      const dsField = setIfUndefined(ds.clients, client, () => (
        /** @type {Array<DeleteItem>} */
        []
      ));
      for (let i2 = 0; i2 < numberOfDeletes; i2++) {
        dsField.push(new DeleteItem(decoder.readDsClock(), decoder.readDsLen()));
      }
    }
  }
  return ds;
};
var readAndApplyDeleteSet = (decoder, transaction, store) => {
  const unappliedDS = new DeleteSet();
  const numClients = readVarUint(decoder.restDecoder);
  for (let i = 0; i < numClients; i++) {
    decoder.resetDsCurVal();
    const client = readVarUint(decoder.restDecoder);
    const numberOfDeletes = readVarUint(decoder.restDecoder);
    const structs = store.clients.get(client) || [];
    const state = getState(store, client);
    for (let i2 = 0; i2 < numberOfDeletes; i2++) {
      const clock = decoder.readDsClock();
      const clockEnd = clock + decoder.readDsLen();
      if (clock < state) {
        if (state < clockEnd) {
          addToDeleteSet(unappliedDS, client, state, clockEnd - state);
        }
        let index = findIndexSS(structs, clock);
        let struct = structs[index];
        if (!struct.deleted && struct.id.clock < clock) {
          structs.splice(index + 1, 0, splitItem(transaction, struct, clock - struct.id.clock));
          index++;
        }
        while (index < structs.length) {
          struct = structs[index++];
          if (struct.id.clock < clockEnd) {
            if (!struct.deleted) {
              if (clockEnd < struct.id.clock + struct.length) {
                structs.splice(index, 0, splitItem(transaction, struct, clockEnd - struct.id.clock));
              }
              struct.delete(transaction);
            }
          } else {
            break;
          }
        }
      } else {
        addToDeleteSet(unappliedDS, client, clock, clockEnd - clock);
      }
    }
  }
  if (unappliedDS.clients.size > 0) {
    const ds = new UpdateEncoderV2();
    writeVarUint(ds.restEncoder, 0);
    writeDeleteSet(ds, unappliedDS);
    return ds.toUint8Array();
  }
  return null;
};
var generateNewClientId = uint32;
var Doc = class _Doc extends ObservableV2 {
  /**
   * @param {DocOpts} opts configuration
   */
  constructor({ guid = uuidv4(), collectionid = null, gc = true, gcFilter = () => true, meta = null, autoLoad = false, shouldLoad = true } = {}) {
    super();
    this.gc = gc;
    this.gcFilter = gcFilter;
    this.clientID = generateNewClientId();
    this.guid = guid;
    this.collectionid = collectionid;
    this.share = /* @__PURE__ */ new Map();
    this.store = new StructStore();
    this._transaction = null;
    this._transactionCleanups = [];
    this.subdocs = /* @__PURE__ */ new Set();
    this._item = null;
    this.shouldLoad = shouldLoad;
    this.autoLoad = autoLoad;
    this.meta = meta;
    this.isLoaded = false;
    this.isSynced = false;
    this.isDestroyed = false;
    this.whenLoaded = create4((resolve) => {
      this.on("load", () => {
        this.isLoaded = true;
        resolve(this);
      });
    });
    const provideSyncedPromise = () => create4((resolve) => {
      const eventHandler = (isSynced) => {
        if (isSynced === void 0 || isSynced === true) {
          this.off("sync", eventHandler);
          resolve();
        }
      };
      this.on("sync", eventHandler);
    });
    this.on("sync", (isSynced) => {
      if (isSynced === false && this.isSynced) {
        this.whenSynced = provideSyncedPromise();
      }
      this.isSynced = isSynced === void 0 || isSynced === true;
      if (this.isSynced && !this.isLoaded) {
        this.emit("load", [this]);
      }
    });
    this.whenSynced = provideSyncedPromise();
  }
  /**
   * Notify the parent document that you request to load data into this subdocument (if it is a subdocument).
   *
   * `load()` might be used in the future to request any provider to load the most current data.
   *
   * It is safe to call `load()` multiple times.
   */
  load() {
    const item = this._item;
    if (item !== null && !this.shouldLoad) {
      transact(
        /** @type {any} */
        item.parent.doc,
        (transaction) => {
          transaction.subdocsLoaded.add(this);
        },
        null,
        true
      );
    }
    this.shouldLoad = true;
  }
  getSubdocs() {
    return this.subdocs;
  }
  getSubdocGuids() {
    return new Set(from(this.subdocs).map((doc2) => doc2.guid));
  }
  /**
   * Changes that happen inside of a transaction are bundled. This means that
   * the observer fires _after_ the transaction is finished and that all changes
   * that happened inside of the transaction are sent as one message to the
   * other peers.
   *
   * @template T
   * @param {function(Transaction):T} f The function that should be executed as a transaction
   * @param {any} [origin] Origin of who started the transaction. Will be stored on transaction.origin
   * @return T
   *
   * @public
   */
  transact(f, origin = null) {
    return transact(this, f, origin);
  }
  /**
   * Define a shared data type.
   *
   * Multiple calls of `ydoc.get(name, TypeConstructor)` yield the same result
   * and do not overwrite each other. I.e.
   * `ydoc.get(name, Y.Array) === ydoc.get(name, Y.Array)`
   *
   * After this method is called, the type is also available on `ydoc.share.get(name)`.
   *
   * *Best Practices:*
   * Define all types right after the Y.Doc instance is created and store them in a separate object.
   * Also use the typed methods `getText(name)`, `getArray(name)`, ..
   *
   * @template {typeof AbstractType<any>} Type
   * @example
   *   const ydoc = new Y.Doc(..)
   *   const appState = {
   *     document: ydoc.getText('document')
   *     comments: ydoc.getArray('comments')
   *   }
   *
   * @param {string} name
   * @param {Type} TypeConstructor The constructor of the type definition. E.g. Y.Text, Y.Array, Y.Map, ...
   * @return {InstanceType<Type>} The created type. Constructed with TypeConstructor
   *
   * @public
   */
  get(name, TypeConstructor = (
    /** @type {any} */
    AbstractType
  )) {
    const type = setIfUndefined(this.share, name, () => {
      const t = new TypeConstructor();
      t._integrate(this, null);
      return t;
    });
    const Constr = type.constructor;
    if (TypeConstructor !== AbstractType && Constr !== TypeConstructor) {
      if (Constr === AbstractType) {
        const t = new TypeConstructor();
        t._map = type._map;
        type._map.forEach(
          /** @param {Item?} n */
          (n) => {
            for (; n !== null; n = n.left) {
              n.parent = t;
            }
          }
        );
        t._start = type._start;
        for (let n = t._start; n !== null; n = n.right) {
          n.parent = t;
        }
        t._length = type._length;
        this.share.set(name, t);
        t._integrate(this, null);
        return (
          /** @type {InstanceType<Type>} */
          t
        );
      } else {
        throw new Error(`Type with the name ${name} has already been defined with a different constructor`);
      }
    }
    return (
      /** @type {InstanceType<Type>} */
      type
    );
  }
  /**
   * @template T
   * @param {string} [name]
   * @return {YArray<T>}
   *
   * @public
   */
  getArray(name = "") {
    return (
      /** @type {YArray<T>} */
      this.get(name, YArray)
    );
  }
  /**
   * @param {string} [name]
   * @return {YText}
   *
   * @public
   */
  getText(name = "") {
    return this.get(name, YText);
  }
  /**
   * @template T
   * @param {string} [name]
   * @return {YMap<T>}
   *
   * @public
   */
  getMap(name = "") {
    return (
      /** @type {YMap<T>} */
      this.get(name, YMap)
    );
  }
  /**
   * @param {string} [name]
   * @return {YXmlElement}
   *
   * @public
   */
  getXmlElement(name = "") {
    return (
      /** @type {YXmlElement<{[key:string]:string}>} */
      this.get(name, YXmlElement)
    );
  }
  /**
   * @param {string} [name]
   * @return {YXmlFragment}
   *
   * @public
   */
  getXmlFragment(name = "") {
    return this.get(name, YXmlFragment);
  }
  /**
   * Converts the entire document into a js object, recursively traversing each yjs type
   * Doesn't log types that have not been defined (using ydoc.getType(..)).
   *
   * @deprecated Do not use this method and rather call toJSON directly on the shared types.
   *
   * @return {Object<string, any>}
   */
  toJSON() {
    const doc2 = {};
    this.share.forEach((value, key) => {
      doc2[key] = value.toJSON();
    });
    return doc2;
  }
  /**
   * Emit `destroy` event and unregister all event handlers.
   */
  destroy() {
    this.isDestroyed = true;
    from(this.subdocs).forEach((subdoc) => subdoc.destroy());
    const item = this._item;
    if (item !== null) {
      this._item = null;
      const content2 = (
        /** @type {ContentDoc} */
        item.content
      );
      content2.doc = new _Doc({ guid: this.guid, ...content2.opts, shouldLoad: false });
      content2.doc._item = item;
      transact(
        /** @type {any} */
        item.parent.doc,
        (transaction) => {
          const doc2 = content2.doc;
          if (!item.deleted) {
            transaction.subdocsAdded.add(doc2);
          }
          transaction.subdocsRemoved.add(this);
        },
        null,
        true
      );
    }
    this.emit("destroyed", [true]);
    this.emit("destroy", [this]);
    super.destroy();
  }
};
var DSDecoderV1 = class {
  /**
   * @param {decoding.Decoder} decoder
   */
  constructor(decoder) {
    this.restDecoder = decoder;
  }
  resetDsCurVal() {
  }
  /**
   * @return {number}
   */
  readDsClock() {
    return readVarUint(this.restDecoder);
  }
  /**
   * @return {number}
   */
  readDsLen() {
    return readVarUint(this.restDecoder);
  }
};
var UpdateDecoderV1 = class extends DSDecoderV1 {
  /**
   * @return {ID}
   */
  readLeftID() {
    return createID(readVarUint(this.restDecoder), readVarUint(this.restDecoder));
  }
  /**
   * @return {ID}
   */
  readRightID() {
    return createID(readVarUint(this.restDecoder), readVarUint(this.restDecoder));
  }
  /**
   * Read the next client id.
   * Use this in favor of readID whenever possible to reduce the number of objects created.
   */
  readClient() {
    return readVarUint(this.restDecoder);
  }
  /**
   * @return {number} info An unsigned 8-bit integer
   */
  readInfo() {
    return readUint8(this.restDecoder);
  }
  /**
   * @return {string}
   */
  readString() {
    return readVarString(this.restDecoder);
  }
  /**
   * @return {boolean} isKey
   */
  readParentInfo() {
    return readVarUint(this.restDecoder) === 1;
  }
  /**
   * @return {number} info An unsigned 8-bit integer
   */
  readTypeRef() {
    return readVarUint(this.restDecoder);
  }
  /**
   * Write len of a struct - well suited for Opt RLE encoder.
   *
   * @return {number} len
   */
  readLen() {
    return readVarUint(this.restDecoder);
  }
  /**
   * @return {any}
   */
  readAny() {
    return readAny(this.restDecoder);
  }
  /**
   * @return {Uint8Array}
   */
  readBuf() {
    return copyUint8Array(readVarUint8Array(this.restDecoder));
  }
  /**
   * Legacy implementation uses JSON parse. We use any-decoding in v2.
   *
   * @return {any}
   */
  readJSON() {
    return JSON.parse(readVarString(this.restDecoder));
  }
  /**
   * @return {string}
   */
  readKey() {
    return readVarString(this.restDecoder);
  }
};
var DSDecoderV2 = class {
  /**
   * @param {decoding.Decoder} decoder
   */
  constructor(decoder) {
    this.dsCurrVal = 0;
    this.restDecoder = decoder;
  }
  resetDsCurVal() {
    this.dsCurrVal = 0;
  }
  /**
   * @return {number}
   */
  readDsClock() {
    this.dsCurrVal += readVarUint(this.restDecoder);
    return this.dsCurrVal;
  }
  /**
   * @return {number}
   */
  readDsLen() {
    const diff = readVarUint(this.restDecoder) + 1;
    this.dsCurrVal += diff;
    return diff;
  }
};
var UpdateDecoderV2 = class extends DSDecoderV2 {
  /**
   * @param {decoding.Decoder} decoder
   */
  constructor(decoder) {
    super(decoder);
    this.keys = [];
    readVarUint(decoder);
    this.keyClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
    this.clientDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
    this.leftClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
    this.rightClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
    this.infoDecoder = new RleDecoder(readVarUint8Array(decoder), readUint8);
    this.stringDecoder = new StringDecoder(readVarUint8Array(decoder));
    this.parentInfoDecoder = new RleDecoder(readVarUint8Array(decoder), readUint8);
    this.typeRefDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
    this.lenDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
  }
  /**
   * @return {ID}
   */
  readLeftID() {
    return new ID(this.clientDecoder.read(), this.leftClockDecoder.read());
  }
  /**
   * @return {ID}
   */
  readRightID() {
    return new ID(this.clientDecoder.read(), this.rightClockDecoder.read());
  }
  /**
   * Read the next client id.
   * Use this in favor of readID whenever possible to reduce the number of objects created.
   */
  readClient() {
    return this.clientDecoder.read();
  }
  /**
   * @return {number} info An unsigned 8-bit integer
   */
  readInfo() {
    return (
      /** @type {number} */
      this.infoDecoder.read()
    );
  }
  /**
   * @return {string}
   */
  readString() {
    return this.stringDecoder.read();
  }
  /**
   * @return {boolean}
   */
  readParentInfo() {
    return this.parentInfoDecoder.read() === 1;
  }
  /**
   * @return {number} An unsigned 8-bit integer
   */
  readTypeRef() {
    return this.typeRefDecoder.read();
  }
  /**
   * Write len of a struct - well suited for Opt RLE encoder.
   *
   * @return {number}
   */
  readLen() {
    return this.lenDecoder.read();
  }
  /**
   * @return {any}
   */
  readAny() {
    return readAny(this.restDecoder);
  }
  /**
   * @return {Uint8Array}
   */
  readBuf() {
    return readVarUint8Array(this.restDecoder);
  }
  /**
   * This is mainly here for legacy purposes.
   *
   * Initial we incoded objects using JSON. Now we use the much faster lib0/any-encoder. This method mainly exists for legacy purposes for the v1 encoder.
   *
   * @return {any}
   */
  readJSON() {
    return readAny(this.restDecoder);
  }
  /**
   * @return {string}
   */
  readKey() {
    const keyClock = this.keyClockDecoder.read();
    if (keyClock < this.keys.length) {
      return this.keys[keyClock];
    } else {
      const key = this.stringDecoder.read();
      this.keys.push(key);
      return key;
    }
  }
};
var DSEncoderV1 = class {
  constructor() {
    this.restEncoder = createEncoder();
  }
  toUint8Array() {
    return toUint8Array(this.restEncoder);
  }
  resetDsCurVal() {
  }
  /**
   * @param {number} clock
   */
  writeDsClock(clock) {
    writeVarUint(this.restEncoder, clock);
  }
  /**
   * @param {number} len
   */
  writeDsLen(len) {
    writeVarUint(this.restEncoder, len);
  }
};
var UpdateEncoderV1 = class extends DSEncoderV1 {
  /**
   * @param {ID} id
   */
  writeLeftID(id2) {
    writeVarUint(this.restEncoder, id2.client);
    writeVarUint(this.restEncoder, id2.clock);
  }
  /**
   * @param {ID} id
   */
  writeRightID(id2) {
    writeVarUint(this.restEncoder, id2.client);
    writeVarUint(this.restEncoder, id2.clock);
  }
  /**
   * Use writeClient and writeClock instead of writeID if possible.
   * @param {number} client
   */
  writeClient(client) {
    writeVarUint(this.restEncoder, client);
  }
  /**
   * @param {number} info An unsigned 8-bit integer
   */
  writeInfo(info) {
    writeUint8(this.restEncoder, info);
  }
  /**
   * @param {string} s
   */
  writeString(s) {
    writeVarString(this.restEncoder, s);
  }
  /**
   * @param {boolean} isYKey
   */
  writeParentInfo(isYKey) {
    writeVarUint(this.restEncoder, isYKey ? 1 : 0);
  }
  /**
   * @param {number} info An unsigned 8-bit integer
   */
  writeTypeRef(info) {
    writeVarUint(this.restEncoder, info);
  }
  /**
   * Write len of a struct - well suited for Opt RLE encoder.
   *
   * @param {number} len
   */
  writeLen(len) {
    writeVarUint(this.restEncoder, len);
  }
  /**
   * @param {any} any
   */
  writeAny(any2) {
    writeAny(this.restEncoder, any2);
  }
  /**
   * @param {Uint8Array} buf
   */
  writeBuf(buf) {
    writeVarUint8Array(this.restEncoder, buf);
  }
  /**
   * @param {any} embed
   */
  writeJSON(embed) {
    writeVarString(this.restEncoder, JSON.stringify(embed));
  }
  /**
   * @param {string} key
   */
  writeKey(key) {
    writeVarString(this.restEncoder, key);
  }
};
var DSEncoderV2 = class {
  constructor() {
    this.restEncoder = createEncoder();
    this.dsCurrVal = 0;
  }
  toUint8Array() {
    return toUint8Array(this.restEncoder);
  }
  resetDsCurVal() {
    this.dsCurrVal = 0;
  }
  /**
   * @param {number} clock
   */
  writeDsClock(clock) {
    const diff = clock - this.dsCurrVal;
    this.dsCurrVal = clock;
    writeVarUint(this.restEncoder, diff);
  }
  /**
   * @param {number} len
   */
  writeDsLen(len) {
    if (len === 0) {
      unexpectedCase();
    }
    writeVarUint(this.restEncoder, len - 1);
    this.dsCurrVal += len;
  }
};
var UpdateEncoderV2 = class extends DSEncoderV2 {
  constructor() {
    super();
    this.keyMap = /* @__PURE__ */ new Map();
    this.keyClock = 0;
    this.keyClockEncoder = new IntDiffOptRleEncoder();
    this.clientEncoder = new UintOptRleEncoder();
    this.leftClockEncoder = new IntDiffOptRleEncoder();
    this.rightClockEncoder = new IntDiffOptRleEncoder();
    this.infoEncoder = new RleEncoder(writeUint8);
    this.stringEncoder = new StringEncoder();
    this.parentInfoEncoder = new RleEncoder(writeUint8);
    this.typeRefEncoder = new UintOptRleEncoder();
    this.lenEncoder = new UintOptRleEncoder();
  }
  toUint8Array() {
    const encoder = createEncoder();
    writeVarUint(encoder, 0);
    writeVarUint8Array(encoder, this.keyClockEncoder.toUint8Array());
    writeVarUint8Array(encoder, this.clientEncoder.toUint8Array());
    writeVarUint8Array(encoder, this.leftClockEncoder.toUint8Array());
    writeVarUint8Array(encoder, this.rightClockEncoder.toUint8Array());
    writeVarUint8Array(encoder, toUint8Array(this.infoEncoder));
    writeVarUint8Array(encoder, this.stringEncoder.toUint8Array());
    writeVarUint8Array(encoder, toUint8Array(this.parentInfoEncoder));
    writeVarUint8Array(encoder, this.typeRefEncoder.toUint8Array());
    writeVarUint8Array(encoder, this.lenEncoder.toUint8Array());
    writeUint8Array(encoder, toUint8Array(this.restEncoder));
    return toUint8Array(encoder);
  }
  /**
   * @param {ID} id
   */
  writeLeftID(id2) {
    this.clientEncoder.write(id2.client);
    this.leftClockEncoder.write(id2.clock);
  }
  /**
   * @param {ID} id
   */
  writeRightID(id2) {
    this.clientEncoder.write(id2.client);
    this.rightClockEncoder.write(id2.clock);
  }
  /**
   * @param {number} client
   */
  writeClient(client) {
    this.clientEncoder.write(client);
  }
  /**
   * @param {number} info An unsigned 8-bit integer
   */
  writeInfo(info) {
    this.infoEncoder.write(info);
  }
  /**
   * @param {string} s
   */
  writeString(s) {
    this.stringEncoder.write(s);
  }
  /**
   * @param {boolean} isYKey
   */
  writeParentInfo(isYKey) {
    this.parentInfoEncoder.write(isYKey ? 1 : 0);
  }
  /**
   * @param {number} info An unsigned 8-bit integer
   */
  writeTypeRef(info) {
    this.typeRefEncoder.write(info);
  }
  /**
   * Write len of a struct - well suited for Opt RLE encoder.
   *
   * @param {number} len
   */
  writeLen(len) {
    this.lenEncoder.write(len);
  }
  /**
   * @param {any} any
   */
  writeAny(any2) {
    writeAny(this.restEncoder, any2);
  }
  /**
   * @param {Uint8Array} buf
   */
  writeBuf(buf) {
    writeVarUint8Array(this.restEncoder, buf);
  }
  /**
   * This is mainly here for legacy purposes.
   *
   * Initial we incoded objects using JSON. Now we use the much faster lib0/any-encoder. This method mainly exists for legacy purposes for the v1 encoder.
   *
   * @param {any} embed
   */
  writeJSON(embed) {
    writeAny(this.restEncoder, embed);
  }
  /**
   * Property keys are often reused. For example, in y-prosemirror the key `bold` might
   * occur very often. For a 3d application, the key `position` might occur very often.
   *
   * We cache these keys in a Map and refer to them via a unique number.
   *
   * @param {string} key
   */
  writeKey(key) {
    const clock = this.keyMap.get(key);
    if (clock === void 0) {
      this.keyClockEncoder.write(this.keyClock++);
      this.stringEncoder.write(key);
    } else {
      this.keyClockEncoder.write(clock);
    }
  }
};
var writeStructs = (encoder, structs, client, clock) => {
  clock = max(clock, structs[0].id.clock);
  const startNewStructs = findIndexSS(structs, clock);
  writeVarUint(encoder.restEncoder, structs.length - startNewStructs);
  encoder.writeClient(client);
  writeVarUint(encoder.restEncoder, clock);
  const firstStruct = structs[startNewStructs];
  firstStruct.write(encoder, clock - firstStruct.id.clock);
  for (let i = startNewStructs + 1; i < structs.length; i++) {
    structs[i].write(encoder, 0);
  }
};
var writeClientsStructs = (encoder, store, _sm) => {
  const sm = /* @__PURE__ */ new Map();
  _sm.forEach((clock, client) => {
    if (getState(store, client) > clock) {
      sm.set(client, clock);
    }
  });
  getStateVector(store).forEach((_clock, client) => {
    if (!_sm.has(client)) {
      sm.set(client, 0);
    }
  });
  writeVarUint(encoder.restEncoder, sm.size);
  from(sm.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, clock]) => {
    writeStructs(
      encoder,
      /** @type {Array<GC|Item>} */
      store.clients.get(client),
      client,
      clock
    );
  });
};
var readClientsStructRefs = (decoder, doc2) => {
  const clientRefs = create();
  const numOfStateUpdates = readVarUint(decoder.restDecoder);
  for (let i = 0; i < numOfStateUpdates; i++) {
    const numberOfStructs = readVarUint(decoder.restDecoder);
    const refs = new Array(numberOfStructs);
    const client = decoder.readClient();
    let clock = readVarUint(decoder.restDecoder);
    clientRefs.set(client, { i: 0, refs });
    for (let i2 = 0; i2 < numberOfStructs; i2++) {
      const info = decoder.readInfo();
      switch (BITS5 & info) {
        case 0: {
          const len = decoder.readLen();
          refs[i2] = new GC(createID(client, clock), len);
          clock += len;
          break;
        }
        case 10: {
          const len = readVarUint(decoder.restDecoder);
          refs[i2] = new Skip(createID(client, clock), len);
          clock += len;
          break;
        }
        default: {
          const cantCopyParentInfo = (info & (BIT7 | BIT8)) === 0;
          const struct = new Item(
            createID(client, clock),
            null,
            // left
            (info & BIT8) === BIT8 ? decoder.readLeftID() : null,
            // origin
            null,
            // right
            (info & BIT7) === BIT7 ? decoder.readRightID() : null,
            // right origin
            cantCopyParentInfo ? decoder.readParentInfo() ? doc2.get(decoder.readString()) : decoder.readLeftID() : null,
            // parent
            cantCopyParentInfo && (info & BIT6) === BIT6 ? decoder.readString() : null,
            // parentSub
            readItemContent(decoder, info)
            // item content
          );
          refs[i2] = struct;
          clock += struct.length;
        }
      }
    }
  }
  return clientRefs;
};
var integrateStructs = (transaction, store, clientsStructRefs) => {
  const stack = [];
  let clientsStructRefsIds = from(clientsStructRefs.keys()).sort((a, b) => a - b);
  if (clientsStructRefsIds.length === 0) {
    return null;
  }
  const getNextStructTarget = () => {
    if (clientsStructRefsIds.length === 0) {
      return null;
    }
    let nextStructsTarget = (
      /** @type {{i:number,refs:Array<GC|Item>}} */
      clientsStructRefs.get(clientsStructRefsIds[clientsStructRefsIds.length - 1])
    );
    while (nextStructsTarget.refs.length === nextStructsTarget.i) {
      clientsStructRefsIds.pop();
      if (clientsStructRefsIds.length > 0) {
        nextStructsTarget = /** @type {{i:number,refs:Array<GC|Item>}} */
        clientsStructRefs.get(clientsStructRefsIds[clientsStructRefsIds.length - 1]);
      } else {
        return null;
      }
    }
    return nextStructsTarget;
  };
  let curStructsTarget = getNextStructTarget();
  if (curStructsTarget === null) {
    return null;
  }
  const restStructs = new StructStore();
  const missingSV = /* @__PURE__ */ new Map();
  const updateMissingSv = (client, clock) => {
    const mclock = missingSV.get(client);
    if (mclock == null || mclock > clock) {
      missingSV.set(client, clock);
    }
  };
  let stackHead = (
    /** @type {any} */
    curStructsTarget.refs[
      /** @type {any} */
      curStructsTarget.i++
    ]
  );
  const state = /* @__PURE__ */ new Map();
  const addStackToRestSS = () => {
    for (const item of stack) {
      const client = item.id.client;
      const inapplicableItems = clientsStructRefs.get(client);
      if (inapplicableItems) {
        inapplicableItems.i--;
        restStructs.clients.set(client, inapplicableItems.refs.slice(inapplicableItems.i));
        clientsStructRefs.delete(client);
        inapplicableItems.i = 0;
        inapplicableItems.refs = [];
      } else {
        restStructs.clients.set(client, [item]);
      }
      clientsStructRefsIds = clientsStructRefsIds.filter((c) => c !== client);
    }
    stack.length = 0;
  };
  while (true) {
    if (stackHead.constructor !== Skip) {
      const localClock = setIfUndefined(state, stackHead.id.client, () => getState(store, stackHead.id.client));
      const offset = localClock - stackHead.id.clock;
      if (offset < 0) {
        stack.push(stackHead);
        updateMissingSv(stackHead.id.client, stackHead.id.clock - 1);
        addStackToRestSS();
      } else {
        const missing = stackHead.getMissing(transaction, store);
        if (missing !== null) {
          stack.push(stackHead);
          const structRefs = clientsStructRefs.get(
            /** @type {number} */
            missing
          ) || { refs: [], i: 0 };
          if (structRefs.refs.length === structRefs.i) {
            updateMissingSv(
              /** @type {number} */
              missing,
              getState(store, missing)
            );
            addStackToRestSS();
          } else {
            stackHead = structRefs.refs[structRefs.i++];
            continue;
          }
        } else if (offset === 0 || offset < stackHead.length) {
          stackHead.integrate(transaction, offset);
          state.set(stackHead.id.client, stackHead.id.clock + stackHead.length);
        }
      }
    }
    if (stack.length > 0) {
      stackHead = /** @type {GC|Item} */
      stack.pop();
    } else if (curStructsTarget !== null && curStructsTarget.i < curStructsTarget.refs.length) {
      stackHead = /** @type {GC|Item} */
      curStructsTarget.refs[curStructsTarget.i++];
    } else {
      curStructsTarget = getNextStructTarget();
      if (curStructsTarget === null) {
        break;
      } else {
        stackHead = /** @type {GC|Item} */
        curStructsTarget.refs[curStructsTarget.i++];
      }
    }
  }
  if (restStructs.clients.size > 0) {
    const encoder = new UpdateEncoderV2();
    writeClientsStructs(encoder, restStructs, /* @__PURE__ */ new Map());
    writeVarUint(encoder.restEncoder, 0);
    return { missing: missingSV, update: encoder.toUint8Array() };
  }
  return null;
};
var writeStructsFromTransaction = (encoder, transaction) => writeClientsStructs(encoder, transaction.doc.store, transaction.beforeState);
var readUpdateV2 = (decoder, ydoc, transactionOrigin, structDecoder = new UpdateDecoderV2(decoder)) => transact(ydoc, (transaction) => {
  transaction.local = false;
  let retry = false;
  const doc2 = transaction.doc;
  const store = doc2.store;
  const ss = readClientsStructRefs(structDecoder, doc2);
  const restStructs = integrateStructs(transaction, store, ss);
  const pending = store.pendingStructs;
  if (pending) {
    for (const [client, clock] of pending.missing) {
      if (clock < getState(store, client)) {
        retry = true;
        break;
      }
    }
    if (restStructs) {
      for (const [client, clock] of restStructs.missing) {
        const mclock = pending.missing.get(client);
        if (mclock == null || mclock > clock) {
          pending.missing.set(client, clock);
        }
      }
      pending.update = mergeUpdatesV2([pending.update, restStructs.update]);
    }
  } else {
    store.pendingStructs = restStructs;
  }
  const dsRest = readAndApplyDeleteSet(structDecoder, transaction, store);
  if (store.pendingDs) {
    const pendingDSUpdate = new UpdateDecoderV2(createDecoder(store.pendingDs));
    readVarUint(pendingDSUpdate.restDecoder);
    const dsRest2 = readAndApplyDeleteSet(pendingDSUpdate, transaction, store);
    if (dsRest && dsRest2) {
      store.pendingDs = mergeUpdatesV2([dsRest, dsRest2]);
    } else {
      store.pendingDs = dsRest || dsRest2;
    }
  } else {
    store.pendingDs = dsRest;
  }
  if (retry) {
    const update = (
      /** @type {{update: Uint8Array}} */
      store.pendingStructs.update
    );
    store.pendingStructs = null;
    applyUpdateV2(transaction.doc, update);
  }
}, transactionOrigin, false);
var applyUpdateV2 = (ydoc, update, transactionOrigin, YDecoder = UpdateDecoderV2) => {
  const decoder = createDecoder(update);
  readUpdateV2(decoder, ydoc, transactionOrigin, new YDecoder(decoder));
};
var applyUpdate = (ydoc, update, transactionOrigin) => applyUpdateV2(ydoc, update, transactionOrigin, UpdateDecoderV1);
var writeStateAsUpdate = (encoder, doc2, targetStateVector = /* @__PURE__ */ new Map()) => {
  writeClientsStructs(encoder, doc2.store, targetStateVector);
  writeDeleteSet(encoder, createDeleteSetFromStructStore(doc2.store));
};
var encodeStateAsUpdateV2 = (doc2, encodedTargetStateVector = new Uint8Array([0]), encoder = new UpdateEncoderV2()) => {
  const targetStateVector = decodeStateVector(encodedTargetStateVector);
  writeStateAsUpdate(encoder, doc2, targetStateVector);
  const updates = [encoder.toUint8Array()];
  if (doc2.store.pendingDs) {
    updates.push(doc2.store.pendingDs);
  }
  if (doc2.store.pendingStructs) {
    updates.push(diffUpdateV2(doc2.store.pendingStructs.update, encodedTargetStateVector));
  }
  if (updates.length > 1) {
    if (encoder.constructor === UpdateEncoderV1) {
      return mergeUpdates(updates.map((update, i) => i === 0 ? update : convertUpdateFormatV2ToV1(update)));
    } else if (encoder.constructor === UpdateEncoderV2) {
      return mergeUpdatesV2(updates);
    }
  }
  return updates[0];
};
var encodeStateAsUpdate = (doc2, encodedTargetStateVector) => encodeStateAsUpdateV2(doc2, encodedTargetStateVector, new UpdateEncoderV1());
var readStateVector = (decoder) => {
  const ss = /* @__PURE__ */ new Map();
  const ssLength = readVarUint(decoder.restDecoder);
  for (let i = 0; i < ssLength; i++) {
    const client = readVarUint(decoder.restDecoder);
    const clock = readVarUint(decoder.restDecoder);
    ss.set(client, clock);
  }
  return ss;
};
var decodeStateVector = (decodedState) => readStateVector(new DSDecoderV1(createDecoder(decodedState)));
var writeStateVector = (encoder, sv) => {
  writeVarUint(encoder.restEncoder, sv.size);
  from(sv.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, clock]) => {
    writeVarUint(encoder.restEncoder, client);
    writeVarUint(encoder.restEncoder, clock);
  });
  return encoder;
};
var writeDocumentStateVector = (encoder, doc2) => writeStateVector(encoder, getStateVector(doc2.store));
var encodeStateVectorV2 = (doc2, encoder = new DSEncoderV2()) => {
  if (doc2 instanceof Map) {
    writeStateVector(encoder, doc2);
  } else {
    writeDocumentStateVector(encoder, doc2);
  }
  return encoder.toUint8Array();
};
var encodeStateVector = (doc2) => encodeStateVectorV2(doc2, new DSEncoderV1());
var EventHandler = class {
  constructor() {
    this.l = [];
  }
};
var createEventHandler = () => new EventHandler();
var addEventHandlerListener = (eventHandler, f) => eventHandler.l.push(f);
var removeEventHandlerListener = (eventHandler, f) => {
  const l = eventHandler.l;
  const len = l.length;
  eventHandler.l = l.filter((g) => f !== g);
  if (len === eventHandler.l.length) {
    console.error("[yjs] Tried to remove event handler that doesn't exist.");
  }
};
var callEventHandlerListeners = (eventHandler, arg0, arg1) => callAll(eventHandler.l, [arg0, arg1]);
var ID = class {
  /**
   * @param {number} client client id
   * @param {number} clock unique per client id, continuous number
   */
  constructor(client, clock) {
    this.client = client;
    this.clock = clock;
  }
};
var compareIDs = (a, b) => a === b || a !== null && b !== null && a.client === b.client && a.clock === b.clock;
var createID = (client, clock) => new ID(client, clock);
var findRootTypeKey = (type) => {
  for (const [key, value] of type.doc.share.entries()) {
    if (value === type) {
      return key;
    }
  }
  throw unexpectedCase();
};
var isParentOf = (parent, child) => {
  while (child !== null) {
    if (child.parent === parent) {
      return true;
    }
    child = /** @type {AbstractType<any>} */
    child.parent._item;
  }
  return false;
};
var RelativePosition = class {
  /**
   * @param {ID|null} type
   * @param {string|null} tname
   * @param {ID|null} item
   * @param {number} assoc
   */
  constructor(type, tname, item, assoc = 0) {
    this.type = type;
    this.tname = tname;
    this.item = item;
    this.assoc = assoc;
  }
};
var relativePositionToJSON = (rpos) => {
  const json = {};
  if (rpos.type) {
    json.type = rpos.type;
  }
  if (rpos.tname) {
    json.tname = rpos.tname;
  }
  if (rpos.item) {
    json.item = rpos.item;
  }
  if (rpos.assoc != null) {
    json.assoc = rpos.assoc;
  }
  return json;
};
var createRelativePositionFromJSON = (json) => new RelativePosition(json.type == null ? null : createID(json.type.client, json.type.clock), json.tname ?? null, json.item == null ? null : createID(json.item.client, json.item.clock), json.assoc == null ? 0 : json.assoc);
var AbsolutePosition = class {
  /**
   * @param {AbstractType<any>} type
   * @param {number} index
   * @param {number} [assoc]
   */
  constructor(type, index, assoc = 0) {
    this.type = type;
    this.index = index;
    this.assoc = assoc;
  }
};
var createAbsolutePosition = (type, index, assoc = 0) => new AbsolutePosition(type, index, assoc);
var createRelativePosition = (type, item, assoc) => {
  let typeid = null;
  let tname = null;
  if (type._item === null) {
    tname = findRootTypeKey(type);
  } else {
    typeid = createID(type._item.id.client, type._item.id.clock);
  }
  return new RelativePosition(typeid, tname, item, assoc);
};
var createRelativePositionFromTypeIndex = (type, index, assoc = 0) => {
  let t = type._start;
  if (assoc < 0) {
    if (index === 0) {
      return createRelativePosition(type, null, assoc);
    }
    index--;
  }
  while (t !== null) {
    if (!t.deleted && t.countable) {
      if (t.length > index) {
        return createRelativePosition(type, createID(t.id.client, t.id.clock + index), assoc);
      }
      index -= t.length;
    }
    if (t.right === null && assoc < 0) {
      return createRelativePosition(type, t.lastId, assoc);
    }
    t = t.right;
  }
  return createRelativePosition(type, null, assoc);
};
var getItemWithOffset = (store, id2) => {
  const item = getItem(store, id2);
  const diff = id2.clock - item.id.clock;
  return {
    item,
    diff
  };
};
var createAbsolutePositionFromRelativePosition = (rpos, doc2, followUndoneDeletions = true) => {
  const store = doc2.store;
  const rightID = rpos.item;
  const typeID = rpos.type;
  const tname = rpos.tname;
  const assoc = rpos.assoc;
  let type = null;
  let index = 0;
  if (rightID !== null) {
    if (getState(store, rightID.client) <= rightID.clock) {
      return null;
    }
    const res = followUndoneDeletions ? followRedone(store, rightID) : getItemWithOffset(store, rightID);
    const right = res.item;
    if (!(right instanceof Item)) {
      return null;
    }
    type = /** @type {AbstractType<any>} */
    right.parent;
    if (type._item === null || !type._item.deleted) {
      index = right.deleted || !right.countable ? 0 : res.diff + (assoc >= 0 ? 0 : 1);
      let n = right.left;
      while (n !== null) {
        if (!n.deleted && n.countable) {
          index += n.length;
        }
        n = n.left;
      }
    }
  } else {
    if (tname !== null) {
      type = doc2.get(tname);
    } else if (typeID !== null) {
      if (getState(store, typeID.client) <= typeID.clock) {
        return null;
      }
      const { item } = followUndoneDeletions ? followRedone(store, typeID) : { item: getItem(store, typeID) };
      if (item instanceof Item && item.content instanceof ContentType) {
        type = item.content.type;
      } else {
        return null;
      }
    } else {
      throw unexpectedCase();
    }
    if (assoc >= 0) {
      index = type._length;
    } else {
      index = 0;
    }
  }
  return createAbsolutePosition(type, index, rpos.assoc);
};
var compareRelativePositions = (a, b) => a === b || a !== null && b !== null && a.tname === b.tname && compareIDs(a.item, b.item) && compareIDs(a.type, b.type) && a.assoc === b.assoc;
var Snapshot = class {
  /**
   * @param {DeleteSet} ds
   * @param {Map<number,number>} sv state map
   */
  constructor(ds, sv) {
    this.ds = ds;
    this.sv = sv;
  }
};
var createSnapshot = (ds, sm) => new Snapshot(ds, sm);
var emptySnapshot = createSnapshot(createDeleteSet(), /* @__PURE__ */ new Map());
var isVisible = (item, snapshot) => snapshot === void 0 ? !item.deleted : snapshot.sv.has(item.id.client) && (snapshot.sv.get(item.id.client) || 0) > item.id.clock && !isDeleted(snapshot.ds, item.id);
var splitSnapshotAffectedStructs = (transaction, snapshot) => {
  const meta = setIfUndefined(transaction.meta, splitSnapshotAffectedStructs, create2);
  const store = transaction.doc.store;
  if (!meta.has(snapshot)) {
    snapshot.sv.forEach((clock, client) => {
      if (clock < getState(store, client)) {
        getItemCleanStart(transaction, createID(client, clock));
      }
    });
    iterateDeletedStructs(transaction, snapshot.ds, (_item) => {
    });
    meta.add(snapshot);
  }
};
var StructStore = class {
  constructor() {
    this.clients = /* @__PURE__ */ new Map();
    this.pendingStructs = null;
    this.pendingDs = null;
  }
};
var getStateVector = (store) => {
  const sm = /* @__PURE__ */ new Map();
  store.clients.forEach((structs, client) => {
    const struct = structs[structs.length - 1];
    sm.set(client, struct.id.clock + struct.length);
  });
  return sm;
};
var getState = (store, client) => {
  const structs = store.clients.get(client);
  if (structs === void 0) {
    return 0;
  }
  const lastStruct = structs[structs.length - 1];
  return lastStruct.id.clock + lastStruct.length;
};
var addStruct = (store, struct) => {
  let structs = store.clients.get(struct.id.client);
  if (structs === void 0) {
    structs = [];
    store.clients.set(struct.id.client, structs);
  } else {
    const lastStruct = structs[structs.length - 1];
    if (lastStruct.id.clock + lastStruct.length !== struct.id.clock) {
      throw unexpectedCase();
    }
  }
  structs.push(struct);
};
var findIndexSS = (structs, clock) => {
  let left = 0;
  let right = structs.length - 1;
  let mid = structs[right];
  let midclock = mid.id.clock;
  if (midclock === clock) {
    return right;
  }
  let midindex = floor(clock / (midclock + mid.length - 1) * right);
  while (left <= right) {
    mid = structs[midindex];
    midclock = mid.id.clock;
    if (midclock <= clock) {
      if (clock < midclock + mid.length) {
        return midindex;
      }
      left = midindex + 1;
    } else {
      right = midindex - 1;
    }
    midindex = floor((left + right) / 2);
  }
  throw unexpectedCase();
};
var find = (store, id2) => {
  const structs = store.clients.get(id2.client);
  return structs[findIndexSS(structs, id2.clock)];
};
var getItem = (
  /** @type {function(StructStore,ID):Item} */
  find
);
var findIndexCleanStart = (transaction, structs, clock) => {
  const index = findIndexSS(structs, clock);
  const struct = structs[index];
  if (struct.id.clock < clock && struct instanceof Item) {
    structs.splice(index + 1, 0, splitItem(transaction, struct, clock - struct.id.clock));
    return index + 1;
  }
  return index;
};
var getItemCleanStart = (transaction, id2) => {
  const structs = (
    /** @type {Array<Item>} */
    transaction.doc.store.clients.get(id2.client)
  );
  return structs[findIndexCleanStart(transaction, structs, id2.clock)];
};
var getItemCleanEnd = (transaction, store, id2) => {
  const structs = store.clients.get(id2.client);
  const index = findIndexSS(structs, id2.clock);
  const struct = structs[index];
  if (id2.clock !== struct.id.clock + struct.length - 1 && struct.constructor !== GC) {
    structs.splice(index + 1, 0, splitItem(transaction, struct, id2.clock - struct.id.clock + 1));
  }
  return struct;
};
var replaceStruct = (store, struct, newStruct) => {
  const structs = (
    /** @type {Array<GC|Item>} */
    store.clients.get(struct.id.client)
  );
  structs[findIndexSS(structs, struct.id.clock)] = newStruct;
};
var iterateStructs = (transaction, structs, clockStart, len, f) => {
  if (len === 0) {
    return;
  }
  const clockEnd = clockStart + len;
  let index = findIndexCleanStart(transaction, structs, clockStart);
  let struct;
  do {
    struct = structs[index++];
    if (clockEnd < struct.id.clock + struct.length) {
      findIndexCleanStart(transaction, structs, clockEnd);
    }
    f(struct);
  } while (index < structs.length && structs[index].id.clock < clockEnd);
};
var Transaction = class {
  /**
   * @param {Doc} doc
   * @param {any} origin
   * @param {boolean} local
   */
  constructor(doc2, origin, local) {
    this.doc = doc2;
    this.deleteSet = new DeleteSet();
    this.beforeState = getStateVector(doc2.store);
    this.afterState = /* @__PURE__ */ new Map();
    this.changed = /* @__PURE__ */ new Map();
    this.changedParentTypes = /* @__PURE__ */ new Map();
    this._mergeStructs = [];
    this.origin = origin;
    this.meta = /* @__PURE__ */ new Map();
    this.local = local;
    this.subdocsAdded = /* @__PURE__ */ new Set();
    this.subdocsRemoved = /* @__PURE__ */ new Set();
    this.subdocsLoaded = /* @__PURE__ */ new Set();
    this._needFormattingCleanup = false;
  }
};
var writeUpdateMessageFromTransaction = (encoder, transaction) => {
  if (transaction.deleteSet.clients.size === 0 && !any(transaction.afterState, (clock, client) => transaction.beforeState.get(client) !== clock)) {
    return false;
  }
  sortAndMergeDeleteSet(transaction.deleteSet);
  writeStructsFromTransaction(encoder, transaction);
  writeDeleteSet(encoder, transaction.deleteSet);
  return true;
};
var addChangedTypeToTransaction = (transaction, type, parentSub) => {
  const item = type._item;
  if (item === null || item.id.clock < (transaction.beforeState.get(item.id.client) || 0) && !item.deleted) {
    setIfUndefined(transaction.changed, type, create2).add(parentSub);
  }
};
var tryToMergeWithLefts = (structs, pos) => {
  let right = structs[pos];
  let left = structs[pos - 1];
  let i = pos;
  for (; i > 0; right = left, left = structs[--i - 1]) {
    if (left.deleted === right.deleted && left.constructor === right.constructor) {
      if (left.mergeWith(right)) {
        if (right instanceof Item && right.parentSub !== null && /** @type {AbstractType<any>} */
        right.parent._map.get(right.parentSub) === right) {
          right.parent._map.set(
            right.parentSub,
            /** @type {Item} */
            left
          );
        }
        continue;
      }
    }
    break;
  }
  const merged = pos - i;
  if (merged) {
    structs.splice(pos + 1 - merged, merged);
  }
  return merged;
};
var tryGcDeleteSet = (ds, store, gcFilter) => {
  for (const [client, deleteItems] of ds.clients.entries()) {
    const structs = (
      /** @type {Array<GC|Item>} */
      store.clients.get(client)
    );
    for (let di = deleteItems.length - 1; di >= 0; di--) {
      const deleteItem = deleteItems[di];
      const endDeleteItemClock = deleteItem.clock + deleteItem.len;
      for (let si = findIndexSS(structs, deleteItem.clock), struct = structs[si]; si < structs.length && struct.id.clock < endDeleteItemClock; struct = structs[++si]) {
        const struct2 = structs[si];
        if (deleteItem.clock + deleteItem.len <= struct2.id.clock) {
          break;
        }
        if (struct2 instanceof Item && struct2.deleted && !struct2.keep && gcFilter(struct2)) {
          struct2.gc(store, false);
        }
      }
    }
  }
};
var tryMergeDeleteSet = (ds, store) => {
  ds.clients.forEach((deleteItems, client) => {
    const structs = (
      /** @type {Array<GC|Item>} */
      store.clients.get(client)
    );
    for (let di = deleteItems.length - 1; di >= 0; di--) {
      const deleteItem = deleteItems[di];
      const mostRightIndexToCheck = min(structs.length - 1, 1 + findIndexSS(structs, deleteItem.clock + deleteItem.len - 1));
      for (let si = mostRightIndexToCheck, struct = structs[si]; si > 0 && struct.id.clock >= deleteItem.clock; struct = structs[si]) {
        si -= 1 + tryToMergeWithLefts(structs, si);
      }
    }
  });
};
var cleanupTransactions = (transactionCleanups, i) => {
  if (i < transactionCleanups.length) {
    const transaction = transactionCleanups[i];
    const doc2 = transaction.doc;
    const store = doc2.store;
    const ds = transaction.deleteSet;
    const mergeStructs = transaction._mergeStructs;
    try {
      sortAndMergeDeleteSet(ds);
      transaction.afterState = getStateVector(transaction.doc.store);
      doc2.emit("beforeObserverCalls", [transaction, doc2]);
      const fs = [];
      transaction.changed.forEach(
        (subs, itemtype) => fs.push(() => {
          if (itemtype._item === null || !itemtype._item.deleted) {
            itemtype._callObserver(transaction, subs);
          }
        })
      );
      fs.push(() => {
        transaction.changedParentTypes.forEach((events, type) => {
          if (type._dEH.l.length > 0 && (type._item === null || !type._item.deleted)) {
            fs.push(() => {
              events = events.filter(
                (event) => event.target._item === null || !event.target._item.deleted
              );
              events.forEach((event) => {
                event.currentTarget = type;
                event._path = null;
              });
              events.sort((event1, event2) => event1.path.length - event2.path.length);
              callEventHandlerListeners(type._dEH, events, transaction);
            });
          }
        });
        fs.push(() => doc2.emit("afterTransaction", [transaction, doc2]));
        fs.push(() => {
          if (transaction._needFormattingCleanup) {
            cleanupYTextAfterTransaction(transaction);
          }
        });
      });
      callAll(fs, []);
    } finally {
      if (doc2.gc) {
        tryGcDeleteSet(ds, store, doc2.gcFilter);
      }
      tryMergeDeleteSet(ds, store);
      transaction.afterState.forEach((clock, client) => {
        const beforeClock = transaction.beforeState.get(client) || 0;
        if (beforeClock !== clock) {
          const structs = (
            /** @type {Array<GC|Item>} */
            store.clients.get(client)
          );
          const firstChangePos = max(findIndexSS(structs, beforeClock), 1);
          for (let i2 = structs.length - 1; i2 >= firstChangePos; ) {
            i2 -= 1 + tryToMergeWithLefts(structs, i2);
          }
        }
      });
      for (let i2 = mergeStructs.length - 1; i2 >= 0; i2--) {
        const { client, clock } = mergeStructs[i2].id;
        const structs = (
          /** @type {Array<GC|Item>} */
          store.clients.get(client)
        );
        const replacedStructPos = findIndexSS(structs, clock);
        if (replacedStructPos + 1 < structs.length) {
          if (tryToMergeWithLefts(structs, replacedStructPos + 1) > 1) {
            continue;
          }
        }
        if (replacedStructPos > 0) {
          tryToMergeWithLefts(structs, replacedStructPos);
        }
      }
      if (!transaction.local && transaction.afterState.get(doc2.clientID) !== transaction.beforeState.get(doc2.clientID)) {
        print(ORANGE, BOLD, "[yjs] ", UNBOLD, RED, "Changed the client-id because another client seems to be using it.");
        doc2.clientID = generateNewClientId();
      }
      doc2.emit("afterTransactionCleanup", [transaction, doc2]);
      if (doc2._observers.has("update")) {
        const encoder = new UpdateEncoderV1();
        const hasContent2 = writeUpdateMessageFromTransaction(encoder, transaction);
        if (hasContent2) {
          doc2.emit("update", [encoder.toUint8Array(), transaction.origin, doc2, transaction]);
        }
      }
      if (doc2._observers.has("updateV2")) {
        const encoder = new UpdateEncoderV2();
        const hasContent2 = writeUpdateMessageFromTransaction(encoder, transaction);
        if (hasContent2) {
          doc2.emit("updateV2", [encoder.toUint8Array(), transaction.origin, doc2, transaction]);
        }
      }
      const { subdocsAdded, subdocsLoaded, subdocsRemoved } = transaction;
      if (subdocsAdded.size > 0 || subdocsRemoved.size > 0 || subdocsLoaded.size > 0) {
        subdocsAdded.forEach((subdoc) => {
          subdoc.clientID = doc2.clientID;
          if (subdoc.collectionid == null) {
            subdoc.collectionid = doc2.collectionid;
          }
          doc2.subdocs.add(subdoc);
        });
        subdocsRemoved.forEach((subdoc) => doc2.subdocs.delete(subdoc));
        doc2.emit("subdocs", [{ loaded: subdocsLoaded, added: subdocsAdded, removed: subdocsRemoved }, doc2, transaction]);
        subdocsRemoved.forEach((subdoc) => subdoc.destroy());
      }
      if (transactionCleanups.length <= i + 1) {
        doc2._transactionCleanups = [];
        doc2.emit("afterAllTransactions", [doc2, transactionCleanups]);
      } else {
        cleanupTransactions(transactionCleanups, i + 1);
      }
    }
  }
};
var transact = (doc2, f, origin = null, local = true) => {
  const transactionCleanups = doc2._transactionCleanups;
  let initialCall = false;
  let result = null;
  if (doc2._transaction === null) {
    initialCall = true;
    doc2._transaction = new Transaction(doc2, origin, local);
    transactionCleanups.push(doc2._transaction);
    if (transactionCleanups.length === 1) {
      doc2.emit("beforeAllTransactions", [doc2]);
    }
    doc2.emit("beforeTransaction", [doc2._transaction, doc2]);
  }
  try {
    result = f(doc2._transaction);
  } finally {
    if (initialCall) {
      const finishCleanup = doc2._transaction === transactionCleanups[0];
      doc2._transaction = null;
      if (finishCleanup) {
        cleanupTransactions(transactionCleanups, 0);
      }
    }
  }
  return result;
};
var StackItem = class {
  /**
   * @param {DeleteSet} deletions
   * @param {DeleteSet} insertions
   */
  constructor(deletions, insertions) {
    this.insertions = insertions;
    this.deletions = deletions;
    this.meta = /* @__PURE__ */ new Map();
  }
};
var clearUndoManagerStackItem = (tr, um, stackItem) => {
  iterateDeletedStructs(tr, stackItem.deletions, (item) => {
    if (item instanceof Item && um.scope.some((type) => type === tr.doc || isParentOf(
      /** @type {AbstractType<any>} */
      type,
      item
    ))) {
      keepItem(item, false);
    }
  });
};
var popStackItem = (undoManager, stack, eventType) => {
  let _tr = null;
  const doc2 = undoManager.doc;
  const scope = undoManager.scope;
  transact(doc2, (transaction) => {
    while (stack.length > 0 && undoManager.currStackItem === null) {
      const store = doc2.store;
      const stackItem = (
        /** @type {StackItem} */
        stack.pop()
      );
      const itemsToRedo = /* @__PURE__ */ new Set();
      const itemsToDelete = [];
      let performedChange = false;
      iterateDeletedStructs(transaction, stackItem.insertions, (struct) => {
        if (struct instanceof Item) {
          if (struct.redone !== null) {
            let { item, diff } = followRedone(store, struct.id);
            if (diff > 0) {
              item = getItemCleanStart(transaction, createID(item.id.client, item.id.clock + diff));
            }
            struct = item;
          }
          if (!struct.deleted && scope.some((type) => type === transaction.doc || isParentOf(
            /** @type {AbstractType<any>} */
            type,
            /** @type {Item} */
            struct
          ))) {
            itemsToDelete.push(struct);
          }
        }
      });
      iterateDeletedStructs(transaction, stackItem.deletions, (struct) => {
        if (struct instanceof Item && scope.some((type) => type === transaction.doc || isParentOf(
          /** @type {AbstractType<any>} */
          type,
          struct
        )) && // Never redo structs in stackItem.insertions because they were created and deleted in the same capture interval.
        !isDeleted(stackItem.insertions, struct.id)) {
          itemsToRedo.add(struct);
        }
      });
      itemsToRedo.forEach((struct) => {
        performedChange = redoItem(transaction, struct, itemsToRedo, stackItem.insertions, undoManager.ignoreRemoteMapChanges, undoManager) !== null || performedChange;
      });
      for (let i = itemsToDelete.length - 1; i >= 0; i--) {
        const item = itemsToDelete[i];
        if (undoManager.deleteFilter(item)) {
          item.delete(transaction);
          performedChange = true;
        }
      }
      undoManager.currStackItem = performedChange ? stackItem : null;
    }
    transaction.changed.forEach((subProps, type) => {
      if (subProps.has(null) && type._searchMarker) {
        type._searchMarker.length = 0;
      }
    });
    _tr = transaction;
  }, undoManager);
  const res = undoManager.currStackItem;
  if (res != null) {
    const changedParentTypes = _tr.changedParentTypes;
    undoManager.emit("stack-item-popped", [{ stackItem: res, type: eventType, changedParentTypes, origin: undoManager }, undoManager]);
    undoManager.currStackItem = null;
  }
  return res;
};
var UndoManager = class extends ObservableV2 {
  /**
   * @param {Doc|AbstractType<any>|Array<AbstractType<any>>} typeScope Limits the scope of the UndoManager. If this is set to a ydoc instance, all changes on that ydoc will be undone. If set to a specific type, only changes on that type or its children will be undone. Also accepts an array of types.
   * @param {UndoManagerOptions} options
   */
  constructor(typeScope, {
    captureTimeout = 500,
    captureTransaction = (_tr) => true,
    deleteFilter = () => true,
    trackedOrigins = /* @__PURE__ */ new Set([null]),
    ignoreRemoteMapChanges = false,
    doc: doc2 = (
      /** @type {Doc} */
      isArray(typeScope) ? typeScope[0].doc : typeScope instanceof Doc ? typeScope : typeScope.doc
    )
  } = {}) {
    super();
    this.scope = [];
    this.doc = doc2;
    this.addToScope(typeScope);
    this.deleteFilter = deleteFilter;
    trackedOrigins.add(this);
    this.trackedOrigins = trackedOrigins;
    this.captureTransaction = captureTransaction;
    this.undoStack = [];
    this.redoStack = [];
    this.undoing = false;
    this.redoing = false;
    this.currStackItem = null;
    this.lastChange = 0;
    this.ignoreRemoteMapChanges = ignoreRemoteMapChanges;
    this.captureTimeout = captureTimeout;
    this.afterTransactionHandler = (transaction) => {
      if (!this.captureTransaction(transaction) || !this.scope.some((type) => transaction.changedParentTypes.has(
        /** @type {AbstractType<any>} */
        type
      ) || type === this.doc) || !this.trackedOrigins.has(transaction.origin) && (!transaction.origin || !this.trackedOrigins.has(transaction.origin.constructor))) {
        return;
      }
      const undoing = this.undoing;
      const redoing = this.redoing;
      const stack = undoing ? this.redoStack : this.undoStack;
      if (undoing) {
        this.stopCapturing();
      } else if (!redoing) {
        this.clear(false, true);
      }
      const insertions = new DeleteSet();
      transaction.afterState.forEach((endClock, client) => {
        const startClock = transaction.beforeState.get(client) || 0;
        const len = endClock - startClock;
        if (len > 0) {
          addToDeleteSet(insertions, client, startClock, len);
        }
      });
      const now = getUnixTime();
      let didAdd = false;
      if (this.lastChange > 0 && now - this.lastChange < this.captureTimeout && stack.length > 0 && !undoing && !redoing) {
        const lastOp = stack[stack.length - 1];
        lastOp.deletions = mergeDeleteSets([lastOp.deletions, transaction.deleteSet]);
        lastOp.insertions = mergeDeleteSets([lastOp.insertions, insertions]);
      } else {
        stack.push(new StackItem(transaction.deleteSet, insertions));
        didAdd = true;
      }
      if (!undoing && !redoing) {
        this.lastChange = now;
      }
      iterateDeletedStructs(
        transaction,
        transaction.deleteSet,
        /** @param {Item|GC} item */
        (item) => {
          if (item instanceof Item && this.scope.some((type) => type === transaction.doc || isParentOf(
            /** @type {AbstractType<any>} */
            type,
            item
          ))) {
            keepItem(item, true);
          }
        }
      );
      const changeEvent = [{ stackItem: stack[stack.length - 1], origin: transaction.origin, type: undoing ? "redo" : "undo", changedParentTypes: transaction.changedParentTypes }, this];
      if (didAdd) {
        this.emit("stack-item-added", changeEvent);
      } else {
        this.emit("stack-item-updated", changeEvent);
      }
    };
    this.destroy = this.destroy.bind(this);
    this.doc.on("afterTransaction", this.afterTransactionHandler);
    this.doc.on("destroy", this.destroy);
  }
  /**
   * Extend the scope.
   *
   * @param {Array<AbstractType<any> | Doc> | AbstractType<any> | Doc} ytypes
   */
  addToScope(ytypes) {
    const tmpSet = new Set(this.scope);
    ytypes = isArray(ytypes) ? ytypes : [ytypes];
    ytypes.forEach((ytype) => {
      if (!tmpSet.has(ytype)) {
        tmpSet.add(ytype);
        if (ytype instanceof AbstractType ? ytype.doc !== this.doc : ytype !== this.doc) warn("[yjs#509] Not same Y.Doc");
        this.scope.push(ytype);
      }
    });
  }
  /**
   * @param {any} origin
   */
  addTrackedOrigin(origin) {
    this.trackedOrigins.add(origin);
  }
  /**
   * @param {any} origin
   */
  removeTrackedOrigin(origin) {
    this.trackedOrigins.delete(origin);
  }
  clear(clearUndoStack = true, clearRedoStack = true) {
    if (clearUndoStack && this.canUndo() || clearRedoStack && this.canRedo()) {
      this.doc.transact((tr) => {
        if (clearUndoStack) {
          this.undoStack.forEach((item) => clearUndoManagerStackItem(tr, this, item));
          this.undoStack = [];
        }
        if (clearRedoStack) {
          this.redoStack.forEach((item) => clearUndoManagerStackItem(tr, this, item));
          this.redoStack = [];
        }
        this.emit("stack-cleared", [{ undoStackCleared: clearUndoStack, redoStackCleared: clearRedoStack }]);
      });
    }
  }
  /**
   * UndoManager merges Undo-StackItem if they are created within time-gap
   * smaller than `options.captureTimeout`. Call `um.stopCapturing()` so that the next
   * StackItem won't be merged.
   *
   *
   * @example
   *     // without stopCapturing
   *     ytext.insert(0, 'a')
   *     ytext.insert(1, 'b')
   *     um.undo()
   *     ytext.toString() // => '' (note that 'ab' was removed)
   *     // with stopCapturing
   *     ytext.insert(0, 'a')
   *     um.stopCapturing()
   *     ytext.insert(0, 'b')
   *     um.undo()
   *     ytext.toString() // => 'a' (note that only 'b' was removed)
   *
   */
  stopCapturing() {
    this.lastChange = 0;
  }
  /**
   * Undo last changes on type.
   *
   * @return {StackItem?} Returns StackItem if a change was applied
   */
  undo() {
    this.undoing = true;
    let res;
    try {
      res = popStackItem(this, this.undoStack, "undo");
    } finally {
      this.undoing = false;
    }
    return res;
  }
  /**
   * Redo last undo operation.
   *
   * @return {StackItem?} Returns StackItem if a change was applied
   */
  redo() {
    this.redoing = true;
    let res;
    try {
      res = popStackItem(this, this.redoStack, "redo");
    } finally {
      this.redoing = false;
    }
    return res;
  }
  /**
   * Are undo steps available?
   *
   * @return {boolean} `true` if undo is possible
   */
  canUndo() {
    return this.undoStack.length > 0;
  }
  /**
   * Are redo steps available?
   *
   * @return {boolean} `true` if redo is possible
   */
  canRedo() {
    return this.redoStack.length > 0;
  }
  destroy() {
    this.trackedOrigins.delete(this);
    this.doc.off("afterTransaction", this.afterTransactionHandler);
    this.doc.off("destroy", this.destroy);
    super.destroy();
  }
};
function* lazyStructReaderGenerator(decoder) {
  const numOfStateUpdates = readVarUint(decoder.restDecoder);
  for (let i = 0; i < numOfStateUpdates; i++) {
    const numberOfStructs = readVarUint(decoder.restDecoder);
    const client = decoder.readClient();
    let clock = readVarUint(decoder.restDecoder);
    for (let i2 = 0; i2 < numberOfStructs; i2++) {
      const info = decoder.readInfo();
      if (info === 10) {
        const len = readVarUint(decoder.restDecoder);
        yield new Skip(createID(client, clock), len);
        clock += len;
      } else if ((BITS5 & info) !== 0) {
        const cantCopyParentInfo = (info & (BIT7 | BIT8)) === 0;
        const struct = new Item(
          createID(client, clock),
          null,
          // left
          (info & BIT8) === BIT8 ? decoder.readLeftID() : null,
          // origin
          null,
          // right
          (info & BIT7) === BIT7 ? decoder.readRightID() : null,
          // right origin
          // @ts-ignore Force writing a string here.
          cantCopyParentInfo ? decoder.readParentInfo() ? decoder.readString() : decoder.readLeftID() : null,
          // parent
          cantCopyParentInfo && (info & BIT6) === BIT6 ? decoder.readString() : null,
          // parentSub
          readItemContent(decoder, info)
          // item content
        );
        yield struct;
        clock += struct.length;
      } else {
        const len = decoder.readLen();
        yield new GC(createID(client, clock), len);
        clock += len;
      }
    }
  }
}
var LazyStructReader = class {
  /**
   * @param {UpdateDecoderV1 | UpdateDecoderV2} decoder
   * @param {boolean} filterSkips
   */
  constructor(decoder, filterSkips) {
    this.gen = lazyStructReaderGenerator(decoder);
    this.curr = null;
    this.done = false;
    this.filterSkips = filterSkips;
    this.next();
  }
  /**
   * @return {Item | GC | Skip |null}
   */
  next() {
    do {
      this.curr = this.gen.next().value || null;
    } while (this.filterSkips && this.curr !== null && this.curr.constructor === Skip);
    return this.curr;
  }
};
var LazyStructWriter = class {
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   */
  constructor(encoder) {
    this.currClient = 0;
    this.startClock = 0;
    this.written = 0;
    this.encoder = encoder;
    this.clientStructs = [];
  }
};
var mergeUpdates = (updates) => mergeUpdatesV2(updates, UpdateDecoderV1, UpdateEncoderV1);
var sliceStruct = (left, diff) => {
  if (left.constructor === GC) {
    const { client, clock } = left.id;
    return new GC(createID(client, clock + diff), left.length - diff);
  } else if (left.constructor === Skip) {
    const { client, clock } = left.id;
    return new Skip(createID(client, clock + diff), left.length - diff);
  } else {
    const leftItem = (
      /** @type {Item} */
      left
    );
    const { client, clock } = leftItem.id;
    return new Item(
      createID(client, clock + diff),
      null,
      createID(client, clock + diff - 1),
      null,
      leftItem.rightOrigin,
      leftItem.parent,
      leftItem.parentSub,
      leftItem.content.splice(diff)
    );
  }
};
var mergeUpdatesV2 = (updates, YDecoder = UpdateDecoderV2, YEncoder = UpdateEncoderV2) => {
  if (updates.length === 1) {
    return updates[0];
  }
  const updateDecoders = updates.map((update) => new YDecoder(createDecoder(update)));
  let lazyStructDecoders = updateDecoders.map((decoder) => new LazyStructReader(decoder, true));
  let currWrite = null;
  const updateEncoder = new YEncoder();
  const lazyStructEncoder = new LazyStructWriter(updateEncoder);
  while (true) {
    lazyStructDecoders = lazyStructDecoders.filter((dec) => dec.curr !== null);
    lazyStructDecoders.sort(
      /** @type {function(any,any):number} */
      (dec1, dec2) => {
        if (dec1.curr.id.client === dec2.curr.id.client) {
          const clockDiff = dec1.curr.id.clock - dec2.curr.id.clock;
          if (clockDiff === 0) {
            return dec1.curr.constructor === dec2.curr.constructor ? 0 : dec1.curr.constructor === Skip ? 1 : -1;
          } else {
            return clockDiff;
          }
        } else {
          return dec2.curr.id.client - dec1.curr.id.client;
        }
      }
    );
    if (lazyStructDecoders.length === 0) {
      break;
    }
    const currDecoder = lazyStructDecoders[0];
    const firstClient = (
      /** @type {Item | GC} */
      currDecoder.curr.id.client
    );
    if (currWrite !== null) {
      let curr = (
        /** @type {Item | GC | null} */
        currDecoder.curr
      );
      let iterated = false;
      while (curr !== null && curr.id.clock + curr.length <= currWrite.struct.id.clock + currWrite.struct.length && curr.id.client >= currWrite.struct.id.client) {
        curr = currDecoder.next();
        iterated = true;
      }
      if (curr === null || // current decoder is empty
      curr.id.client !== firstClient || // check whether there is another decoder that has has updates from `firstClient`
      iterated && curr.id.clock > currWrite.struct.id.clock + currWrite.struct.length) {
        continue;
      }
      if (firstClient !== currWrite.struct.id.client) {
        writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
        currWrite = { struct: curr, offset: 0 };
        currDecoder.next();
      } else {
        if (currWrite.struct.id.clock + currWrite.struct.length < curr.id.clock) {
          if (currWrite.struct.constructor === Skip) {
            currWrite.struct.length = curr.id.clock + curr.length - currWrite.struct.id.clock;
          } else {
            writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
            const diff = curr.id.clock - currWrite.struct.id.clock - currWrite.struct.length;
            const struct = new Skip(createID(firstClient, currWrite.struct.id.clock + currWrite.struct.length), diff);
            currWrite = { struct, offset: 0 };
          }
        } else {
          const diff = currWrite.struct.id.clock + currWrite.struct.length - curr.id.clock;
          if (diff > 0) {
            if (currWrite.struct.constructor === Skip) {
              currWrite.struct.length -= diff;
            } else {
              curr = sliceStruct(curr, diff);
            }
          }
          if (!currWrite.struct.mergeWith(
            /** @type {any} */
            curr
          )) {
            writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
            currWrite = { struct: curr, offset: 0 };
            currDecoder.next();
          }
        }
      }
    } else {
      currWrite = { struct: (
        /** @type {Item | GC} */
        currDecoder.curr
      ), offset: 0 };
      currDecoder.next();
    }
    for (let next = currDecoder.curr; next !== null && next.id.client === firstClient && next.id.clock === currWrite.struct.id.clock + currWrite.struct.length && next.constructor !== Skip; next = currDecoder.next()) {
      writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
      currWrite = { struct: next, offset: 0 };
    }
  }
  if (currWrite !== null) {
    writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
    currWrite = null;
  }
  finishLazyStructWriting(lazyStructEncoder);
  const dss = updateDecoders.map((decoder) => readDeleteSet(decoder));
  const ds = mergeDeleteSets(dss);
  writeDeleteSet(updateEncoder, ds);
  return updateEncoder.toUint8Array();
};
var diffUpdateV2 = (update, sv, YDecoder = UpdateDecoderV2, YEncoder = UpdateEncoderV2) => {
  const state = decodeStateVector(sv);
  const encoder = new YEncoder();
  const lazyStructWriter = new LazyStructWriter(encoder);
  const decoder = new YDecoder(createDecoder(update));
  const reader = new LazyStructReader(decoder, false);
  while (reader.curr) {
    const curr = reader.curr;
    const currClient = curr.id.client;
    const svClock = state.get(currClient) || 0;
    if (reader.curr.constructor === Skip) {
      reader.next();
      continue;
    }
    if (curr.id.clock + curr.length > svClock) {
      writeStructToLazyStructWriter(lazyStructWriter, curr, max(svClock - curr.id.clock, 0));
      reader.next();
      while (reader.curr && reader.curr.id.client === currClient) {
        writeStructToLazyStructWriter(lazyStructWriter, reader.curr, 0);
        reader.next();
      }
    } else {
      while (reader.curr && reader.curr.id.client === currClient && reader.curr.id.clock + reader.curr.length <= svClock) {
        reader.next();
      }
    }
  }
  finishLazyStructWriting(lazyStructWriter);
  const ds = readDeleteSet(decoder);
  writeDeleteSet(encoder, ds);
  return encoder.toUint8Array();
};
var flushLazyStructWriter = (lazyWriter) => {
  if (lazyWriter.written > 0) {
    lazyWriter.clientStructs.push({ written: lazyWriter.written, restEncoder: toUint8Array(lazyWriter.encoder.restEncoder) });
    lazyWriter.encoder.restEncoder = createEncoder();
    lazyWriter.written = 0;
  }
};
var writeStructToLazyStructWriter = (lazyWriter, struct, offset) => {
  if (lazyWriter.written > 0 && lazyWriter.currClient !== struct.id.client) {
    flushLazyStructWriter(lazyWriter);
  }
  if (lazyWriter.written === 0) {
    lazyWriter.currClient = struct.id.client;
    lazyWriter.encoder.writeClient(struct.id.client);
    writeVarUint(lazyWriter.encoder.restEncoder, struct.id.clock + offset);
  }
  struct.write(lazyWriter.encoder, offset);
  lazyWriter.written++;
};
var finishLazyStructWriting = (lazyWriter) => {
  flushLazyStructWriter(lazyWriter);
  const restEncoder = lazyWriter.encoder.restEncoder;
  writeVarUint(restEncoder, lazyWriter.clientStructs.length);
  for (let i = 0; i < lazyWriter.clientStructs.length; i++) {
    const partStructs = lazyWriter.clientStructs[i];
    writeVarUint(restEncoder, partStructs.written);
    writeUint8Array(restEncoder, partStructs.restEncoder);
  }
};
var convertUpdateFormat = (update, blockTransformer, YDecoder, YEncoder) => {
  const updateDecoder = new YDecoder(createDecoder(update));
  const lazyDecoder = new LazyStructReader(updateDecoder, false);
  const updateEncoder = new YEncoder();
  const lazyWriter = new LazyStructWriter(updateEncoder);
  for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) {
    writeStructToLazyStructWriter(lazyWriter, blockTransformer(curr), 0);
  }
  finishLazyStructWriting(lazyWriter);
  const ds = readDeleteSet(updateDecoder);
  writeDeleteSet(updateEncoder, ds);
  return updateEncoder.toUint8Array();
};
var convertUpdateFormatV2ToV1 = (update) => convertUpdateFormat(update, id, UpdateDecoderV2, UpdateEncoderV1);
var errorComputeChanges = "You must not compute changes after the event-handler fired.";
var YEvent = class {
  /**
   * @param {T} target The changed type.
   * @param {Transaction} transaction
   */
  constructor(target, transaction) {
    this.target = target;
    this.currentTarget = target;
    this.transaction = transaction;
    this._changes = null;
    this._keys = null;
    this._delta = null;
    this._path = null;
  }
  /**
   * Computes the path from `y` to the changed type.
   *
   * @todo v14 should standardize on path: Array<{parent, index}> because that is easier to work with.
   *
   * The following property holds:
   * @example
   *   let type = y
   *   event.path.forEach(dir => {
   *     type = type.get(dir)
   *   })
   *   type === event.target // => true
   */
  get path() {
    return this._path || (this._path = getPathTo(this.currentTarget, this.target));
  }
  /**
   * Check if a struct is deleted by this event.
   *
   * In contrast to change.deleted, this method also returns true if the struct was added and then deleted.
   *
   * @param {AbstractStruct} struct
   * @return {boolean}
   */
  deletes(struct) {
    return isDeleted(this.transaction.deleteSet, struct.id);
  }
  /**
   * @type {Map<string, { action: 'add' | 'update' | 'delete', oldValue: any }>}
   */
  get keys() {
    if (this._keys === null) {
      if (this.transaction.doc._transactionCleanups.length === 0) {
        throw create3(errorComputeChanges);
      }
      const keys2 = /* @__PURE__ */ new Map();
      const target = this.target;
      const changed = (
        /** @type Set<string|null> */
        this.transaction.changed.get(target)
      );
      changed.forEach((key) => {
        if (key !== null) {
          const item = (
            /** @type {Item} */
            target._map.get(key)
          );
          let action;
          let oldValue;
          if (this.adds(item)) {
            let prev = item.left;
            while (prev !== null && this.adds(prev)) {
              prev = prev.left;
            }
            if (this.deletes(item)) {
              if (prev !== null && this.deletes(prev)) {
                action = "delete";
                oldValue = last(prev.content.getContent());
              } else {
                return;
              }
            } else {
              if (prev !== null && this.deletes(prev)) {
                action = "update";
                oldValue = last(prev.content.getContent());
              } else {
                action = "add";
                oldValue = void 0;
              }
            }
          } else {
            if (this.deletes(item)) {
              action = "delete";
              oldValue = last(
                /** @type {Item} */
                item.content.getContent()
              );
            } else {
              return;
            }
          }
          keys2.set(key, { action, oldValue });
        }
      });
      this._keys = keys2;
    }
    return this._keys;
  }
  /**
   * This is a computed property. Note that this can only be safely computed during the
   * event call. Computing this property after other changes happened might result in
   * unexpected behavior (incorrect computation of deltas). A safe way to collect changes
   * is to store the `changes` or the `delta` object. Avoid storing the `transaction` object.
   *
   * @type {Array<{insert?: string | Array<any> | object | AbstractType<any>, retain?: number, delete?: number, attributes?: Object<string, any>}>}
   */
  get delta() {
    return this.changes.delta;
  }
  /**
   * Check if a struct is added by this event.
   *
   * In contrast to change.deleted, this method also returns true if the struct was added and then deleted.
   *
   * @param {AbstractStruct} struct
   * @return {boolean}
   */
  adds(struct) {
    return struct.id.clock >= (this.transaction.beforeState.get(struct.id.client) || 0);
  }
  /**
   * This is a computed property. Note that this can only be safely computed during the
   * event call. Computing this property after other changes happened might result in
   * unexpected behavior (incorrect computation of deltas). A safe way to collect changes
   * is to store the `changes` or the `delta` object. Avoid storing the `transaction` object.
   *
   * @type {{added:Set<Item>,deleted:Set<Item>,keys:Map<string,{action:'add'|'update'|'delete',oldValue:any}>,delta:Array<{insert?:Array<any>|string, delete?:number, retain?:number}>}}
   */
  get changes() {
    let changes = this._changes;
    if (changes === null) {
      if (this.transaction.doc._transactionCleanups.length === 0) {
        throw create3(errorComputeChanges);
      }
      const target = this.target;
      const added = create2();
      const deleted = create2();
      const delta = [];
      changes = {
        added,
        deleted,
        delta,
        keys: this.keys
      };
      const changed = (
        /** @type Set<string|null> */
        this.transaction.changed.get(target)
      );
      if (changed.has(null)) {
        let lastOp = null;
        const packOp = () => {
          if (lastOp) {
            delta.push(lastOp);
          }
        };
        for (let item = target._start; item !== null; item = item.right) {
          if (item.deleted) {
            if (this.deletes(item) && !this.adds(item)) {
              if (lastOp === null || lastOp.delete === void 0) {
                packOp();
                lastOp = { delete: 0 };
              }
              lastOp.delete += item.length;
              deleted.add(item);
            }
          } else {
            if (this.adds(item)) {
              if (lastOp === null || lastOp.insert === void 0) {
                packOp();
                lastOp = { insert: [] };
              }
              lastOp.insert = lastOp.insert.concat(item.content.getContent());
              added.add(item);
            } else {
              if (lastOp === null || lastOp.retain === void 0) {
                packOp();
                lastOp = { retain: 0 };
              }
              lastOp.retain += item.length;
            }
          }
        }
        if (lastOp !== null && lastOp.retain === void 0) {
          packOp();
        }
      }
      this._changes = changes;
    }
    return (
      /** @type {any} */
      changes
    );
  }
};
var getPathTo = (parent, child) => {
  const path = [];
  while (child._item !== null && child !== parent) {
    if (child._item.parentSub !== null) {
      path.unshift(child._item.parentSub);
    } else {
      let i = 0;
      let c = (
        /** @type {AbstractType<any>} */
        child._item.parent._start
      );
      while (c !== child._item && c !== null) {
        if (!c.deleted && c.countable) {
          i += c.length;
        }
        c = c.right;
      }
      path.unshift(i);
    }
    child = /** @type {AbstractType<any>} */
    child._item.parent;
  }
  return path;
};
var warnPrematureAccess = () => {
  warn("Invalid access: Add Yjs type to a document before reading data.");
};
var maxSearchMarker = 80;
var globalSearchMarkerTimestamp = 0;
var ArraySearchMarker = class {
  /**
   * @param {Item} p
   * @param {number} index
   */
  constructor(p, index) {
    p.marker = true;
    this.p = p;
    this.index = index;
    this.timestamp = globalSearchMarkerTimestamp++;
  }
};
var refreshMarkerTimestamp = (marker) => {
  marker.timestamp = globalSearchMarkerTimestamp++;
};
var overwriteMarker = (marker, p, index) => {
  marker.p.marker = false;
  marker.p = p;
  p.marker = true;
  marker.index = index;
  marker.timestamp = globalSearchMarkerTimestamp++;
};
var markPosition = (searchMarker, p, index) => {
  if (searchMarker.length >= maxSearchMarker) {
    const marker = searchMarker.reduce((a, b) => a.timestamp < b.timestamp ? a : b);
    overwriteMarker(marker, p, index);
    return marker;
  } else {
    const pm = new ArraySearchMarker(p, index);
    searchMarker.push(pm);
    return pm;
  }
};
var findMarker = (yarray, index) => {
  if (yarray._start === null || index === 0 || yarray._searchMarker === null) {
    return null;
  }
  const marker = yarray._searchMarker.length === 0 ? null : yarray._searchMarker.reduce((a, b) => abs(index - a.index) < abs(index - b.index) ? a : b);
  let p = yarray._start;
  let pindex = 0;
  if (marker !== null) {
    p = marker.p;
    pindex = marker.index;
    refreshMarkerTimestamp(marker);
  }
  while (p.right !== null && pindex < index) {
    if (!p.deleted && p.countable) {
      if (index < pindex + p.length) {
        break;
      }
      pindex += p.length;
    }
    p = p.right;
  }
  while (p.left !== null && pindex > index) {
    p = p.left;
    if (!p.deleted && p.countable) {
      pindex -= p.length;
    }
  }
  while (p.left !== null && p.left.id.client === p.id.client && p.left.id.clock + p.left.length === p.id.clock) {
    p = p.left;
    if (!p.deleted && p.countable) {
      pindex -= p.length;
    }
  }
  if (marker !== null && abs(marker.index - pindex) < /** @type {YText|YArray<any>} */
  p.parent.length / maxSearchMarker) {
    overwriteMarker(marker, p, pindex);
    return marker;
  } else {
    return markPosition(yarray._searchMarker, p, pindex);
  }
};
var updateMarkerChanges = (searchMarker, index, len) => {
  for (let i = searchMarker.length - 1; i >= 0; i--) {
    const m = searchMarker[i];
    if (len > 0) {
      let p = m.p;
      p.marker = false;
      while (p && (p.deleted || !p.countable)) {
        p = p.left;
        if (p && !p.deleted && p.countable) {
          m.index -= p.length;
        }
      }
      if (p === null || p.marker === true) {
        searchMarker.splice(i, 1);
        continue;
      }
      m.p = p;
      p.marker = true;
    }
    if (index < m.index || len > 0 && index === m.index) {
      m.index = max(index, m.index + len);
    }
  }
};
var callTypeObservers = (type, transaction, event) => {
  const changedType = type;
  const changedParentTypes = transaction.changedParentTypes;
  while (true) {
    setIfUndefined(changedParentTypes, type, () => []).push(event);
    if (type._item === null) {
      break;
    }
    type = /** @type {AbstractType<any>} */
    type._item.parent;
  }
  callEventHandlerListeners(changedType._eH, event, transaction);
};
var AbstractType = class {
  constructor() {
    this._item = null;
    this._map = /* @__PURE__ */ new Map();
    this._start = null;
    this.doc = null;
    this._length = 0;
    this._eH = createEventHandler();
    this._dEH = createEventHandler();
    this._searchMarker = null;
  }
  /**
   * @return {AbstractType<any>|null}
   */
  get parent() {
    return this._item ? (
      /** @type {AbstractType<any>} */
      this._item.parent
    ) : null;
  }
  /**
   * Integrate this type into the Yjs instance.
   *
   * * Save this struct in the os
   * * This type is sent to other client
   * * Observer functions are fired
   *
   * @param {Doc} y The Yjs instance
   * @param {Item|null} item
   */
  _integrate(y, item) {
    this.doc = y;
    this._item = item;
  }
  /**
   * @return {AbstractType<EventType>}
   */
  _copy() {
    throw methodUnimplemented();
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {AbstractType<EventType>}
   */
  clone() {
    throw methodUnimplemented();
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} _encoder
   */
  _write(_encoder) {
  }
  /**
   * The first non-deleted item
   */
  get _first() {
    let n = this._start;
    while (n !== null && n.deleted) {
      n = n.right;
    }
    return n;
  }
  /**
   * Creates YEvent and calls all type observers.
   * Must be implemented by each type.
   *
   * @param {Transaction} transaction
   * @param {Set<null|string>} _parentSubs Keys changed on this type. `null` if list was modified.
   */
  _callObserver(transaction, _parentSubs) {
    if (!transaction.local && this._searchMarker) {
      this._searchMarker.length = 0;
    }
  }
  /**
   * Observe all events that are created on this type.
   *
   * @param {function(EventType, Transaction):void} f Observer function
   */
  observe(f) {
    addEventHandlerListener(this._eH, f);
  }
  /**
   * Observe all events that are created by this type and its children.
   *
   * @param {function(Array<YEvent<any>>,Transaction):void} f Observer function
   */
  observeDeep(f) {
    addEventHandlerListener(this._dEH, f);
  }
  /**
   * Unregister an observer function.
   *
   * @param {function(EventType,Transaction):void} f Observer function
   */
  unobserve(f) {
    removeEventHandlerListener(this._eH, f);
  }
  /**
   * Unregister an observer function.
   *
   * @param {function(Array<YEvent<any>>,Transaction):void} f Observer function
   */
  unobserveDeep(f) {
    removeEventHandlerListener(this._dEH, f);
  }
  /**
   * @abstract
   * @return {any}
   */
  toJSON() {
  }
};
var typeListSlice = (type, start, end) => {
  type.doc ?? warnPrematureAccess();
  if (start < 0) {
    start = type._length + start;
  }
  if (end < 0) {
    end = type._length + end;
  }
  let len = end - start;
  const cs = [];
  let n = type._start;
  while (n !== null && len > 0) {
    if (n.countable && !n.deleted) {
      const c = n.content.getContent();
      if (c.length <= start) {
        start -= c.length;
      } else {
        for (let i = start; i < c.length && len > 0; i++) {
          cs.push(c[i]);
          len--;
        }
        start = 0;
      }
    }
    n = n.right;
  }
  return cs;
};
var typeListToArray = (type) => {
  type.doc ?? warnPrematureAccess();
  const cs = [];
  let n = type._start;
  while (n !== null) {
    if (n.countable && !n.deleted) {
      const c = n.content.getContent();
      for (let i = 0; i < c.length; i++) {
        cs.push(c[i]);
      }
    }
    n = n.right;
  }
  return cs;
};
var typeListForEach = (type, f) => {
  let index = 0;
  let n = type._start;
  type.doc ?? warnPrematureAccess();
  while (n !== null) {
    if (n.countable && !n.deleted) {
      const c = n.content.getContent();
      for (let i = 0; i < c.length; i++) {
        f(c[i], index++, type);
      }
    }
    n = n.right;
  }
};
var typeListMap = (type, f) => {
  const result = [];
  typeListForEach(type, (c, i) => {
    result.push(f(c, i, type));
  });
  return result;
};
var typeListCreateIterator = (type) => {
  let n = type._start;
  let currentContent = null;
  let currentContentIndex = 0;
  return {
    [Symbol.iterator]() {
      return this;
    },
    next: () => {
      if (currentContent === null) {
        while (n !== null && n.deleted) {
          n = n.right;
        }
        if (n === null) {
          return {
            done: true,
            value: void 0
          };
        }
        currentContent = n.content.getContent();
        currentContentIndex = 0;
        n = n.right;
      }
      const value = currentContent[currentContentIndex++];
      if (currentContent.length <= currentContentIndex) {
        currentContent = null;
      }
      return {
        done: false,
        value
      };
    }
  };
};
var typeListGet = (type, index) => {
  type.doc ?? warnPrematureAccess();
  const marker = findMarker(type, index);
  let n = type._start;
  if (marker !== null) {
    n = marker.p;
    index -= marker.index;
  }
  for (; n !== null; n = n.right) {
    if (!n.deleted && n.countable) {
      if (index < n.length) {
        return n.content.getContent()[index];
      }
      index -= n.length;
    }
  }
};
var typeListInsertGenericsAfter = (transaction, parent, referenceItem, content2) => {
  let left = referenceItem;
  const doc2 = transaction.doc;
  const ownClientId = doc2.clientID;
  const store = doc2.store;
  const right = referenceItem === null ? parent._start : referenceItem.right;
  let jsonContent = [];
  const packJsonContent = () => {
    if (jsonContent.length > 0) {
      left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentAny(jsonContent));
      left.integrate(transaction, 0);
      jsonContent = [];
    }
  };
  content2.forEach((c) => {
    if (c === null) {
      jsonContent.push(c);
    } else {
      switch (c.constructor) {
        case Number:
        case Object:
        case Boolean:
        case Array:
        case String:
          jsonContent.push(c);
          break;
        default:
          packJsonContent();
          switch (c.constructor) {
            case Uint8Array:
            case ArrayBuffer:
              left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentBinary(new Uint8Array(
                /** @type {Uint8Array} */
                c
              )));
              left.integrate(transaction, 0);
              break;
            case Doc:
              left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentDoc(
                /** @type {Doc} */
                c
              ));
              left.integrate(transaction, 0);
              break;
            default:
              if (c instanceof AbstractType) {
                left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentType(c));
                left.integrate(transaction, 0);
              } else {
                throw new Error("Unexpected content type in insert operation");
              }
          }
      }
    }
  });
  packJsonContent();
};
var lengthExceeded = () => create3("Length exceeded!");
var typeListInsertGenerics = (transaction, parent, index, content2) => {
  if (index > parent._length) {
    throw lengthExceeded();
  }
  if (index === 0) {
    if (parent._searchMarker) {
      updateMarkerChanges(parent._searchMarker, index, content2.length);
    }
    return typeListInsertGenericsAfter(transaction, parent, null, content2);
  }
  const startIndex = index;
  const marker = findMarker(parent, index);
  let n = parent._start;
  if (marker !== null) {
    n = marker.p;
    index -= marker.index;
    if (index === 0) {
      n = n.prev;
      index += n && n.countable && !n.deleted ? n.length : 0;
    }
  }
  for (; n !== null; n = n.right) {
    if (!n.deleted && n.countable) {
      if (index <= n.length) {
        if (index < n.length) {
          getItemCleanStart(transaction, createID(n.id.client, n.id.clock + index));
        }
        break;
      }
      index -= n.length;
    }
  }
  if (parent._searchMarker) {
    updateMarkerChanges(parent._searchMarker, startIndex, content2.length);
  }
  return typeListInsertGenericsAfter(transaction, parent, n, content2);
};
var typeListPushGenerics = (transaction, parent, content2) => {
  const marker = (parent._searchMarker || []).reduce((maxMarker, currMarker) => currMarker.index > maxMarker.index ? currMarker : maxMarker, { index: 0, p: parent._start });
  let n = marker.p;
  if (n) {
    while (n.right) {
      n = n.right;
    }
  }
  return typeListInsertGenericsAfter(transaction, parent, n, content2);
};
var typeListDelete = (transaction, parent, index, length2) => {
  if (length2 === 0) {
    return;
  }
  const startIndex = index;
  const startLength = length2;
  const marker = findMarker(parent, index);
  let n = parent._start;
  if (marker !== null) {
    n = marker.p;
    index -= marker.index;
  }
  for (; n !== null && index > 0; n = n.right) {
    if (!n.deleted && n.countable) {
      if (index < n.length) {
        getItemCleanStart(transaction, createID(n.id.client, n.id.clock + index));
      }
      index -= n.length;
    }
  }
  while (length2 > 0 && n !== null) {
    if (!n.deleted) {
      if (length2 < n.length) {
        getItemCleanStart(transaction, createID(n.id.client, n.id.clock + length2));
      }
      n.delete(transaction);
      length2 -= n.length;
    }
    n = n.right;
  }
  if (length2 > 0) {
    throw lengthExceeded();
  }
  if (parent._searchMarker) {
    updateMarkerChanges(
      parent._searchMarker,
      startIndex,
      -startLength + length2
      /* in case we remove the above exception */
    );
  }
};
var typeMapDelete = (transaction, parent, key) => {
  const c = parent._map.get(key);
  if (c !== void 0) {
    c.delete(transaction);
  }
};
var typeMapSet = (transaction, parent, key, value) => {
  const left = parent._map.get(key) || null;
  const doc2 = transaction.doc;
  const ownClientId = doc2.clientID;
  let content2;
  if (value == null) {
    content2 = new ContentAny([value]);
  } else {
    switch (value.constructor) {
      case Number:
      case Object:
      case Boolean:
      case Array:
      case String:
      case Date:
      case BigInt:
        content2 = new ContentAny([value]);
        break;
      case Uint8Array:
        content2 = new ContentBinary(
          /** @type {Uint8Array} */
          value
        );
        break;
      case Doc:
        content2 = new ContentDoc(
          /** @type {Doc} */
          value
        );
        break;
      default:
        if (value instanceof AbstractType) {
          content2 = new ContentType(value);
        } else {
          throw new Error("Unexpected content type");
        }
    }
  }
  new Item(createID(ownClientId, getState(doc2.store, ownClientId)), left, left && left.lastId, null, null, parent, key, content2).integrate(transaction, 0);
};
var typeMapGet = (parent, key) => {
  parent.doc ?? warnPrematureAccess();
  const val = parent._map.get(key);
  return val !== void 0 && !val.deleted ? val.content.getContent()[val.length - 1] : void 0;
};
var typeMapGetAll = (parent) => {
  const res = {};
  parent.doc ?? warnPrematureAccess();
  parent._map.forEach((value, key) => {
    if (!value.deleted) {
      res[key] = value.content.getContent()[value.length - 1];
    }
  });
  return res;
};
var typeMapHas = (parent, key) => {
  parent.doc ?? warnPrematureAccess();
  const val = parent._map.get(key);
  return val !== void 0 && !val.deleted;
};
var typeMapGetAllSnapshot = (parent, snapshot) => {
  const res = {};
  parent._map.forEach((value, key) => {
    let v = value;
    while (v !== null && (!snapshot.sv.has(v.id.client) || v.id.clock >= (snapshot.sv.get(v.id.client) || 0))) {
      v = v.left;
    }
    if (v !== null && isVisible(v, snapshot)) {
      res[key] = v.content.getContent()[v.length - 1];
    }
  });
  return res;
};
var createMapIterator = (type) => {
  type.doc ?? warnPrematureAccess();
  return iteratorFilter(
    type._map.entries(),
    /** @param {any} entry */
    (entry) => !entry[1].deleted
  );
};
var YArrayEvent = class extends YEvent {
};
var YArray = class _YArray extends AbstractType {
  constructor() {
    super();
    this._prelimContent = [];
    this._searchMarker = [];
  }
  /**
   * Construct a new YArray containing the specified items.
   * @template {Object<string,any>|Array<any>|number|null|string|Uint8Array} T
   * @param {Array<T>} items
   * @return {YArray<T>}
   */
  static from(items) {
    const a = new _YArray();
    a.push(items);
    return a;
  }
  /**
   * Integrate this type into the Yjs instance.
   *
   * * Save this struct in the os
   * * This type is sent to other client
   * * Observer functions are fired
   *
   * @param {Doc} y The Yjs instance
   * @param {Item} item
   */
  _integrate(y, item) {
    super._integrate(y, item);
    this.insert(
      0,
      /** @type {Array<any>} */
      this._prelimContent
    );
    this._prelimContent = null;
  }
  /**
   * @return {YArray<T>}
   */
  _copy() {
    return new _YArray();
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YArray<T>}
   */
  clone() {
    const arr = new _YArray();
    arr.insert(0, this.toArray().map(
      (el) => el instanceof AbstractType ? (
        /** @type {typeof el} */
        el.clone()
      ) : el
    ));
    return arr;
  }
  get length() {
    this.doc ?? warnPrematureAccess();
    return this._length;
  }
  /**
   * Creates YArrayEvent and calls observers.
   *
   * @param {Transaction} transaction
   * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
   */
  _callObserver(transaction, parentSubs) {
    super._callObserver(transaction, parentSubs);
    callTypeObservers(this, transaction, new YArrayEvent(this, transaction));
  }
  /**
   * Inserts new content at an index.
   *
   * Important: This function expects an array of content. Not just a content
   * object. The reason for this "weirdness" is that inserting several elements
   * is very efficient when it is done as a single operation.
   *
   * @example
   *  // Insert character 'a' at position 0
   *  yarray.insert(0, ['a'])
   *  // Insert numbers 1, 2 at position 1
   *  yarray.insert(1, [1, 2])
   *
   * @param {number} index The index to insert content at.
   * @param {Array<T>} content The array of content
   */
  insert(index, content2) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeListInsertGenerics(
          transaction,
          this,
          index,
          /** @type {any} */
          content2
        );
      });
    } else {
      this._prelimContent.splice(index, 0, ...content2);
    }
  }
  /**
   * Appends content to this YArray.
   *
   * @param {Array<T>} content Array of content to append.
   *
   * @todo Use the following implementation in all types.
   */
  push(content2) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeListPushGenerics(
          transaction,
          this,
          /** @type {any} */
          content2
        );
      });
    } else {
      this._prelimContent.push(...content2);
    }
  }
  /**
   * Prepends content to this YArray.
   *
   * @param {Array<T>} content Array of content to prepend.
   */
  unshift(content2) {
    this.insert(0, content2);
  }
  /**
   * Deletes elements starting from an index.
   *
   * @param {number} index Index at which to start deleting elements
   * @param {number} length The number of elements to remove. Defaults to 1.
   */
  delete(index, length2 = 1) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeListDelete(transaction, this, index, length2);
      });
    } else {
      this._prelimContent.splice(index, length2);
    }
  }
  /**
   * Returns the i-th element from a YArray.
   *
   * @param {number} index The index of the element to return from the YArray
   * @return {T}
   */
  get(index) {
    return typeListGet(this, index);
  }
  /**
   * Transforms this YArray to a JavaScript Array.
   *
   * @return {Array<T>}
   */
  toArray() {
    return typeListToArray(this);
  }
  /**
   * Returns a portion of this YArray into a JavaScript Array selected
   * from start to end (end not included).
   *
   * @param {number} [start]
   * @param {number} [end]
   * @return {Array<T>}
   */
  slice(start = 0, end = this.length) {
    return typeListSlice(this, start, end);
  }
  /**
   * Transforms this Shared Type to a JSON object.
   *
   * @return {Array<any>}
   */
  toJSON() {
    return this.map((c) => c instanceof AbstractType ? c.toJSON() : c);
  }
  /**
   * Returns an Array with the result of calling a provided function on every
   * element of this YArray.
   *
   * @template M
   * @param {function(T,number,YArray<T>):M} f Function that produces an element of the new Array
   * @return {Array<M>} A new array with each element being the result of the
   *                 callback function
   */
  map(f) {
    return typeListMap(
      this,
      /** @type {any} */
      f
    );
  }
  /**
   * Executes a provided function once on every element of this YArray.
   *
   * @param {function(T,number,YArray<T>):void} f A function to execute on every element of this YArray.
   */
  forEach(f) {
    typeListForEach(this, f);
  }
  /**
   * @return {IterableIterator<T>}
   */
  [Symbol.iterator]() {
    return typeListCreateIterator(this);
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   */
  _write(encoder) {
    encoder.writeTypeRef(YArrayRefID);
  }
};
var readYArray = (_decoder) => new YArray();
var YMapEvent = class extends YEvent {
  /**
   * @param {YMap<T>} ymap The YArray that changed.
   * @param {Transaction} transaction
   * @param {Set<any>} subs The keys that changed.
   */
  constructor(ymap, transaction, subs) {
    super(ymap, transaction);
    this.keysChanged = subs;
  }
};
var YMap = class _YMap extends AbstractType {
  /**
   *
   * @param {Iterable<readonly [string, any]>=} entries - an optional iterable to initialize the YMap
   */
  constructor(entries2) {
    super();
    this._prelimContent = null;
    if (entries2 === void 0) {
      this._prelimContent = /* @__PURE__ */ new Map();
    } else {
      this._prelimContent = new Map(entries2);
    }
  }
  /**
   * Integrate this type into the Yjs instance.
   *
   * * Save this struct in the os
   * * This type is sent to other client
   * * Observer functions are fired
   *
   * @param {Doc} y The Yjs instance
   * @param {Item} item
   */
  _integrate(y, item) {
    super._integrate(y, item);
    this._prelimContent.forEach((value, key) => {
      this.set(key, value);
    });
    this._prelimContent = null;
  }
  /**
   * @return {YMap<MapType>}
   */
  _copy() {
    return new _YMap();
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YMap<MapType>}
   */
  clone() {
    const map2 = new _YMap();
    this.forEach((value, key) => {
      map2.set(key, value instanceof AbstractType ? (
        /** @type {typeof value} */
        value.clone()
      ) : value);
    });
    return map2;
  }
  /**
   * Creates YMapEvent and calls observers.
   *
   * @param {Transaction} transaction
   * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
   */
  _callObserver(transaction, parentSubs) {
    callTypeObservers(this, transaction, new YMapEvent(this, transaction, parentSubs));
  }
  /**
   * Transforms this Shared Type to a JSON object.
   *
   * @return {Object<string,any>}
   */
  toJSON() {
    this.doc ?? warnPrematureAccess();
    const map2 = {};
    this._map.forEach((item, key) => {
      if (!item.deleted) {
        const v = item.content.getContent()[item.length - 1];
        map2[key] = v instanceof AbstractType ? v.toJSON() : v;
      }
    });
    return map2;
  }
  /**
   * Returns the size of the YMap (count of key/value pairs)
   *
   * @return {number}
   */
  get size() {
    return [...createMapIterator(this)].length;
  }
  /**
   * Returns the keys for each element in the YMap Type.
   *
   * @return {IterableIterator<string>}
   */
  keys() {
    return iteratorMap(
      createMapIterator(this),
      /** @param {any} v */
      (v) => v[0]
    );
  }
  /**
   * Returns the values for each element in the YMap Type.
   *
   * @return {IterableIterator<MapType>}
   */
  values() {
    return iteratorMap(
      createMapIterator(this),
      /** @param {any} v */
      (v) => v[1].content.getContent()[v[1].length - 1]
    );
  }
  /**
   * Returns an Iterator of [key, value] pairs
   *
   * @return {IterableIterator<[string, MapType]>}
   */
  entries() {
    return iteratorMap(
      createMapIterator(this),
      /** @param {any} v */
      (v) => (
        /** @type {any} */
        [v[0], v[1].content.getContent()[v[1].length - 1]]
      )
    );
  }
  /**
   * Executes a provided function on once on every key-value pair.
   *
   * @param {function(MapType,string,YMap<MapType>):void} f A function to execute on every element of this YArray.
   */
  forEach(f) {
    this.doc ?? warnPrematureAccess();
    this._map.forEach((item, key) => {
      if (!item.deleted) {
        f(item.content.getContent()[item.length - 1], key, this);
      }
    });
  }
  /**
   * Returns an Iterator of [key, value] pairs
   *
   * @return {IterableIterator<[string, MapType]>}
   */
  [Symbol.iterator]() {
    return this.entries();
  }
  /**
   * Remove a specified element from this YMap.
   *
   * @param {string} key The key of the element to remove.
   */
  delete(key) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeMapDelete(transaction, this, key);
      });
    } else {
      this._prelimContent.delete(key);
    }
  }
  /**
   * Adds or updates an element with a specified key and value.
   * @template {MapType} VAL
   *
   * @param {string} key The key of the element to add to this YMap
   * @param {VAL} value The value of the element to add
   * @return {VAL}
   */
  set(key, value) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeMapSet(
          transaction,
          this,
          key,
          /** @type {any} */
          value
        );
      });
    } else {
      this._prelimContent.set(key, value);
    }
    return value;
  }
  /**
   * Returns a specified element from this YMap.
   *
   * @param {string} key
   * @return {MapType|undefined}
   */
  get(key) {
    return (
      /** @type {any} */
      typeMapGet(this, key)
    );
  }
  /**
   * Returns a boolean indicating whether the specified key exists or not.
   *
   * @param {string} key The key to test.
   * @return {boolean}
   */
  has(key) {
    return typeMapHas(this, key);
  }
  /**
   * Removes all elements from this YMap.
   */
  clear() {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        this.forEach(function(_value, key, map2) {
          typeMapDelete(transaction, map2, key);
        });
      });
    } else {
      this._prelimContent.clear();
    }
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   */
  _write(encoder) {
    encoder.writeTypeRef(YMapRefID);
  }
};
var readYMap = (_decoder) => new YMap();
var equalAttrs = (a, b) => a === b || typeof a === "object" && typeof b === "object" && a && b && equalFlat(a, b);
var ItemTextListPosition = class {
  /**
   * @param {Item|null} left
   * @param {Item|null} right
   * @param {number} index
   * @param {Map<string,any>} currentAttributes
   */
  constructor(left, right, index, currentAttributes) {
    this.left = left;
    this.right = right;
    this.index = index;
    this.currentAttributes = currentAttributes;
  }
  /**
   * Only call this if you know that this.right is defined
   */
  forward() {
    if (this.right === null) {
      unexpectedCase();
    }
    switch (this.right.content.constructor) {
      case ContentFormat:
        if (!this.right.deleted) {
          updateCurrentAttributes(
            this.currentAttributes,
            /** @type {ContentFormat} */
            this.right.content
          );
        }
        break;
      default:
        if (!this.right.deleted) {
          this.index += this.right.length;
        }
        break;
    }
    this.left = this.right;
    this.right = this.right.right;
  }
};
var findNextPosition = (transaction, pos, count) => {
  while (pos.right !== null && count > 0) {
    switch (pos.right.content.constructor) {
      case ContentFormat:
        if (!pos.right.deleted) {
          updateCurrentAttributes(
            pos.currentAttributes,
            /** @type {ContentFormat} */
            pos.right.content
          );
        }
        break;
      default:
        if (!pos.right.deleted) {
          if (count < pos.right.length) {
            getItemCleanStart(transaction, createID(pos.right.id.client, pos.right.id.clock + count));
          }
          pos.index += pos.right.length;
          count -= pos.right.length;
        }
        break;
    }
    pos.left = pos.right;
    pos.right = pos.right.right;
  }
  return pos;
};
var findPosition = (transaction, parent, index, useSearchMarker) => {
  const currentAttributes = /* @__PURE__ */ new Map();
  const marker = useSearchMarker ? findMarker(parent, index) : null;
  if (marker) {
    const pos = new ItemTextListPosition(marker.p.left, marker.p, marker.index, currentAttributes);
    return findNextPosition(transaction, pos, index - marker.index);
  } else {
    const pos = new ItemTextListPosition(null, parent._start, 0, currentAttributes);
    return findNextPosition(transaction, pos, index);
  }
};
var insertNegatedAttributes = (transaction, parent, currPos, negatedAttributes) => {
  while (currPos.right !== null && (currPos.right.deleted === true || currPos.right.content.constructor === ContentFormat && equalAttrs(
    negatedAttributes.get(
      /** @type {ContentFormat} */
      currPos.right.content.key
    ),
    /** @type {ContentFormat} */
    currPos.right.content.value
  ))) {
    if (!currPos.right.deleted) {
      negatedAttributes.delete(
        /** @type {ContentFormat} */
        currPos.right.content.key
      );
    }
    currPos.forward();
  }
  const doc2 = transaction.doc;
  const ownClientId = doc2.clientID;
  negatedAttributes.forEach((val, key) => {
    const left = currPos.left;
    const right = currPos.right;
    const nextFormat = new Item(createID(ownClientId, getState(doc2.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentFormat(key, val));
    nextFormat.integrate(transaction, 0);
    currPos.right = nextFormat;
    currPos.forward();
  });
};
var updateCurrentAttributes = (currentAttributes, format) => {
  const { key, value } = format;
  if (value === null) {
    currentAttributes.delete(key);
  } else {
    currentAttributes.set(key, value);
  }
};
var minimizeAttributeChanges = (currPos, attributes) => {
  while (true) {
    if (currPos.right === null) {
      break;
    } else if (currPos.right.deleted || currPos.right.content.constructor === ContentFormat && equalAttrs(
      attributes[
        /** @type {ContentFormat} */
        currPos.right.content.key
      ] ?? null,
      /** @type {ContentFormat} */
      currPos.right.content.value
    )) ;
    else {
      break;
    }
    currPos.forward();
  }
};
var insertAttributes = (transaction, parent, currPos, attributes) => {
  const doc2 = transaction.doc;
  const ownClientId = doc2.clientID;
  const negatedAttributes = /* @__PURE__ */ new Map();
  for (const key in attributes) {
    const val = attributes[key];
    const currentVal = currPos.currentAttributes.get(key) ?? null;
    if (!equalAttrs(currentVal, val)) {
      negatedAttributes.set(key, currentVal);
      const { left, right } = currPos;
      currPos.right = new Item(createID(ownClientId, getState(doc2.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentFormat(key, val));
      currPos.right.integrate(transaction, 0);
      currPos.forward();
    }
  }
  return negatedAttributes;
};
var insertText = (transaction, parent, currPos, text2, attributes) => {
  currPos.currentAttributes.forEach((_val, key) => {
    if (attributes[key] === void 0) {
      attributes[key] = null;
    }
  });
  const doc2 = transaction.doc;
  const ownClientId = doc2.clientID;
  minimizeAttributeChanges(currPos, attributes);
  const negatedAttributes = insertAttributes(transaction, parent, currPos, attributes);
  const content2 = text2.constructor === String ? new ContentString(
    /** @type {string} */
    text2
  ) : text2 instanceof AbstractType ? new ContentType(text2) : new ContentEmbed(text2);
  let { left, right, index } = currPos;
  if (parent._searchMarker) {
    updateMarkerChanges(parent._searchMarker, currPos.index, content2.getLength());
  }
  right = new Item(createID(ownClientId, getState(doc2.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, content2);
  right.integrate(transaction, 0);
  currPos.right = right;
  currPos.index = index;
  currPos.forward();
  insertNegatedAttributes(transaction, parent, currPos, negatedAttributes);
};
var formatText = (transaction, parent, currPos, length2, attributes) => {
  const doc2 = transaction.doc;
  const ownClientId = doc2.clientID;
  minimizeAttributeChanges(currPos, attributes);
  const negatedAttributes = insertAttributes(transaction, parent, currPos, attributes);
  iterationLoop: while (currPos.right !== null && (length2 > 0 || negatedAttributes.size > 0 && (currPos.right.deleted || currPos.right.content.constructor === ContentFormat))) {
    if (!currPos.right.deleted) {
      switch (currPos.right.content.constructor) {
        case ContentFormat: {
          const { key, value } = (
            /** @type {ContentFormat} */
            currPos.right.content
          );
          const attr = attributes[key];
          if (attr !== void 0) {
            if (equalAttrs(attr, value)) {
              negatedAttributes.delete(key);
            } else {
              if (length2 === 0) {
                break iterationLoop;
              }
              negatedAttributes.set(key, value);
            }
            currPos.right.delete(transaction);
          } else {
            currPos.currentAttributes.set(key, value);
          }
          break;
        }
        default:
          if (length2 < currPos.right.length) {
            getItemCleanStart(transaction, createID(currPos.right.id.client, currPos.right.id.clock + length2));
          }
          length2 -= currPos.right.length;
          break;
      }
    }
    currPos.forward();
  }
  if (length2 > 0) {
    let newlines = "";
    for (; length2 > 0; length2--) {
      newlines += "\n";
    }
    currPos.right = new Item(createID(ownClientId, getState(doc2.store, ownClientId)), currPos.left, currPos.left && currPos.left.lastId, currPos.right, currPos.right && currPos.right.id, parent, null, new ContentString(newlines));
    currPos.right.integrate(transaction, 0);
    currPos.forward();
  }
  insertNegatedAttributes(transaction, parent, currPos, negatedAttributes);
};
var cleanupFormattingGap = (transaction, start, curr, startAttributes, currAttributes) => {
  let end = start;
  const endFormats = create();
  while (end && (!end.countable || end.deleted)) {
    if (!end.deleted && end.content.constructor === ContentFormat) {
      const cf = (
        /** @type {ContentFormat} */
        end.content
      );
      endFormats.set(cf.key, cf);
    }
    end = end.right;
  }
  let cleanups = 0;
  let reachedCurr = false;
  while (start !== end) {
    if (curr === start) {
      reachedCurr = true;
    }
    if (!start.deleted) {
      const content2 = start.content;
      switch (content2.constructor) {
        case ContentFormat: {
          const { key, value } = (
            /** @type {ContentFormat} */
            content2
          );
          const startAttrValue = startAttributes.get(key) ?? null;
          if (endFormats.get(key) !== content2 || startAttrValue === value) {
            start.delete(transaction);
            cleanups++;
            if (!reachedCurr && (currAttributes.get(key) ?? null) === value && startAttrValue !== value) {
              if (startAttrValue === null) {
                currAttributes.delete(key);
              } else {
                currAttributes.set(key, startAttrValue);
              }
            }
          }
          if (!reachedCurr && !start.deleted) {
            updateCurrentAttributes(
              currAttributes,
              /** @type {ContentFormat} */
              content2
            );
          }
          break;
        }
      }
    }
    start = /** @type {Item} */
    start.right;
  }
  return cleanups;
};
var cleanupContextlessFormattingGap = (transaction, item) => {
  while (item && item.right && (item.right.deleted || !item.right.countable)) {
    item = item.right;
  }
  const attrs = /* @__PURE__ */ new Set();
  while (item && (item.deleted || !item.countable)) {
    if (!item.deleted && item.content.constructor === ContentFormat) {
      const key = (
        /** @type {ContentFormat} */
        item.content.key
      );
      if (attrs.has(key)) {
        item.delete(transaction);
      } else {
        attrs.add(key);
      }
    }
    item = item.left;
  }
};
var cleanupYTextFormatting = (type) => {
  let res = 0;
  transact(
    /** @type {Doc} */
    type.doc,
    (transaction) => {
      let start = (
        /** @type {Item} */
        type._start
      );
      let end = type._start;
      let startAttributes = create();
      const currentAttributes = copy(startAttributes);
      while (end) {
        if (end.deleted === false) {
          switch (end.content.constructor) {
            case ContentFormat:
              updateCurrentAttributes(
                currentAttributes,
                /** @type {ContentFormat} */
                end.content
              );
              break;
            default:
              res += cleanupFormattingGap(transaction, start, end, startAttributes, currentAttributes);
              startAttributes = copy(currentAttributes);
              start = end;
              break;
          }
        }
        end = end.right;
      }
    }
  );
  return res;
};
var cleanupYTextAfterTransaction = (transaction) => {
  const needFullCleanup = /* @__PURE__ */ new Set();
  const doc2 = transaction.doc;
  for (const [client, afterClock] of transaction.afterState.entries()) {
    const clock = transaction.beforeState.get(client) || 0;
    if (afterClock === clock) {
      continue;
    }
    iterateStructs(
      transaction,
      /** @type {Array<Item|GC>} */
      doc2.store.clients.get(client),
      clock,
      afterClock,
      (item) => {
        if (!item.deleted && /** @type {Item} */
        item.content.constructor === ContentFormat && item.constructor !== GC) {
          needFullCleanup.add(
            /** @type {any} */
            item.parent
          );
        }
      }
    );
  }
  transact(doc2, (t) => {
    iterateDeletedStructs(transaction, transaction.deleteSet, (item) => {
      if (item instanceof GC || !/** @type {YText} */
      item.parent._hasFormatting || needFullCleanup.has(
        /** @type {YText} */
        item.parent
      )) {
        return;
      }
      const parent = (
        /** @type {YText} */
        item.parent
      );
      if (item.content.constructor === ContentFormat) {
        needFullCleanup.add(parent);
      } else {
        cleanupContextlessFormattingGap(t, item);
      }
    });
    for (const yText of needFullCleanup) {
      cleanupYTextFormatting(yText);
    }
  });
};
var deleteText = (transaction, currPos, length2) => {
  const startLength = length2;
  const startAttrs = copy(currPos.currentAttributes);
  const start = currPos.right;
  while (length2 > 0 && currPos.right !== null) {
    if (currPos.right.deleted === false) {
      switch (currPos.right.content.constructor) {
        case ContentType:
        case ContentEmbed:
        case ContentString:
          if (length2 < currPos.right.length) {
            getItemCleanStart(transaction, createID(currPos.right.id.client, currPos.right.id.clock + length2));
          }
          length2 -= currPos.right.length;
          currPos.right.delete(transaction);
          break;
      }
    }
    currPos.forward();
  }
  if (start) {
    cleanupFormattingGap(transaction, start, currPos.right, startAttrs, currPos.currentAttributes);
  }
  const parent = (
    /** @type {AbstractType<any>} */
    /** @type {Item} */
    (currPos.left || currPos.right).parent
  );
  if (parent._searchMarker) {
    updateMarkerChanges(parent._searchMarker, currPos.index, -startLength + length2);
  }
  return currPos;
};
var YTextEvent = class extends YEvent {
  /**
   * @param {YText} ytext
   * @param {Transaction} transaction
   * @param {Set<any>} subs The keys that changed
   */
  constructor(ytext, transaction, subs) {
    super(ytext, transaction);
    this.childListChanged = false;
    this.keysChanged = /* @__PURE__ */ new Set();
    subs.forEach((sub) => {
      if (sub === null) {
        this.childListChanged = true;
      } else {
        this.keysChanged.add(sub);
      }
    });
  }
  /**
   * @type {{added:Set<Item>,deleted:Set<Item>,keys:Map<string,{action:'add'|'update'|'delete',oldValue:any}>,delta:Array<{insert?:Array<any>|string, delete?:number, retain?:number}>}}
   */
  get changes() {
    if (this._changes === null) {
      const changes = {
        keys: this.keys,
        delta: this.delta,
        added: /* @__PURE__ */ new Set(),
        deleted: /* @__PURE__ */ new Set()
      };
      this._changes = changes;
    }
    return (
      /** @type {any} */
      this._changes
    );
  }
  /**
   * Compute the changes in the delta format.
   * A {@link https://quilljs.com/docs/delta/|Quill Delta}) that represents the changes on the document.
   *
   * @type {Array<{insert?:string|object|AbstractType<any>, delete?:number, retain?:number, attributes?: Object<string,any>}>}
   *
   * @public
   */
  get delta() {
    if (this._delta === null) {
      const y = (
        /** @type {Doc} */
        this.target.doc
      );
      const delta = [];
      transact(y, (transaction) => {
        const currentAttributes = /* @__PURE__ */ new Map();
        const oldAttributes = /* @__PURE__ */ new Map();
        let item = this.target._start;
        let action = null;
        const attributes = {};
        let insert = "";
        let retain = 0;
        let deleteLen = 0;
        const addOp = () => {
          if (action !== null) {
            let op = null;
            switch (action) {
              case "delete":
                if (deleteLen > 0) {
                  op = { delete: deleteLen };
                }
                deleteLen = 0;
                break;
              case "insert":
                if (typeof insert === "object" || insert.length > 0) {
                  op = { insert };
                  if (currentAttributes.size > 0) {
                    op.attributes = {};
                    currentAttributes.forEach((value, key) => {
                      if (value !== null) {
                        op.attributes[key] = value;
                      }
                    });
                  }
                }
                insert = "";
                break;
              case "retain":
                if (retain > 0) {
                  op = { retain };
                  if (!isEmpty(attributes)) {
                    op.attributes = assign({}, attributes);
                  }
                }
                retain = 0;
                break;
            }
            if (op) delta.push(op);
            action = null;
          }
        };
        while (item !== null) {
          switch (item.content.constructor) {
            case ContentType:
            case ContentEmbed:
              if (this.adds(item)) {
                if (!this.deletes(item)) {
                  addOp();
                  action = "insert";
                  insert = item.content.getContent()[0];
                  addOp();
                }
              } else if (this.deletes(item)) {
                if (action !== "delete") {
                  addOp();
                  action = "delete";
                }
                deleteLen += 1;
              } else if (!item.deleted) {
                if (action !== "retain") {
                  addOp();
                  action = "retain";
                }
                retain += 1;
              }
              break;
            case ContentString:
              if (this.adds(item)) {
                if (!this.deletes(item)) {
                  if (action !== "insert") {
                    addOp();
                    action = "insert";
                  }
                  insert += /** @type {ContentString} */
                  item.content.str;
                }
              } else if (this.deletes(item)) {
                if (action !== "delete") {
                  addOp();
                  action = "delete";
                }
                deleteLen += item.length;
              } else if (!item.deleted) {
                if (action !== "retain") {
                  addOp();
                  action = "retain";
                }
                retain += item.length;
              }
              break;
            case ContentFormat: {
              const { key, value } = (
                /** @type {ContentFormat} */
                item.content
              );
              if (this.adds(item)) {
                if (!this.deletes(item)) {
                  const curVal = currentAttributes.get(key) ?? null;
                  if (!equalAttrs(curVal, value)) {
                    if (action === "retain") {
                      addOp();
                    }
                    if (equalAttrs(value, oldAttributes.get(key) ?? null)) {
                      delete attributes[key];
                    } else {
                      attributes[key] = value;
                    }
                  } else if (value !== null) {
                    item.delete(transaction);
                  }
                }
              } else if (this.deletes(item)) {
                oldAttributes.set(key, value);
                const curVal = currentAttributes.get(key) ?? null;
                if (!equalAttrs(curVal, value)) {
                  if (action === "retain") {
                    addOp();
                  }
                  attributes[key] = curVal;
                }
              } else if (!item.deleted) {
                oldAttributes.set(key, value);
                const attr = attributes[key];
                if (attr !== void 0) {
                  if (!equalAttrs(attr, value)) {
                    if (action === "retain") {
                      addOp();
                    }
                    if (value === null) {
                      delete attributes[key];
                    } else {
                      attributes[key] = value;
                    }
                  } else if (attr !== null) {
                    item.delete(transaction);
                  }
                }
              }
              if (!item.deleted) {
                if (action === "insert") {
                  addOp();
                }
                updateCurrentAttributes(
                  currentAttributes,
                  /** @type {ContentFormat} */
                  item.content
                );
              }
              break;
            }
          }
          item = item.right;
        }
        addOp();
        while (delta.length > 0) {
          const lastOp = delta[delta.length - 1];
          if (lastOp.retain !== void 0 && lastOp.attributes === void 0) {
            delta.pop();
          } else {
            break;
          }
        }
      });
      this._delta = delta;
    }
    return (
      /** @type {any} */
      this._delta
    );
  }
};
var YText = class _YText extends AbstractType {
  /**
   * @param {String} [string] The initial value of the YText.
   */
  constructor(string) {
    super();
    this._pending = string !== void 0 ? [() => this.insert(0, string)] : [];
    this._searchMarker = [];
    this._hasFormatting = false;
  }
  /**
   * Number of characters of this text type.
   *
   * @type {number}
   */
  get length() {
    this.doc ?? warnPrematureAccess();
    return this._length;
  }
  /**
   * @param {Doc} y
   * @param {Item} item
   */
  _integrate(y, item) {
    super._integrate(y, item);
    try {
      this._pending.forEach((f) => f());
    } catch (e) {
      console.error(e);
    }
    this._pending = null;
  }
  _copy() {
    return new _YText();
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YText}
   */
  clone() {
    const text2 = new _YText();
    text2.applyDelta(this.toDelta());
    return text2;
  }
  /**
   * Creates YTextEvent and calls observers.
   *
   * @param {Transaction} transaction
   * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
   */
  _callObserver(transaction, parentSubs) {
    super._callObserver(transaction, parentSubs);
    const event = new YTextEvent(this, transaction, parentSubs);
    callTypeObservers(this, transaction, event);
    if (!transaction.local && this._hasFormatting) {
      transaction._needFormattingCleanup = true;
    }
  }
  /**
   * Returns the unformatted string representation of this YText type.
   *
   * @public
   */
  toString() {
    this.doc ?? warnPrematureAccess();
    let str = "";
    let n = this._start;
    while (n !== null) {
      if (!n.deleted && n.countable && n.content.constructor === ContentString) {
        str += /** @type {ContentString} */
        n.content.str;
      }
      n = n.right;
    }
    return str;
  }
  /**
   * Returns the unformatted string representation of this YText type.
   *
   * @return {string}
   * @public
   */
  toJSON() {
    return this.toString();
  }
  /**
   * Apply a {@link Delta} on this shared YText type.
   *
   * @param {Array<any>} delta The changes to apply on this element.
   * @param {object}  opts
   * @param {boolean} [opts.sanitize] Sanitize input delta. Removes ending newlines if set to true.
   *
   *
   * @public
   */
  applyDelta(delta, { sanitize = true } = {}) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        const currPos = new ItemTextListPosition(null, this._start, 0, /* @__PURE__ */ new Map());
        for (let i = 0; i < delta.length; i++) {
          const op = delta[i];
          if (op.insert !== void 0) {
            const ins = !sanitize && typeof op.insert === "string" && i === delta.length - 1 && currPos.right === null && op.insert.slice(-1) === "\n" ? op.insert.slice(0, -1) : op.insert;
            if (typeof ins !== "string" || ins.length > 0) {
              insertText(transaction, this, currPos, ins, op.attributes || {});
            }
          } else if (op.retain !== void 0) {
            formatText(transaction, this, currPos, op.retain, op.attributes || {});
          } else if (op.delete !== void 0) {
            deleteText(transaction, currPos, op.delete);
          }
        }
      });
    } else {
      this._pending.push(() => this.applyDelta(delta));
    }
  }
  /**
   * Returns the Delta representation of this YText type.
   *
   * @param {Snapshot} [snapshot]
   * @param {Snapshot} [prevSnapshot]
   * @param {function('removed' | 'added', ID):any} [computeYChange]
   * @return {any} The Delta representation of this type.
   *
   * @public
   */
  toDelta(snapshot, prevSnapshot, computeYChange) {
    this.doc ?? warnPrematureAccess();
    const ops = [];
    const currentAttributes = /* @__PURE__ */ new Map();
    const doc2 = (
      /** @type {Doc} */
      this.doc
    );
    let str = "";
    let n = this._start;
    function packStr() {
      if (str.length > 0) {
        const attributes = {};
        let addAttributes = false;
        currentAttributes.forEach((value, key) => {
          addAttributes = true;
          attributes[key] = value;
        });
        const op = { insert: str };
        if (addAttributes) {
          op.attributes = attributes;
        }
        ops.push(op);
        str = "";
      }
    }
    const computeDelta = () => {
      while (n !== null) {
        if (isVisible(n, snapshot) || prevSnapshot !== void 0 && isVisible(n, prevSnapshot)) {
          switch (n.content.constructor) {
            case ContentString: {
              const cur = currentAttributes.get("ychange");
              if (snapshot !== void 0 && !isVisible(n, snapshot)) {
                if (cur === void 0 || cur.user !== n.id.client || cur.type !== "removed") {
                  packStr();
                  currentAttributes.set("ychange", computeYChange ? computeYChange("removed", n.id) : { type: "removed" });
                }
              } else if (prevSnapshot !== void 0 && !isVisible(n, prevSnapshot)) {
                if (cur === void 0 || cur.user !== n.id.client || cur.type !== "added") {
                  packStr();
                  currentAttributes.set("ychange", computeYChange ? computeYChange("added", n.id) : { type: "added" });
                }
              } else if (cur !== void 0) {
                packStr();
                currentAttributes.delete("ychange");
              }
              str += /** @type {ContentString} */
              n.content.str;
              break;
            }
            case ContentType:
            case ContentEmbed: {
              packStr();
              const op = {
                insert: n.content.getContent()[0]
              };
              if (currentAttributes.size > 0) {
                const attrs = (
                  /** @type {Object<string,any>} */
                  {}
                );
                op.attributes = attrs;
                currentAttributes.forEach((value, key) => {
                  attrs[key] = value;
                });
              }
              ops.push(op);
              break;
            }
            case ContentFormat:
              if (isVisible(n, snapshot)) {
                packStr();
                updateCurrentAttributes(
                  currentAttributes,
                  /** @type {ContentFormat} */
                  n.content
                );
              }
              break;
          }
        }
        n = n.right;
      }
      packStr();
    };
    if (snapshot || prevSnapshot) {
      transact(doc2, (transaction) => {
        if (snapshot) {
          splitSnapshotAffectedStructs(transaction, snapshot);
        }
        if (prevSnapshot) {
          splitSnapshotAffectedStructs(transaction, prevSnapshot);
        }
        computeDelta();
      }, "cleanup");
    } else {
      computeDelta();
    }
    return ops;
  }
  /**
   * Insert text at a given index.
   *
   * @param {number} index The index at which to start inserting.
   * @param {String} text The text to insert at the specified position.
   * @param {TextAttributes} [attributes] Optionally define some formatting
   *                                    information to apply on the inserted
   *                                    Text.
   * @public
   */
  insert(index, text2, attributes) {
    if (text2.length <= 0) {
      return;
    }
    const y = this.doc;
    if (y !== null) {
      transact(y, (transaction) => {
        const pos = findPosition(transaction, this, index, !attributes);
        if (!attributes) {
          attributes = {};
          pos.currentAttributes.forEach((v, k) => {
            attributes[k] = v;
          });
        }
        insertText(transaction, this, pos, text2, attributes);
      });
    } else {
      this._pending.push(() => this.insert(index, text2, attributes));
    }
  }
  /**
   * Inserts an embed at a index.
   *
   * @param {number} index The index to insert the embed at.
   * @param {Object | AbstractType<any>} embed The Object that represents the embed.
   * @param {TextAttributes} [attributes] Attribute information to apply on the
   *                                    embed
   *
   * @public
   */
  insertEmbed(index, embed, attributes) {
    const y = this.doc;
    if (y !== null) {
      transact(y, (transaction) => {
        const pos = findPosition(transaction, this, index, !attributes);
        insertText(transaction, this, pos, embed, attributes || {});
      });
    } else {
      this._pending.push(() => this.insertEmbed(index, embed, attributes || {}));
    }
  }
  /**
   * Deletes text starting from an index.
   *
   * @param {number} index Index at which to start deleting.
   * @param {number} length The number of characters to remove. Defaults to 1.
   *
   * @public
   */
  delete(index, length2) {
    if (length2 === 0) {
      return;
    }
    const y = this.doc;
    if (y !== null) {
      transact(y, (transaction) => {
        deleteText(transaction, findPosition(transaction, this, index, true), length2);
      });
    } else {
      this._pending.push(() => this.delete(index, length2));
    }
  }
  /**
   * Assigns properties to a range of text.
   *
   * @param {number} index The position where to start formatting.
   * @param {number} length The amount of characters to assign properties to.
   * @param {TextAttributes} attributes Attribute information to apply on the
   *                                    text.
   *
   * @public
   */
  format(index, length2, attributes) {
    if (length2 === 0) {
      return;
    }
    const y = this.doc;
    if (y !== null) {
      transact(y, (transaction) => {
        const pos = findPosition(transaction, this, index, false);
        if (pos.right === null) {
          return;
        }
        formatText(transaction, this, pos, length2, attributes);
      });
    } else {
      this._pending.push(() => this.format(index, length2, attributes));
    }
  }
  /**
   * Removes an attribute.
   *
   * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
   *
   * @param {String} attributeName The attribute name that is to be removed.
   *
   * @public
   */
  removeAttribute(attributeName) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeMapDelete(transaction, this, attributeName);
      });
    } else {
      this._pending.push(() => this.removeAttribute(attributeName));
    }
  }
  /**
   * Sets or updates an attribute.
   *
   * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
   *
   * @param {String} attributeName The attribute name that is to be set.
   * @param {any} attributeValue The attribute value that is to be set.
   *
   * @public
   */
  setAttribute(attributeName, attributeValue) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeMapSet(transaction, this, attributeName, attributeValue);
      });
    } else {
      this._pending.push(() => this.setAttribute(attributeName, attributeValue));
    }
  }
  /**
   * Returns an attribute value that belongs to the attribute name.
   *
   * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
   *
   * @param {String} attributeName The attribute name that identifies the
   *                               queried value.
   * @return {any} The queried attribute value.
   *
   * @public
   */
  getAttribute(attributeName) {
    return (
      /** @type {any} */
      typeMapGet(this, attributeName)
    );
  }
  /**
   * Returns all attribute name/value pairs in a JSON Object.
   *
   * @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
   *
   * @return {Object<string, any>} A JSON Object that describes the attributes.
   *
   * @public
   */
  getAttributes() {
    return typeMapGetAll(this);
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   */
  _write(encoder) {
    encoder.writeTypeRef(YTextRefID);
  }
};
var readYText = (_decoder) => new YText();
var YXmlTreeWalker = class {
  /**
   * @param {YXmlFragment | YXmlElement} root
   * @param {function(AbstractType<any>):boolean} [f]
   */
  constructor(root, f = () => true) {
    this._filter = f;
    this._root = root;
    this._currentNode = /** @type {Item} */
    root._start;
    this._firstCall = true;
    root.doc ?? warnPrematureAccess();
  }
  [Symbol.iterator]() {
    return this;
  }
  /**
   * Get the next node.
   *
   * @return {IteratorResult<YXmlElement|YXmlText|YXmlHook>} The next node.
   *
   * @public
   */
  next() {
    let n = this._currentNode;
    let type = n && n.content && /** @type {any} */
    n.content.type;
    if (n !== null && (!this._firstCall || n.deleted || !this._filter(type))) {
      do {
        type = /** @type {any} */
        n.content.type;
        if (!n.deleted && (type.constructor === YXmlElement || type.constructor === YXmlFragment) && type._start !== null) {
          n = type._start;
        } else {
          while (n !== null) {
            const nxt = n.next;
            if (nxt !== null) {
              n = nxt;
              break;
            } else if (n.parent === this._root) {
              n = null;
            } else {
              n = /** @type {AbstractType<any>} */
              n.parent._item;
            }
          }
        }
      } while (n !== null && (n.deleted || !this._filter(
        /** @type {ContentType} */
        n.content.type
      )));
    }
    this._firstCall = false;
    if (n === null) {
      return { value: void 0, done: true };
    }
    this._currentNode = n;
    return { value: (
      /** @type {any} */
      n.content.type
    ), done: false };
  }
};
var YXmlFragment = class _YXmlFragment extends AbstractType {
  constructor() {
    super();
    this._prelimContent = [];
  }
  /**
   * @type {YXmlElement|YXmlText|null}
   */
  get firstChild() {
    const first = this._first;
    return first ? first.content.getContent()[0] : null;
  }
  /**
   * Integrate this type into the Yjs instance.
   *
   * * Save this struct in the os
   * * This type is sent to other client
   * * Observer functions are fired
   *
   * @param {Doc} y The Yjs instance
   * @param {Item} item
   */
  _integrate(y, item) {
    super._integrate(y, item);
    this.insert(
      0,
      /** @type {Array<any>} */
      this._prelimContent
    );
    this._prelimContent = null;
  }
  _copy() {
    return new _YXmlFragment();
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YXmlFragment}
   */
  clone() {
    const el = new _YXmlFragment();
    el.insert(0, this.toArray().map((item) => item instanceof AbstractType ? item.clone() : item));
    return el;
  }
  get length() {
    this.doc ?? warnPrematureAccess();
    return this._prelimContent === null ? this._length : this._prelimContent.length;
  }
  /**
   * Create a subtree of childNodes.
   *
   * @example
   * const walker = elem.createTreeWalker(dom => dom.nodeName === 'div')
   * for (let node in walker) {
   *   // `node` is a div node
   *   nop(node)
   * }
   *
   * @param {function(AbstractType<any>):boolean} filter Function that is called on each child element and
   *                          returns a Boolean indicating whether the child
   *                          is to be included in the subtree.
   * @return {YXmlTreeWalker} A subtree and a position within it.
   *
   * @public
   */
  createTreeWalker(filter) {
    return new YXmlTreeWalker(this, filter);
  }
  /**
   * Returns the first YXmlElement that matches the query.
   * Similar to DOM's {@link querySelector}.
   *
   * Query support:
   *   - tagname
   * TODO:
   *   - id
   *   - attribute
   *
   * @param {CSS_Selector} query The query on the children.
   * @return {YXmlElement|YXmlText|YXmlHook|null} The first element that matches the query or null.
   *
   * @public
   */
  querySelector(query) {
    query = query.toUpperCase();
    const iterator = new YXmlTreeWalker(this, (element2) => element2.nodeName && element2.nodeName.toUpperCase() === query);
    const next = iterator.next();
    if (next.done) {
      return null;
    } else {
      return next.value;
    }
  }
  /**
   * Returns all YXmlElements that match the query.
   * Similar to Dom's {@link querySelectorAll}.
   *
   * @todo Does not yet support all queries. Currently only query by tagName.
   *
   * @param {CSS_Selector} query The query on the children
   * @return {Array<YXmlElement|YXmlText|YXmlHook|null>} The elements that match this query.
   *
   * @public
   */
  querySelectorAll(query) {
    query = query.toUpperCase();
    return from(new YXmlTreeWalker(this, (element2) => element2.nodeName && element2.nodeName.toUpperCase() === query));
  }
  /**
   * Creates YXmlEvent and calls observers.
   *
   * @param {Transaction} transaction
   * @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
   */
  _callObserver(transaction, parentSubs) {
    callTypeObservers(this, transaction, new YXmlEvent(this, parentSubs, transaction));
  }
  /**
   * Get the string representation of all the children of this YXmlFragment.
   *
   * @return {string} The string representation of all children.
   */
  toString() {
    return typeListMap(this, (xml) => xml.toString()).join("");
  }
  /**
   * @return {string}
   */
  toJSON() {
    return this.toString();
  }
  /**
   * Creates a Dom Element that mirrors this YXmlElement.
   *
   * @param {Document} [_document=document] The document object (you must define
   *                                        this when calling this method in
   *                                        nodejs)
   * @param {Object<string, any>} [hooks={}] Optional property to customize how hooks
   *                                             are presented in the DOM
   * @param {any} [binding] You should not set this property. This is
   *                               used if DomBinding wants to create a
   *                               association to the created DOM type.
   * @return {Node} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
   *
   * @public
   */
  toDOM(_document = document, hooks = {}, binding) {
    const fragment2 = _document.createDocumentFragment();
    if (binding !== void 0) {
      binding._createAssociation(fragment2, this);
    }
    typeListForEach(this, (xmlType) => {
      fragment2.insertBefore(xmlType.toDOM(_document, hooks, binding), null);
    });
    return fragment2;
  }
  /**
   * Inserts new content at an index.
   *
   * @example
   *  // Insert character 'a' at position 0
   *  xml.insert(0, [new Y.XmlText('text')])
   *
   * @param {number} index The index to insert content at
   * @param {Array<YXmlElement|YXmlText>} content The array of content
   */
  insert(index, content2) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeListInsertGenerics(transaction, this, index, content2);
      });
    } else {
      this._prelimContent.splice(index, 0, ...content2);
    }
  }
  /**
   * Inserts new content at an index.
   *
   * @example
   *  // Insert character 'a' at position 0
   *  xml.insert(0, [new Y.XmlText('text')])
   *
   * @param {null|Item|YXmlElement|YXmlText} ref The index to insert content at
   * @param {Array<YXmlElement|YXmlText>} content The array of content
   */
  insertAfter(ref, content2) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        const refItem = ref && ref instanceof AbstractType ? ref._item : ref;
        typeListInsertGenericsAfter(transaction, this, refItem, content2);
      });
    } else {
      const pc = (
        /** @type {Array<any>} */
        this._prelimContent
      );
      const index = ref === null ? 0 : pc.findIndex((el) => el === ref) + 1;
      if (index === 0 && ref !== null) {
        throw create3("Reference item not found");
      }
      pc.splice(index, 0, ...content2);
    }
  }
  /**
   * Deletes elements starting from an index.
   *
   * @param {number} index Index at which to start deleting elements
   * @param {number} [length=1] The number of elements to remove. Defaults to 1.
   */
  delete(index, length2 = 1) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeListDelete(transaction, this, index, length2);
      });
    } else {
      this._prelimContent.splice(index, length2);
    }
  }
  /**
   * Transforms this YArray to a JavaScript Array.
   *
   * @return {Array<YXmlElement|YXmlText|YXmlHook>}
   */
  toArray() {
    return typeListToArray(this);
  }
  /**
   * Appends content to this YArray.
   *
   * @param {Array<YXmlElement|YXmlText>} content Array of content to append.
   */
  push(content2) {
    this.insert(this.length, content2);
  }
  /**
   * Prepends content to this YArray.
   *
   * @param {Array<YXmlElement|YXmlText>} content Array of content to prepend.
   */
  unshift(content2) {
    this.insert(0, content2);
  }
  /**
   * Returns the i-th element from a YArray.
   *
   * @param {number} index The index of the element to return from the YArray
   * @return {YXmlElement|YXmlText}
   */
  get(index) {
    return typeListGet(this, index);
  }
  /**
   * Returns a portion of this YXmlFragment into a JavaScript Array selected
   * from start to end (end not included).
   *
   * @param {number} [start]
   * @param {number} [end]
   * @return {Array<YXmlElement|YXmlText>}
   */
  slice(start = 0, end = this.length) {
    return typeListSlice(this, start, end);
  }
  /**
   * Executes a provided function on once on every child element.
   *
   * @param {function(YXmlElement|YXmlText,number, typeof self):void} f A function to execute on every element of this YArray.
   */
  forEach(f) {
    typeListForEach(this, f);
  }
  /**
   * Transform the properties of this type to binary and write it to an
   * BinaryEncoder.
   *
   * This is called when this Item is sent to a remote peer.
   *
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
   */
  _write(encoder) {
    encoder.writeTypeRef(YXmlFragmentRefID);
  }
};
var readYXmlFragment = (_decoder) => new YXmlFragment();
var YXmlElement = class _YXmlElement extends YXmlFragment {
  constructor(nodeName = "UNDEFINED") {
    super();
    this.nodeName = nodeName;
    this._prelimAttrs = /* @__PURE__ */ new Map();
  }
  /**
   * @type {YXmlElement|YXmlText|null}
   */
  get nextSibling() {
    const n = this._item ? this._item.next : null;
    return n ? (
      /** @type {YXmlElement|YXmlText} */
      /** @type {ContentType} */
      n.content.type
    ) : null;
  }
  /**
   * @type {YXmlElement|YXmlText|null}
   */
  get prevSibling() {
    const n = this._item ? this._item.prev : null;
    return n ? (
      /** @type {YXmlElement|YXmlText} */
      /** @type {ContentType} */
      n.content.type
    ) : null;
  }
  /**
   * Integrate this type into the Yjs instance.
   *
   * * Save this struct in the os
   * * This type is sent to other client
   * * Observer functions are fired
   *
   * @param {Doc} y The Yjs instance
   * @param {Item} item
   */
  _integrate(y, item) {
    super._integrate(y, item);
    /** @type {Map<string, any>} */
    this._prelimAttrs.forEach((value, key) => {
      this.setAttribute(key, value);
    });
    this._prelimAttrs = null;
  }
  /**
   * Creates an Item with the same effect as this Item (without position effect)
   *
   * @return {YXmlElement}
   */
  _copy() {
    return new _YXmlElement(this.nodeName);
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YXmlElement<KV>}
   */
  clone() {
    const el = new _YXmlElement(this.nodeName);
    const attrs = this.getAttributes();
    forEach(attrs, (value, key) => {
      el.setAttribute(
        key,
        /** @type {any} */
        value
      );
    });
    el.insert(0, this.toArray().map((v) => v instanceof AbstractType ? v.clone() : v));
    return el;
  }
  /**
   * Returns the XML serialization of this YXmlElement.
   * The attributes are ordered by attribute-name, so you can easily use this
   * method to compare YXmlElements
   *
   * @return {string} The string representation of this type.
   *
   * @public
   */
  toString() {
    const attrs = this.getAttributes();
    const stringBuilder = [];
    const keys2 = [];
    for (const key in attrs) {
      keys2.push(key);
    }
    keys2.sort();
    const keysLen = keys2.length;
    for (let i = 0; i < keysLen; i++) {
      const key = keys2[i];
      stringBuilder.push(key + '="' + attrs[key] + '"');
    }
    const nodeName = this.nodeName.toLocaleLowerCase();
    const attrsString = stringBuilder.length > 0 ? " " + stringBuilder.join(" ") : "";
    return `<${nodeName}${attrsString}>${super.toString()}</${nodeName}>`;
  }
  /**
   * Removes an attribute from this YXmlElement.
   *
   * @param {string} attributeName The attribute name that is to be removed.
   *
   * @public
   */
  removeAttribute(attributeName) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeMapDelete(transaction, this, attributeName);
      });
    } else {
      this._prelimAttrs.delete(attributeName);
    }
  }
  /**
   * Sets or updates an attribute.
   *
   * @template {keyof KV & string} KEY
   *
   * @param {KEY} attributeName The attribute name that is to be set.
   * @param {KV[KEY]} attributeValue The attribute value that is to be set.
   *
   * @public
   */
  setAttribute(attributeName, attributeValue) {
    if (this.doc !== null) {
      transact(this.doc, (transaction) => {
        typeMapSet(transaction, this, attributeName, attributeValue);
      });
    } else {
      this._prelimAttrs.set(attributeName, attributeValue);
    }
  }
  /**
   * Returns an attribute value that belongs to the attribute name.
   *
   * @template {keyof KV & string} KEY
   *
   * @param {KEY} attributeName The attribute name that identifies the
   *                               queried value.
   * @return {KV[KEY]|undefined} The queried attribute value.
   *
   * @public
   */
  getAttribute(attributeName) {
    return (
      /** @type {any} */
      typeMapGet(this, attributeName)
    );
  }
  /**
   * Returns whether an attribute exists
   *
   * @param {string} attributeName The attribute name to check for existence.
   * @return {boolean} whether the attribute exists.
   *
   * @public
   */
  hasAttribute(attributeName) {
    return (
      /** @type {any} */
      typeMapHas(this, attributeName)
    );
  }
  /**
   * Returns all attribute name/value pairs in a JSON Object.
   *
   * @param {Snapshot} [snapshot]
   * @return {{ [Key in Extract<keyof KV,string>]?: KV[Key]}} A JSON Object that describes the attributes.
   *
   * @public
   */
  getAttributes(snapshot) {
    return (
      /** @type {any} */
      snapshot ? typeMapGetAllSnapshot(this, snapshot) : typeMapGetAll(this)
    );
  }
  /**
   * Creates a Dom Element that mirrors this YXmlElement.
   *
   * @param {Document} [_document=document] The document object (you must define
   *                                        this when calling this method in
   *                                        nodejs)
   * @param {Object<string, any>} [hooks={}] Optional property to customize how hooks
   *                                             are presented in the DOM
   * @param {any} [binding] You should not set this property. This is
   *                               used if DomBinding wants to create a
   *                               association to the created DOM type.
   * @return {Node} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
   *
   * @public
   */
  toDOM(_document = document, hooks = {}, binding) {
    const dom = _document.createElement(this.nodeName);
    const attrs = this.getAttributes();
    for (const key in attrs) {
      const value = attrs[key];
      if (typeof value === "string") {
        dom.setAttribute(key, value);
      }
    }
    typeListForEach(this, (yxml) => {
      dom.appendChild(yxml.toDOM(_document, hooks, binding));
    });
    if (binding !== void 0) {
      binding._createAssociation(dom, this);
    }
    return dom;
  }
  /**
   * Transform the properties of this type to binary and write it to an
   * BinaryEncoder.
   *
   * This is called when this Item is sent to a remote peer.
   *
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
   */
  _write(encoder) {
    encoder.writeTypeRef(YXmlElementRefID);
    encoder.writeKey(this.nodeName);
  }
};
var readYXmlElement = (decoder) => new YXmlElement(decoder.readKey());
var YXmlEvent = class extends YEvent {
  /**
   * @param {YXmlElement|YXmlText|YXmlFragment} target The target on which the event is created.
   * @param {Set<string|null>} subs The set of changed attributes. `null` is included if the
   *                   child list changed.
   * @param {Transaction} transaction The transaction instance with which the
   *                                  change was created.
   */
  constructor(target, subs, transaction) {
    super(target, transaction);
    this.childListChanged = false;
    this.attributesChanged = /* @__PURE__ */ new Set();
    subs.forEach((sub) => {
      if (sub === null) {
        this.childListChanged = true;
      } else {
        this.attributesChanged.add(sub);
      }
    });
  }
};
var YXmlHook = class _YXmlHook extends YMap {
  /**
   * @param {string} hookName nodeName of the Dom Node.
   */
  constructor(hookName) {
    super();
    this.hookName = hookName;
  }
  /**
   * Creates an Item with the same effect as this Item (without position effect)
   */
  _copy() {
    return new _YXmlHook(this.hookName);
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YXmlHook}
   */
  clone() {
    const el = new _YXmlHook(this.hookName);
    this.forEach((value, key) => {
      el.set(key, value);
    });
    return el;
  }
  /**
   * Creates a Dom Element that mirrors this YXmlElement.
   *
   * @param {Document} [_document=document] The document object (you must define
   *                                        this when calling this method in
   *                                        nodejs)
   * @param {Object.<string, any>} [hooks] Optional property to customize how hooks
   *                                             are presented in the DOM
   * @param {any} [binding] You should not set this property. This is
   *                               used if DomBinding wants to create a
   *                               association to the created DOM type
   * @return {Element} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
   *
   * @public
   */
  toDOM(_document = document, hooks = {}, binding) {
    const hook = hooks[this.hookName];
    let dom;
    if (hook !== void 0) {
      dom = hook.createDom(this);
    } else {
      dom = document.createElement(this.hookName);
    }
    dom.setAttribute("data-yjs-hook", this.hookName);
    if (binding !== void 0) {
      binding._createAssociation(dom, this);
    }
    return dom;
  }
  /**
   * Transform the properties of this type to binary and write it to an
   * BinaryEncoder.
   *
   * This is called when this Item is sent to a remote peer.
   *
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
   */
  _write(encoder) {
    encoder.writeTypeRef(YXmlHookRefID);
    encoder.writeKey(this.hookName);
  }
};
var readYXmlHook = (decoder) => new YXmlHook(decoder.readKey());
var YXmlText = class _YXmlText extends YText {
  /**
   * @type {YXmlElement|YXmlText|null}
   */
  get nextSibling() {
    const n = this._item ? this._item.next : null;
    return n ? (
      /** @type {YXmlElement|YXmlText} */
      /** @type {ContentType} */
      n.content.type
    ) : null;
  }
  /**
   * @type {YXmlElement|YXmlText|null}
   */
  get prevSibling() {
    const n = this._item ? this._item.prev : null;
    return n ? (
      /** @type {YXmlElement|YXmlText} */
      /** @type {ContentType} */
      n.content.type
    ) : null;
  }
  _copy() {
    return new _YXmlText();
  }
  /**
   * Makes a copy of this data type that can be included somewhere else.
   *
   * Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
   *
   * @return {YXmlText}
   */
  clone() {
    const text2 = new _YXmlText();
    text2.applyDelta(this.toDelta());
    return text2;
  }
  /**
   * Creates a Dom Element that mirrors this YXmlText.
   *
   * @param {Document} [_document=document] The document object (you must define
   *                                        this when calling this method in
   *                                        nodejs)
   * @param {Object<string, any>} [hooks] Optional property to customize how hooks
   *                                             are presented in the DOM
   * @param {any} [binding] You should not set this property. This is
   *                               used if DomBinding wants to create a
   *                               association to the created DOM type.
   * @return {Text} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
   *
   * @public
   */
  toDOM(_document = document, hooks, binding) {
    const dom = _document.createTextNode(this.toString());
    if (binding !== void 0) {
      binding._createAssociation(dom, this);
    }
    return dom;
  }
  toString() {
    return this.toDelta().map((delta) => {
      const nestedNodes = [];
      for (const nodeName in delta.attributes) {
        const attrs = [];
        for (const key in delta.attributes[nodeName]) {
          attrs.push({ key, value: delta.attributes[nodeName][key] });
        }
        attrs.sort((a, b) => a.key < b.key ? -1 : 1);
        nestedNodes.push({ nodeName, attrs });
      }
      nestedNodes.sort((a, b) => a.nodeName < b.nodeName ? -1 : 1);
      let str = "";
      for (let i = 0; i < nestedNodes.length; i++) {
        const node = nestedNodes[i];
        str += `<${node.nodeName}`;
        for (let j = 0; j < node.attrs.length; j++) {
          const attr = node.attrs[j];
          str += ` ${attr.key}="${attr.value}"`;
        }
        str += ">";
      }
      str += delta.insert;
      for (let i = nestedNodes.length - 1; i >= 0; i--) {
        str += `</${nestedNodes[i].nodeName}>`;
      }
      return str;
    }).join("");
  }
  /**
   * @return {string}
   */
  toJSON() {
    return this.toString();
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   */
  _write(encoder) {
    encoder.writeTypeRef(YXmlTextRefID);
  }
};
var readYXmlText = (decoder) => new YXmlText();
var AbstractStruct = class {
  /**
   * @param {ID} id
   * @param {number} length
   */
  constructor(id2, length2) {
    this.id = id2;
    this.length = length2;
  }
  /**
   * @type {boolean}
   */
  get deleted() {
    throw methodUnimplemented();
  }
  /**
   * Merge this struct with the item to the right.
   * This method is already assuming that `this.id.clock + this.length === this.id.clock`.
   * Also this method does *not* remove right from StructStore!
   * @param {AbstractStruct} right
   * @return {boolean} whether this merged with right
   */
  mergeWith(right) {
    return false;
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
   * @param {number} offset
   * @param {number} encodingRef
   */
  write(encoder, offset, encodingRef) {
    throw methodUnimplemented();
  }
  /**
   * @param {Transaction} transaction
   * @param {number} offset
   */
  integrate(transaction, offset) {
    throw methodUnimplemented();
  }
};
var structGCRefNumber = 0;
var GC = class extends AbstractStruct {
  get deleted() {
    return true;
  }
  delete() {
  }
  /**
   * @param {GC} right
   * @return {boolean}
   */
  mergeWith(right) {
    if (this.constructor !== right.constructor) {
      return false;
    }
    this.length += right.length;
    return true;
  }
  /**
   * @param {Transaction} transaction
   * @param {number} offset
   */
  integrate(transaction, offset) {
    if (offset > 0) {
      this.id.clock += offset;
      this.length -= offset;
    }
    addStruct(transaction.doc.store, this);
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeInfo(structGCRefNumber);
    encoder.writeLen(this.length - offset);
  }
  /**
   * @param {Transaction} transaction
   * @param {StructStore} store
   * @return {null | number}
   */
  getMissing(transaction, store) {
    return null;
  }
};
var ContentBinary = class _ContentBinary {
  /**
   * @param {Uint8Array} content
   */
  constructor(content2) {
    this.content = content2;
  }
  /**
   * @return {number}
   */
  getLength() {
    return 1;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return [this.content];
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentBinary}
   */
  copy() {
    return new _ContentBinary(this.content);
  }
  /**
   * @param {number} offset
   * @return {ContentBinary}
   */
  splice(offset) {
    throw methodUnimplemented();
  }
  /**
   * @param {ContentBinary} right
   * @return {boolean}
   */
  mergeWith(right) {
    return false;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeBuf(this.content);
  }
  /**
   * @return {number}
   */
  getRef() {
    return 3;
  }
};
var readContentBinary = (decoder) => new ContentBinary(decoder.readBuf());
var ContentDeleted = class _ContentDeleted {
  /**
   * @param {number} len
   */
  constructor(len) {
    this.len = len;
  }
  /**
   * @return {number}
   */
  getLength() {
    return this.len;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return [];
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return false;
  }
  /**
   * @return {ContentDeleted}
   */
  copy() {
    return new _ContentDeleted(this.len);
  }
  /**
   * @param {number} offset
   * @return {ContentDeleted}
   */
  splice(offset) {
    const right = new _ContentDeleted(this.len - offset);
    this.len = offset;
    return right;
  }
  /**
   * @param {ContentDeleted} right
   * @return {boolean}
   */
  mergeWith(right) {
    this.len += right.len;
    return true;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
    addToDeleteSet(transaction.deleteSet, item.id.client, item.id.clock, this.len);
    item.markDeleted();
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeLen(this.len - offset);
  }
  /**
   * @return {number}
   */
  getRef() {
    return 1;
  }
};
var readContentDeleted = (decoder) => new ContentDeleted(decoder.readLen());
var createDocFromOpts = (guid, opts) => new Doc({ guid, ...opts, shouldLoad: opts.shouldLoad || opts.autoLoad || false });
var ContentDoc = class _ContentDoc {
  /**
   * @param {Doc} doc
   */
  constructor(doc2) {
    if (doc2._item) {
      console.error("This document was already integrated as a sub-document. You should create a second instance instead with the same guid.");
    }
    this.doc = doc2;
    const opts = {};
    this.opts = opts;
    if (!doc2.gc) {
      opts.gc = false;
    }
    if (doc2.autoLoad) {
      opts.autoLoad = true;
    }
    if (doc2.meta !== null) {
      opts.meta = doc2.meta;
    }
  }
  /**
   * @return {number}
   */
  getLength() {
    return 1;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return [this.doc];
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentDoc}
   */
  copy() {
    return new _ContentDoc(createDocFromOpts(this.doc.guid, this.opts));
  }
  /**
   * @param {number} offset
   * @return {ContentDoc}
   */
  splice(offset) {
    throw methodUnimplemented();
  }
  /**
   * @param {ContentDoc} right
   * @return {boolean}
   */
  mergeWith(right) {
    return false;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
    this.doc._item = item;
    transaction.subdocsAdded.add(this.doc);
    if (this.doc.shouldLoad) {
      transaction.subdocsLoaded.add(this.doc);
    }
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
    if (transaction.subdocsAdded.has(this.doc)) {
      transaction.subdocsAdded.delete(this.doc);
    } else {
      transaction.subdocsRemoved.add(this.doc);
    }
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeString(this.doc.guid);
    encoder.writeAny(this.opts);
  }
  /**
   * @return {number}
   */
  getRef() {
    return 9;
  }
};
var readContentDoc = (decoder) => new ContentDoc(createDocFromOpts(decoder.readString(), decoder.readAny()));
var ContentEmbed = class _ContentEmbed {
  /**
   * @param {Object} embed
   */
  constructor(embed) {
    this.embed = embed;
  }
  /**
   * @return {number}
   */
  getLength() {
    return 1;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return [this.embed];
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentEmbed}
   */
  copy() {
    return new _ContentEmbed(this.embed);
  }
  /**
   * @param {number} offset
   * @return {ContentEmbed}
   */
  splice(offset) {
    throw methodUnimplemented();
  }
  /**
   * @param {ContentEmbed} right
   * @return {boolean}
   */
  mergeWith(right) {
    return false;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeJSON(this.embed);
  }
  /**
   * @return {number}
   */
  getRef() {
    return 5;
  }
};
var readContentEmbed = (decoder) => new ContentEmbed(decoder.readJSON());
var ContentFormat = class _ContentFormat {
  /**
   * @param {string} key
   * @param {Object} value
   */
  constructor(key, value) {
    this.key = key;
    this.value = value;
  }
  /**
   * @return {number}
   */
  getLength() {
    return 1;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return [];
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return false;
  }
  /**
   * @return {ContentFormat}
   */
  copy() {
    return new _ContentFormat(this.key, this.value);
  }
  /**
   * @param {number} _offset
   * @return {ContentFormat}
   */
  splice(_offset) {
    throw methodUnimplemented();
  }
  /**
   * @param {ContentFormat} _right
   * @return {boolean}
   */
  mergeWith(_right) {
    return false;
  }
  /**
   * @param {Transaction} _transaction
   * @param {Item} item
   */
  integrate(_transaction, item) {
    const p = (
      /** @type {YText} */
      item.parent
    );
    p._searchMarker = null;
    p._hasFormatting = true;
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeKey(this.key);
    encoder.writeJSON(this.value);
  }
  /**
   * @return {number}
   */
  getRef() {
    return 6;
  }
};
var readContentFormat = (decoder) => new ContentFormat(decoder.readKey(), decoder.readJSON());
var ContentJSON = class _ContentJSON {
  /**
   * @param {Array<any>} arr
   */
  constructor(arr) {
    this.arr = arr;
  }
  /**
   * @return {number}
   */
  getLength() {
    return this.arr.length;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return this.arr;
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentJSON}
   */
  copy() {
    return new _ContentJSON(this.arr);
  }
  /**
   * @param {number} offset
   * @return {ContentJSON}
   */
  splice(offset) {
    const right = new _ContentJSON(this.arr.slice(offset));
    this.arr = this.arr.slice(0, offset);
    return right;
  }
  /**
   * @param {ContentJSON} right
   * @return {boolean}
   */
  mergeWith(right) {
    this.arr = this.arr.concat(right.arr);
    return true;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    const len = this.arr.length;
    encoder.writeLen(len - offset);
    for (let i = offset; i < len; i++) {
      const c = this.arr[i];
      encoder.writeString(c === void 0 ? "undefined" : JSON.stringify(c));
    }
  }
  /**
   * @return {number}
   */
  getRef() {
    return 2;
  }
};
var readContentJSON = (decoder) => {
  const len = decoder.readLen();
  const cs = [];
  for (let i = 0; i < len; i++) {
    const c = decoder.readString();
    if (c === "undefined") {
      cs.push(void 0);
    } else {
      cs.push(JSON.parse(c));
    }
  }
  return new ContentJSON(cs);
};
var isDevMode = getVariable("node_env") === "development";
var ContentAny = class _ContentAny {
  /**
   * @param {Array<any>} arr
   */
  constructor(arr) {
    this.arr = arr;
    isDevMode && deepFreeze(arr);
  }
  /**
   * @return {number}
   */
  getLength() {
    return this.arr.length;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return this.arr;
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentAny}
   */
  copy() {
    return new _ContentAny(this.arr);
  }
  /**
   * @param {number} offset
   * @return {ContentAny}
   */
  splice(offset) {
    const right = new _ContentAny(this.arr.slice(offset));
    this.arr = this.arr.slice(0, offset);
    return right;
  }
  /**
   * @param {ContentAny} right
   * @return {boolean}
   */
  mergeWith(right) {
    this.arr = this.arr.concat(right.arr);
    return true;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    const len = this.arr.length;
    encoder.writeLen(len - offset);
    for (let i = offset; i < len; i++) {
      const c = this.arr[i];
      encoder.writeAny(c);
    }
  }
  /**
   * @return {number}
   */
  getRef() {
    return 8;
  }
};
var readContentAny = (decoder) => {
  const len = decoder.readLen();
  const cs = [];
  for (let i = 0; i < len; i++) {
    cs.push(decoder.readAny());
  }
  return new ContentAny(cs);
};
var ContentString = class _ContentString {
  /**
   * @param {string} str
   */
  constructor(str) {
    this.str = str;
  }
  /**
   * @return {number}
   */
  getLength() {
    return this.str.length;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return this.str.split("");
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentString}
   */
  copy() {
    return new _ContentString(this.str);
  }
  /**
   * @param {number} offset
   * @return {ContentString}
   */
  splice(offset) {
    const right = new _ContentString(this.str.slice(offset));
    this.str = this.str.slice(0, offset);
    const firstCharCode = this.str.charCodeAt(offset - 1);
    if (firstCharCode >= 55296 && firstCharCode <= 56319) {
      this.str = this.str.slice(0, offset - 1) + "\uFFFD";
      right.str = "\uFFFD" + right.str.slice(1);
    }
    return right;
  }
  /**
   * @param {ContentString} right
   * @return {boolean}
   */
  mergeWith(right) {
    this.str += right.str;
    return true;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeString(offset === 0 ? this.str : this.str.slice(offset));
  }
  /**
   * @return {number}
   */
  getRef() {
    return 4;
  }
};
var readContentString = (decoder) => new ContentString(decoder.readString());
var typeRefs = [
  readYArray,
  readYMap,
  readYText,
  readYXmlElement,
  readYXmlFragment,
  readYXmlHook,
  readYXmlText
];
var YArrayRefID = 0;
var YMapRefID = 1;
var YTextRefID = 2;
var YXmlElementRefID = 3;
var YXmlFragmentRefID = 4;
var YXmlHookRefID = 5;
var YXmlTextRefID = 6;
var ContentType = class _ContentType {
  /**
   * @param {AbstractType<any>} type
   */
  constructor(type) {
    this.type = type;
  }
  /**
   * @return {number}
   */
  getLength() {
    return 1;
  }
  /**
   * @return {Array<any>}
   */
  getContent() {
    return [this.type];
  }
  /**
   * @return {boolean}
   */
  isCountable() {
    return true;
  }
  /**
   * @return {ContentType}
   */
  copy() {
    return new _ContentType(this.type._copy());
  }
  /**
   * @param {number} offset
   * @return {ContentType}
   */
  splice(offset) {
    throw methodUnimplemented();
  }
  /**
   * @param {ContentType} right
   * @return {boolean}
   */
  mergeWith(right) {
    return false;
  }
  /**
   * @param {Transaction} transaction
   * @param {Item} item
   */
  integrate(transaction, item) {
    this.type._integrate(transaction.doc, item);
  }
  /**
   * @param {Transaction} transaction
   */
  delete(transaction) {
    let item = this.type._start;
    while (item !== null) {
      if (!item.deleted) {
        item.delete(transaction);
      } else if (item.id.clock < (transaction.beforeState.get(item.id.client) || 0)) {
        transaction._mergeStructs.push(item);
      }
      item = item.right;
    }
    this.type._map.forEach((item2) => {
      if (!item2.deleted) {
        item2.delete(transaction);
      } else if (item2.id.clock < (transaction.beforeState.get(item2.id.client) || 0)) {
        transaction._mergeStructs.push(item2);
      }
    });
    transaction.changed.delete(this.type);
  }
  /**
   * @param {StructStore} store
   */
  gc(store) {
    let item = this.type._start;
    while (item !== null) {
      item.gc(store, true);
      item = item.right;
    }
    this.type._start = null;
    this.type._map.forEach(
      /** @param {Item | null} item */
      (item2) => {
        while (item2 !== null) {
          item2.gc(store, true);
          item2 = item2.left;
        }
      }
    );
    this.type._map = /* @__PURE__ */ new Map();
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    this.type._write(encoder);
  }
  /**
   * @return {number}
   */
  getRef() {
    return 7;
  }
};
var readContentType = (decoder) => new ContentType(typeRefs[decoder.readTypeRef()](decoder));
var followRedone = (store, id2) => {
  let nextID = id2;
  let diff = 0;
  let item;
  do {
    if (diff > 0) {
      nextID = createID(nextID.client, nextID.clock + diff);
    }
    item = getItem(store, nextID);
    diff = nextID.clock - item.id.clock;
    nextID = item.redone;
  } while (nextID !== null && item instanceof Item);
  return {
    item,
    diff
  };
};
var keepItem = (item, keep) => {
  while (item !== null && item.keep !== keep) {
    item.keep = keep;
    item = /** @type {AbstractType<any>} */
    item.parent._item;
  }
};
var splitItem = (transaction, leftItem, diff) => {
  const { client, clock } = leftItem.id;
  const rightItem = new Item(
    createID(client, clock + diff),
    leftItem,
    createID(client, clock + diff - 1),
    leftItem.right,
    leftItem.rightOrigin,
    leftItem.parent,
    leftItem.parentSub,
    leftItem.content.splice(diff)
  );
  if (leftItem.deleted) {
    rightItem.markDeleted();
  }
  if (leftItem.keep) {
    rightItem.keep = true;
  }
  if (leftItem.redone !== null) {
    rightItem.redone = createID(leftItem.redone.client, leftItem.redone.clock + diff);
  }
  leftItem.right = rightItem;
  if (rightItem.right !== null) {
    rightItem.right.left = rightItem;
  }
  transaction._mergeStructs.push(rightItem);
  if (rightItem.parentSub !== null && rightItem.right === null) {
    rightItem.parent._map.set(rightItem.parentSub, rightItem);
  }
  leftItem.length = diff;
  return rightItem;
};
var isDeletedByUndoStack = (stack, id2) => some(
  stack,
  /** @param {StackItem} s */
  (s) => isDeleted(s.deletions, id2)
);
var redoItem = (transaction, item, redoitems, itemsToDelete, ignoreRemoteMapChanges, um) => {
  const doc2 = transaction.doc;
  const store = doc2.store;
  const ownClientID = doc2.clientID;
  const redone = item.redone;
  if (redone !== null) {
    return getItemCleanStart(transaction, redone);
  }
  let parentItem = (
    /** @type {AbstractType<any>} */
    item.parent._item
  );
  let left = null;
  let right;
  if (parentItem !== null && parentItem.deleted === true) {
    if (parentItem.redone === null && (!redoitems.has(parentItem) || redoItem(transaction, parentItem, redoitems, itemsToDelete, ignoreRemoteMapChanges, um) === null)) {
      return null;
    }
    while (parentItem.redone !== null) {
      parentItem = getItemCleanStart(transaction, parentItem.redone);
    }
  }
  const parentType = parentItem === null ? (
    /** @type {AbstractType<any>} */
    item.parent
  ) : (
    /** @type {ContentType} */
    parentItem.content.type
  );
  if (item.parentSub === null) {
    left = item.left;
    right = item;
    while (left !== null) {
      let leftTrace = left;
      while (leftTrace !== null && /** @type {AbstractType<any>} */
      leftTrace.parent._item !== parentItem) {
        leftTrace = leftTrace.redone === null ? null : getItemCleanStart(transaction, leftTrace.redone);
      }
      if (leftTrace !== null && /** @type {AbstractType<any>} */
      leftTrace.parent._item === parentItem) {
        left = leftTrace;
        break;
      }
      left = left.left;
    }
    while (right !== null) {
      let rightTrace = right;
      while (rightTrace !== null && /** @type {AbstractType<any>} */
      rightTrace.parent._item !== parentItem) {
        rightTrace = rightTrace.redone === null ? null : getItemCleanStart(transaction, rightTrace.redone);
      }
      if (rightTrace !== null && /** @type {AbstractType<any>} */
      rightTrace.parent._item === parentItem) {
        right = rightTrace;
        break;
      }
      right = right.right;
    }
  } else {
    right = null;
    if (item.right && !ignoreRemoteMapChanges) {
      left = item;
      while (left !== null && left.right !== null && (left.right.redone || isDeleted(itemsToDelete, left.right.id) || isDeletedByUndoStack(um.undoStack, left.right.id) || isDeletedByUndoStack(um.redoStack, left.right.id))) {
        left = left.right;
        while (left.redone) left = getItemCleanStart(transaction, left.redone);
      }
      if (left && left.right !== null) {
        return null;
      }
    } else {
      left = parentType._map.get(item.parentSub) || null;
    }
    if (left !== null && /** @type {AbstractType<any>} */
    left.parent._item !== parentItem) {
      left = parentType._map.get(item.parentSub) || null;
    }
  }
  const nextClock = getState(store, ownClientID);
  const nextId = createID(ownClientID, nextClock);
  const redoneItem = new Item(
    nextId,
    left,
    left && left.lastId,
    right,
    right && right.id,
    parentType,
    item.parentSub,
    item.content.copy()
  );
  item.redone = nextId;
  keepItem(redoneItem, true);
  redoneItem.integrate(transaction, 0);
  return redoneItem;
};
var Item = class _Item extends AbstractStruct {
  /**
   * @param {ID} id
   * @param {Item | null} left
   * @param {ID | null} origin
   * @param {Item | null} right
   * @param {ID | null} rightOrigin
   * @param {AbstractType<any>|ID|null} parent Is a type if integrated, is null if it is possible to copy parent from left or right, is ID before integration to search for it.
   * @param {string | null} parentSub
   * @param {AbstractContent} content
   */
  constructor(id2, left, origin, right, rightOrigin, parent, parentSub, content2) {
    super(id2, content2.getLength());
    this.origin = origin;
    this.left = left;
    this.right = right;
    this.rightOrigin = rightOrigin;
    this.parent = parent;
    this.parentSub = parentSub;
    this.redone = null;
    this.content = content2;
    this.info = this.content.isCountable() ? BIT2 : 0;
  }
  /**
   * This is used to mark the item as an indexed fast-search marker
   *
   * @type {boolean}
   */
  set marker(isMarked) {
    if ((this.info & BIT4) > 0 !== isMarked) {
      this.info ^= BIT4;
    }
  }
  get marker() {
    return (this.info & BIT4) > 0;
  }
  /**
   * If true, do not garbage collect this Item.
   */
  get keep() {
    return (this.info & BIT1) > 0;
  }
  set keep(doKeep) {
    if (this.keep !== doKeep) {
      this.info ^= BIT1;
    }
  }
  get countable() {
    return (this.info & BIT2) > 0;
  }
  /**
   * Whether this item was deleted or not.
   * @type {Boolean}
   */
  get deleted() {
    return (this.info & BIT3) > 0;
  }
  set deleted(doDelete) {
    if (this.deleted !== doDelete) {
      this.info ^= BIT3;
    }
  }
  markDeleted() {
    this.info |= BIT3;
  }
  /**
   * Return the creator clientID of the missing op or define missing items and return null.
   *
   * @param {Transaction} transaction
   * @param {StructStore} store
   * @return {null | number}
   */
  getMissing(transaction, store) {
    if (this.origin && this.origin.client !== this.id.client && this.origin.clock >= getState(store, this.origin.client)) {
      return this.origin.client;
    }
    if (this.rightOrigin && this.rightOrigin.client !== this.id.client && this.rightOrigin.clock >= getState(store, this.rightOrigin.client)) {
      return this.rightOrigin.client;
    }
    if (this.parent && this.parent.constructor === ID && this.id.client !== this.parent.client && this.parent.clock >= getState(store, this.parent.client)) {
      return this.parent.client;
    }
    if (this.origin) {
      this.left = getItemCleanEnd(transaction, store, this.origin);
      this.origin = this.left.lastId;
    }
    if (this.rightOrigin) {
      this.right = getItemCleanStart(transaction, this.rightOrigin);
      this.rightOrigin = this.right.id;
    }
    if (this.left && this.left.constructor === GC || this.right && this.right.constructor === GC) {
      this.parent = null;
    } else if (!this.parent) {
      if (this.left && this.left.constructor === _Item) {
        this.parent = this.left.parent;
        this.parentSub = this.left.parentSub;
      } else if (this.right && this.right.constructor === _Item) {
        this.parent = this.right.parent;
        this.parentSub = this.right.parentSub;
      }
    } else if (this.parent.constructor === ID) {
      const parentItem = getItem(store, this.parent);
      if (parentItem.constructor === GC) {
        this.parent = null;
      } else {
        this.parent = /** @type {ContentType} */
        parentItem.content.type;
      }
    }
    return null;
  }
  /**
   * @param {Transaction} transaction
   * @param {number} offset
   */
  integrate(transaction, offset) {
    if (offset > 0) {
      this.id.clock += offset;
      this.left = getItemCleanEnd(transaction, transaction.doc.store, createID(this.id.client, this.id.clock - 1));
      this.origin = this.left.lastId;
      this.content = this.content.splice(offset);
      this.length -= offset;
    }
    if (this.parent) {
      if (!this.left && (!this.right || this.right.left !== null) || this.left && this.left.right !== this.right) {
        let left = this.left;
        let o;
        if (left !== null) {
          o = left.right;
        } else if (this.parentSub !== null) {
          o = /** @type {AbstractType<any>} */
          this.parent._map.get(this.parentSub) || null;
          while (o !== null && o.left !== null) {
            o = o.left;
          }
        } else {
          o = /** @type {AbstractType<any>} */
          this.parent._start;
        }
        const conflictingItems = /* @__PURE__ */ new Set();
        const itemsBeforeOrigin = /* @__PURE__ */ new Set();
        while (o !== null && o !== this.right) {
          itemsBeforeOrigin.add(o);
          conflictingItems.add(o);
          if (compareIDs(this.origin, o.origin)) {
            if (o.id.client < this.id.client) {
              left = o;
              conflictingItems.clear();
            } else if (compareIDs(this.rightOrigin, o.rightOrigin)) {
              break;
            }
          } else if (o.origin !== null && itemsBeforeOrigin.has(getItem(transaction.doc.store, o.origin))) {
            if (!conflictingItems.has(getItem(transaction.doc.store, o.origin))) {
              left = o;
              conflictingItems.clear();
            }
          } else {
            break;
          }
          o = o.right;
        }
        this.left = left;
      }
      if (this.left !== null) {
        const right = this.left.right;
        this.right = right;
        this.left.right = this;
      } else {
        let r2;
        if (this.parentSub !== null) {
          r2 = /** @type {AbstractType<any>} */
          this.parent._map.get(this.parentSub) || null;
          while (r2 !== null && r2.left !== null) {
            r2 = r2.left;
          }
        } else {
          r2 = /** @type {AbstractType<any>} */
          this.parent._start;
          this.parent._start = this;
        }
        this.right = r2;
      }
      if (this.right !== null) {
        this.right.left = this;
      } else if (this.parentSub !== null) {
        this.parent._map.set(this.parentSub, this);
        if (this.left !== null) {
          this.left.delete(transaction);
        }
      }
      if (this.parentSub === null && this.countable && !this.deleted) {
        this.parent._length += this.length;
      }
      addStruct(transaction.doc.store, this);
      this.content.integrate(transaction, this);
      addChangedTypeToTransaction(
        transaction,
        /** @type {AbstractType<any>} */
        this.parent,
        this.parentSub
      );
      if (
        /** @type {AbstractType<any>} */
        this.parent._item !== null && /** @type {AbstractType<any>} */
        this.parent._item.deleted || this.parentSub !== null && this.right !== null
      ) {
        this.delete(transaction);
      }
    } else {
      new GC(this.id, this.length).integrate(transaction, 0);
    }
  }
  /**
   * Returns the next non-deleted item
   */
  get next() {
    let n = this.right;
    while (n !== null && n.deleted) {
      n = n.right;
    }
    return n;
  }
  /**
   * Returns the previous non-deleted item
   */
  get prev() {
    let n = this.left;
    while (n !== null && n.deleted) {
      n = n.left;
    }
    return n;
  }
  /**
   * Computes the last content address of this Item.
   */
  get lastId() {
    return this.length === 1 ? this.id : createID(this.id.client, this.id.clock + this.length - 1);
  }
  /**
   * Try to merge two items
   *
   * @param {Item} right
   * @return {boolean}
   */
  mergeWith(right) {
    if (this.constructor === right.constructor && compareIDs(right.origin, this.lastId) && this.right === right && compareIDs(this.rightOrigin, right.rightOrigin) && this.id.client === right.id.client && this.id.clock + this.length === right.id.clock && this.deleted === right.deleted && this.redone === null && right.redone === null && this.content.constructor === right.content.constructor && this.content.mergeWith(right.content)) {
      const searchMarker = (
        /** @type {AbstractType<any>} */
        this.parent._searchMarker
      );
      if (searchMarker) {
        searchMarker.forEach((marker) => {
          if (marker.p === right) {
            marker.p = this;
            if (!this.deleted && this.countable) {
              marker.index -= this.length;
            }
          }
        });
      }
      if (right.keep) {
        this.keep = true;
      }
      this.right = right.right;
      if (this.right !== null) {
        this.right.left = this;
      }
      this.length += right.length;
      return true;
    }
    return false;
  }
  /**
   * Mark this Item as deleted.
   *
   * @param {Transaction} transaction
   */
  delete(transaction) {
    if (!this.deleted) {
      const parent = (
        /** @type {AbstractType<any>} */
        this.parent
      );
      if (this.countable && this.parentSub === null) {
        parent._length -= this.length;
      }
      this.markDeleted();
      addToDeleteSet(transaction.deleteSet, this.id.client, this.id.clock, this.length);
      addChangedTypeToTransaction(transaction, parent, this.parentSub);
      this.content.delete(transaction);
    }
  }
  /**
   * @param {StructStore} store
   * @param {boolean} parentGCd
   */
  gc(store, parentGCd) {
    if (!this.deleted) {
      throw unexpectedCase();
    }
    this.content.gc(store);
    if (parentGCd) {
      replaceStruct(store, this, new GC(this.id, this.length));
    } else {
      this.content = new ContentDeleted(this.length);
    }
  }
  /**
   * Transform the properties of this type to binary and write it to an
   * BinaryEncoder.
   *
   * This is called when this Item is sent to a remote peer.
   *
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
   * @param {number} offset
   */
  write(encoder, offset) {
    const origin = offset > 0 ? createID(this.id.client, this.id.clock + offset - 1) : this.origin;
    const rightOrigin = this.rightOrigin;
    const parentSub = this.parentSub;
    const info = this.content.getRef() & BITS5 | (origin === null ? 0 : BIT8) | // origin is defined
    (rightOrigin === null ? 0 : BIT7) | // right origin is defined
    (parentSub === null ? 0 : BIT6);
    encoder.writeInfo(info);
    if (origin !== null) {
      encoder.writeLeftID(origin);
    }
    if (rightOrigin !== null) {
      encoder.writeRightID(rightOrigin);
    }
    if (origin === null && rightOrigin === null) {
      const parent = (
        /** @type {AbstractType<any>} */
        this.parent
      );
      if (parent._item !== void 0) {
        const parentItem = parent._item;
        if (parentItem === null) {
          const ykey = findRootTypeKey(parent);
          encoder.writeParentInfo(true);
          encoder.writeString(ykey);
        } else {
          encoder.writeParentInfo(false);
          encoder.writeLeftID(parentItem.id);
        }
      } else if (parent.constructor === String) {
        encoder.writeParentInfo(true);
        encoder.writeString(parent);
      } else if (parent.constructor === ID) {
        encoder.writeParentInfo(false);
        encoder.writeLeftID(parent);
      } else {
        unexpectedCase();
      }
      if (parentSub !== null) {
        encoder.writeString(parentSub);
      }
    }
    this.content.write(encoder, offset);
  }
};
var readItemContent = (decoder, info) => contentRefs[info & BITS5](decoder);
var contentRefs = [
  () => {
    unexpectedCase();
  },
  // GC is not ItemContent
  readContentDeleted,
  // 1
  readContentJSON,
  // 2
  readContentBinary,
  // 3
  readContentString,
  // 4
  readContentEmbed,
  // 5
  readContentFormat,
  // 6
  readContentType,
  // 7
  readContentAny,
  // 8
  readContentDoc,
  // 9
  () => {
    unexpectedCase();
  }
  // 10 - Skip is not ItemContent
];
var structSkipRefNumber = 10;
var Skip = class extends AbstractStruct {
  get deleted() {
    return true;
  }
  delete() {
  }
  /**
   * @param {Skip} right
   * @return {boolean}
   */
  mergeWith(right) {
    if (this.constructor !== right.constructor) {
      return false;
    }
    this.length += right.length;
    return true;
  }
  /**
   * @param {Transaction} transaction
   * @param {number} offset
   */
  integrate(transaction, offset) {
    unexpectedCase();
  }
  /**
   * @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
   * @param {number} offset
   */
  write(encoder, offset) {
    encoder.writeInfo(structSkipRefNumber);
    writeVarUint(encoder.restEncoder, this.length - offset);
  }
  /**
   * @param {Transaction} transaction
   * @param {StructStore} store
   * @return {null | number}
   */
  getMissing(transaction, store) {
    return null;
  }
};
var glo = (
  /** @type {any} */
  typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {}
);
var importIdentifier = "__ $YJS$ __";
if (glo[importIdentifier] === true) {
  console.error("Yjs was already imported. This breaks constructor checks and will lead to issues! - https://github.com/yjs/yjs/issues/438");
}
glo[importIdentifier] = true;

var MAX_IMAGE = 5 * 1024 * 1024;
var MAX_TEXT = 1024 * 1024;
var MAX_TOTAL = 50 * 1024 * 1024;
var IMAGE = /\.(png|jpe?g|gif|webp|svg|avif|bmp)$/i;
function supported(p) {
  return typeof p === "string" && p.length > 0 && p.length <= 512 && p === p.normalize("NFC") && !p.includes("\\") && !/[\x00-\x1f\x7f]/.test(p) && !p.startsWith("/") && !p.split("/").some((s) => !s || s === "." || s === ".." || s.startsWith(".") || /[<>:|?*]/.test(s) || s.includes(String.fromCharCode(34)) || /[. ]$/.test(s) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:[.]|$)/i.test(s)) && (/\.md$/i.test(p) || IMAGE.test(p));
}
function patchText(doc2, p, next, origin) {
  if (!supported(p) || !/\.md$/i.test(p)) throw Error("Invalid Markdown path");
  const t = doc2.getText("text:" + p), old = t.toString();
  let from2 = 0;
  while (from2 < old.length && from2 < next.length && old[from2] === next[from2]) from2++;
  let tail = 0;
  while (tail < old.length - from2 && tail < next.length - from2 && old[old.length - 1 - tail] === next[next.length - 1 - tail]) tail++;
  doc2.transact(() => {
    if (old.length - from2 - tail) t.delete(from2, old.length - from2 - tail);
    if (next.length - from2 - tail) t.insert(from2, next.slice(from2, next.length - tail));
  }, origin);
}

var MAX_PATHS = 8192;
var MAX_ACTIVE_PATHS = 6e3;
var MAX_INLINE_NOTE = 16 * 1024;
var MAX_INLINE_TOTAL = 128 * 1024;
var MAX_BINARY = 5 * 1024 * 1024;
var MAX_FILE_TEXT = 16 * 1024 * 1024;
var MAX_BLOB_BYTES = MAX_FILE_TEXT;
var MAX_LIVE_BYTES = 256 * 1024 * 1024;
var MAX_STATE = 2 * 1024 * 1024;
var FILE_REFS_CAPABILITY = "versioned-files-v1";
var MAX_DISK_BYTES = 512 * 1024 * 1024;
var MAX_DISK_OBJECTS = 8192;
var BLOB_RESPONSE_IDENTITY_CAPABILITY = "blob-response-identity-v1";

var GENERAL_FILES_CAPABILITY = "general-files-v1";
var GENERAL = /\.(json|csv|jsonl|html?|py|txt|sha256|log|zip|bak)$/i;
var DATED_BACKUP = /\.md\.bak\.\d{8}-\d{6}$/i;
var imagePath = (p) => typeof p === "string" && IMAGE.test(p);
function supportedFile(p) {
  return !["realtime-lab-v3-files.json", "realtime-lab-v2.json"].includes(p) && (supported(p) || typeof p === "string" && p.length <= 512 && (/\.pdf$/i.test(p) || GENERAL.test(p) || DATED_BACKUP.test(p)) && supported(p.replace(/\.[^./]+$/, ".png")));
}
var fileKind = (p) => imagePath(p) ? "image" : "file";
var maxFileSize = (p) => /\.md$/i.test(p) ? MAX_FILE_TEXT : imagePath(p) || /\.pdf$/i.test(p) ? MAX_BINARY : MAX_FILE_TEXT;
var textPreviewPath = (p) => /\.(md|json|csv|jsonl|html?|py|txt|sha256|log|bak)$/i.test(p) || DATED_BACKUP.test(p);
function decodeTextPreview(bytes) {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    return null;
  }
}

var import_obsidian = require("obsidian");
var import_state = require("@codemirror/state");

var cmView4 = __toESM(require("@codemirror/view"), 1);
var cmState4 = __toESM(require("@codemirror/state"), 1);

var YRange = class _YRange {
  /**
   * @param {Y.RelativePosition} yanchor
   * @param {Y.RelativePosition} yhead
   */
  constructor(yanchor, yhead) {
    this.yanchor = yanchor;
    this.yhead = yhead;
  }
  /**
   * @returns {any}
   */
  toJSON() {
    return {
      yanchor: relativePositionToJSON(this.yanchor),
      yhead: relativePositionToJSON(this.yhead)
    };
  }
  /**
   * @param {any} json
   * @return {YRange}
   */
  static fromJSON(json) {
    return new _YRange(createRelativePositionFromJSON(json.yanchor), createRelativePositionFromJSON(json.yhead));
  }
};

var cmState = __toESM(require("@codemirror/state"), 1);
var cmView = __toESM(require("@codemirror/view"), 1);
var YSyncConfig = class {
  constructor(ytext, awareness) {
    this.ytext = ytext;
    this.awareness = awareness;
  }
  /**
   * Helper function to transform an absolute index position to a Yjs-based relative position
   * (https://docs.yjs.dev/api/relative-positions).
   *
   * A relative position can be transformed back to an absolute position even after the document has changed. The position is
   * automatically adapted. This does not require any position transformations. Relative positions are computed based on
   * the internal Yjs document model. Peers that share content through Yjs are guaranteed that their positions will always
   * synced up when using relatve positions.
   *
   * ```js
   * import { ySyncFacet } from 'y-codemirror'
   *
   * ..
   * const ysync = view.state.facet(ySyncFacet)
   * // transform an absolute index position to a ypos
   * const ypos = ysync.getYPos(3)
   * // transform the ypos back to an absolute position
   * ysync.fromYPos(ypos) // => 3
   * ```
   *
   * It cannot be guaranteed that absolute index positions can be synced up between peers.
   * This might lead to undesired behavior when implementing features that require that all peers see the
   * same marked range (e.g. a comment plugin).
   *
   * @param {number} pos
   * @param {number} [assoc]
   */
  toYPos(pos, assoc = 0) {
    return createRelativePositionFromTypeIndex(this.ytext, pos, assoc);
  }
  /**
   * @param {Y.RelativePosition | Object} rpos
   */
  fromYPos(rpos) {
    const pos = createAbsolutePositionFromRelativePosition(createRelativePositionFromJSON(rpos), this.ytext.doc);
    if (pos == null || pos.type !== this.ytext) {
      throw new Error("[y-codemirror] The position you want to retrieve was created by a different document");
    }
    return {
      pos: pos.index,
      assoc: pos.assoc
    };
  }
  /**
   * @param {cmState.SelectionRange} range
   * @return {YRange}
   */
  toYRange(range) {
    const assoc = range.assoc;
    const yanchor = this.toYPos(range.anchor, assoc);
    const yhead = this.toYPos(range.head, assoc);
    return new YRange(yanchor, yhead);
  }
  /**
   * @param {YRange} yrange
   */
  fromYRange(yrange) {
    const anchor = this.fromYPos(yrange.yanchor);
    const head = this.fromYPos(yrange.yhead);
    if (anchor.pos === head.pos) {
      return cmState.EditorSelection.cursor(head.pos, head.assoc);
    }
    return cmState.EditorSelection.range(anchor.pos, head.pos);
  }
};
var ySyncFacet = cmState.Facet.define({
  combine(inputs) {
    return inputs[inputs.length - 1];
  }
});
var ySyncAnnotation = cmState.Annotation.define();
var YSyncPluginValue = class {
  /**
   * @param {cmView.EditorView} view
   */
  constructor(view) {
    this.view = view;
    this.conf = view.state.facet(ySyncFacet);
    this._observer = (event, tr) => {
      if (tr.origin !== this.conf) {
        const delta = event.delta;
        const changes = [];
        let pos = 0;
        for (let i = 0; i < delta.length; i++) {
          const d = delta[i];
          if (d.insert != null) {
            changes.push({ from: pos, to: pos, insert: d.insert });
          } else if (d.delete != null) {
            changes.push({ from: pos, to: pos + d.delete, insert: "" });
            pos += d.delete;
          } else {
            pos += d.retain;
          }
        }
        view.dispatch({ changes, annotations: [ySyncAnnotation.of(this.conf)] });
      }
    };
    this._ytext = this.conf.ytext;
    this._ytext.observe(this._observer);
  }
  /**
   * @param {cmView.ViewUpdate} update
   */
  update(update) {
    if (!update.docChanged || update.transactions.length > 0 && update.transactions[0].annotation(ySyncAnnotation) === this.conf) {
      return;
    }
    const ytext = this.conf.ytext;
    ytext.doc.transact(() => {
      let adj = 0;
      update.changes.iterChanges((fromA, toA, fromB, toB, insert) => {
        const insertText2 = insert.sliceString(0, insert.length, "\n");
        if (fromA !== toA) {
          ytext.delete(fromA + adj, toA - fromA);
        }
        if (insertText2.length > 0) {
          ytext.insert(fromA + adj, insertText2);
        }
        adj += insertText2.length - (toA - fromA);
      });
    }, this.conf);
  }
  destroy() {
    this._ytext.unobserve(this._observer);
  }
};
var ySync = cmView.ViewPlugin.fromClass(YSyncPluginValue);

var cmView2 = __toESM(require("@codemirror/view"), 1);
var cmState2 = __toESM(require("@codemirror/state"), 1);
var yRemoteSelectionsTheme = cmView2.EditorView.baseTheme({
  ".cm-ySelection": {},
  ".cm-yLineSelection": {
    padding: 0,
    margin: "0px 2px 0px 4px"
  },
  ".cm-ySelectionCaret": {
    position: "relative",
    borderLeft: "1px solid black",
    borderRight: "1px solid black",
    marginLeft: "-1px",
    marginRight: "-1px",
    boxSizing: "border-box",
    display: "inline"
  },
  ".cm-ySelectionCaretDot": {
    borderRadius: "50%",
    position: "absolute",
    width: ".4em",
    height: ".4em",
    top: "-.2em",
    left: "-.2em",
    backgroundColor: "inherit",
    transition: "transform .3s ease-in-out",
    boxSizing: "border-box"
  },
  ".cm-ySelectionCaret:hover > .cm-ySelectionCaretDot": {
    transformOrigin: "bottom center",
    transform: "scale(0)"
  },
  ".cm-ySelectionInfo": {
    position: "absolute",
    top: "-1.05em",
    left: "-1px",
    fontSize: ".75em",
    fontFamily: "serif",
    fontStyle: "normal",
    fontWeight: "normal",
    lineHeight: "normal",
    userSelect: "none",
    color: "white",
    paddingLeft: "2px",
    paddingRight: "2px",
    zIndex: 101,
    transition: "opacity .3s ease-in-out",
    backgroundColor: "inherit",
    // these should be separate
    opacity: 0,
    transitionDelay: "0s",
    whiteSpace: "nowrap"
  },
  ".cm-ySelectionCaret:hover > .cm-ySelectionInfo": {
    opacity: 1,
    transitionDelay: "0s"
  }
});
var yRemoteSelectionsAnnotation = cmState2.Annotation.define();
var YRemoteCaretWidget = class extends cmView2.WidgetType {
  /**
   * @param {string} color
   * @param {string} name
   */
  constructor(color, name) {
    super();
    this.color = color;
    this.name = name;
  }
  toDOM() {
    return (
      /** @type {HTMLElement} */
      element("span", [create5("class", "cm-ySelectionCaret"), create5("style", `background-color: ${this.color}; border-color: ${this.color}`)], [
        text("\u2060"),
        element("div", [
          create5("class", "cm-ySelectionCaretDot")
        ]),
        text("\u2060"),
        element("div", [
          create5("class", "cm-ySelectionInfo")
        ], [
          text(this.name)
        ]),
        text("\u2060")
      ])
    );
  }
  eq(widget) {
    return widget.color === this.color;
  }
  compare(widget) {
    return widget.color === this.color;
  }
  updateDOM() {
    return false;
  }
  get estimatedHeight() {
    return -1;
  }
  ignoreEvent() {
    return true;
  }
};
var YRemoteSelectionsPluginValue = class {
  /**
   * @param {cmView.EditorView} view
   */
  constructor(view) {
    this.conf = view.state.facet(ySyncFacet);
    this._listener = ({ added, updated, removed }, s, t) => {
      const clients = added.concat(updated).concat(removed);
      if (clients.findIndex((id2) => id2 !== this.conf.awareness.doc.clientID) >= 0) {
        view.dispatch({ annotations: [yRemoteSelectionsAnnotation.of([])] });
      }
    };
    this._awareness = this.conf.awareness;
    this._awareness.on("change", this._listener);
    this.decorations = cmState2.RangeSet.of([]);
  }
  destroy() {
    this._awareness.off("change", this._listener);
  }
  /**
   * @param {cmView.ViewUpdate} update
   */
  update(update) {
    const ytext = this.conf.ytext;
    const ydoc = (
      /** @type {Y.Doc} */
      ytext.doc
    );
    const awareness = this.conf.awareness;
    const decorations = [];
    const localAwarenessState = this.conf.awareness.getLocalState();
    if (localAwarenessState != null) {
      const hasFocus = update.view.hasFocus && update.view.dom.ownerDocument.hasFocus();
      const sel = hasFocus ? update.state.selection.main : null;
      const currentAnchor = localAwarenessState.cursor == null ? null : createRelativePositionFromJSON(localAwarenessState.cursor.anchor);
      const currentHead = localAwarenessState.cursor == null ? null : createRelativePositionFromJSON(localAwarenessState.cursor.head);
      if (sel != null) {
        const anchor = createRelativePositionFromTypeIndex(ytext, sel.anchor);
        const head = createRelativePositionFromTypeIndex(ytext, sel.head);
        if (localAwarenessState.cursor == null || !compareRelativePositions(currentAnchor, anchor) || !compareRelativePositions(currentHead, head)) {
          awareness.setLocalStateField("cursor", {
            anchor,
            head
          });
        }
      } else if (localAwarenessState.cursor != null && hasFocus) {
        awareness.setLocalStateField("cursor", null);
      }
    }
    awareness.getStates().forEach((state, clientid) => {
      if (clientid === awareness.doc.clientID) {
        return;
      }
      const cursor = state.cursor;
      if (cursor == null || cursor.anchor == null || cursor.head == null) {
        return;
      }
      const anchor = createAbsolutePositionFromRelativePosition(cursor.anchor, ydoc);
      const head = createAbsolutePositionFromRelativePosition(cursor.head, ydoc);
      if (anchor == null || head == null || anchor.type !== ytext || head.type !== ytext) {
        return;
      }
      const { color = "#30bced", name = "Anonymous" } = state.user || {};
      const colorLight = state.user && state.user.colorLight || color + "33";
      const start = min(anchor.index, head.index);
      const end = max(anchor.index, head.index);
      const startLine = update.view.state.doc.lineAt(start);
      const endLine = update.view.state.doc.lineAt(end);
      if (startLine.number === endLine.number) {
        decorations.push({
          from: start,
          to: end,
          value: cmView2.Decoration.mark({
            attributes: { style: `background-color: ${colorLight}` },
            class: "cm-ySelection"
          })
        });
      } else {
        decorations.push({
          from: start,
          to: startLine.from + startLine.length,
          value: cmView2.Decoration.mark({
            attributes: { style: `background-color: ${colorLight}` },
            class: "cm-ySelection"
          })
        });
        decorations.push({
          from: endLine.from,
          to: end,
          value: cmView2.Decoration.mark({
            attributes: { style: `background-color: ${colorLight}` },
            class: "cm-ySelection"
          })
        });
        for (let i = startLine.number + 1; i < endLine.number; i++) {
          const linePos = update.view.state.doc.line(i).from;
          decorations.push({
            from: linePos,
            to: linePos,
            value: cmView2.Decoration.line({
              attributes: { style: `background-color: ${colorLight}`, class: "cm-yLineSelection" }
            })
          });
        }
      }
      decorations.push({
        from: head.index,
        to: head.index,
        value: cmView2.Decoration.widget({
          side: head.index - anchor.index > 0 ? -1 : 1,
          // the local cursor should be rendered outside the remote selection
          block: false,
          widget: new YRemoteCaretWidget(color, name)
        })
      });
    });
    this.decorations = cmView2.Decoration.set(decorations, true);
  }
};
var yRemoteSelections = cmView2.ViewPlugin.fromClass(YRemoteSelectionsPluginValue, {
  decorations: (v) => v.decorations
});

var cmState3 = __toESM(require("@codemirror/state"), 1);
var cmView3 = __toESM(require("@codemirror/view"), 1);
var YUndoManagerConfig = class {
  /**
   * @param {Y.UndoManager} undoManager
   */
  constructor(undoManager) {
    this.undoManager = undoManager;
  }
  /**
   * @param {any} origin
   */
  addTrackedOrigin(origin) {
    this.undoManager.addTrackedOrigin(origin);
  }
  /**
   * @param {any} origin
   */
  removeTrackedOrigin(origin) {
    this.undoManager.removeTrackedOrigin(origin);
  }
  /**
   * @return {boolean} Whether a change was undone.
   */
  undo() {
    return this.undoManager.undo() != null;
  }
  /**
   * @return {boolean} Whether a change was redone.
   */
  redo() {
    return this.undoManager.redo() != null;
  }
};
var yUndoManagerFacet = cmState3.Facet.define({
  combine(inputs) {
    return inputs[inputs.length - 1];
  }
});
var yUndoManagerAnnotation = cmState3.Annotation.define();
var YUndoManagerPluginValue = class {
  /**
   * @param {cmView.EditorView} view
   */
  constructor(view) {
    this.view = view;
    this.conf = view.state.facet(yUndoManagerFacet);
    this._undoManager = this.conf.undoManager;
    this.syncConf = view.state.facet(ySyncFacet);
    this._beforeChangeSelection = null;
    this._onStackItemAdded = ({ stackItem, changedParentTypes }) => {
      if (changedParentTypes.has(this.syncConf.ytext) && this._beforeChangeSelection && !stackItem.meta.has(this)) {
        stackItem.meta.set(this, this._beforeChangeSelection);
      }
    };
    this._onStackItemPopped = ({ stackItem }) => {
      const sel = stackItem.meta.get(this);
      if (sel) {
        const selection = this.syncConf.fromYRange(sel);
        view.dispatch(view.state.update({
          selection,
          effects: [cmView3.EditorView.scrollIntoView(selection)]
        }));
        this._storeSelection();
      }
    };
    this._storeSelection = () => {
      this._beforeChangeSelection = this.syncConf.toYRange(this.view.state.selection.main);
    };
    this._undoManager.on("stack-item-added", this._onStackItemAdded);
    this._undoManager.on("stack-item-popped", this._onStackItemPopped);
    this._undoManager.addTrackedOrigin(this.syncConf);
  }
  /**
   * @param {cmView.ViewUpdate} update
   */
  update(update) {
    if (update.selectionSet && (update.transactions.length === 0 || update.transactions[0].annotation(ySyncAnnotation) !== this.syncConf)) {
      this._storeSelection();
    }
  }
  destroy() {
    this._undoManager.off("stack-item-added", this._onStackItemAdded);
    this._undoManager.off("stack-item-popped", this._onStackItemPopped);
    this._undoManager.removeTrackedOrigin(this.syncConf);
  }
};
var yUndoManager = cmView3.ViewPlugin.fromClass(YUndoManagerPluginValue);
var undo = ({ state, dispatch }) => state.facet(yUndoManagerFacet).undo() || true;
var redo = ({ state, dispatch }) => state.facet(yUndoManagerFacet).redo() || true;

var yCollab = (ytext, awareness, { undoManager = new UndoManager(ytext) } = {}) => {
  const ySyncConfig = new YSyncConfig(ytext, awareness);
  const plugins = [
    ySyncFacet.of(ySyncConfig),
    ySync
  ];
  if (awareness) {
    plugins.push(
      yRemoteSelectionsTheme,
      yRemoteSelections
    );
  }
  if (undoManager !== false) {
    plugins.push(
      yUndoManagerFacet.of(new YUndoManagerConfig(undoManager)),
      yUndoManager,
      cmView4.EditorView.domEventHandlers({
        beforeinput(e, view) {
          if (e.inputType === "historyUndo") return undo(view);
          if (e.inputType === "historyRedo") return redo(view);
          return false;
        }
      })
    );
  }
  return plugins;
};

function parsePairing(params2) {
  let url;
  try {
    url = new URL(params2.url);
  } catch {
    throw Error("Invalid connection URL");
  }
  if (!["ws:", "wss:"].includes(url.protocol) || !url.hostname || url.username || url.password || url.hash || url.search) throw Error("Invalid connection URL");
  if (typeof params2.token !== "string" || params2.token.length < 32 || params2.token.length > 512) throw Error("Invalid pairing token");
  return { url: url.toString(), token: params2.token };
}

function canonicalEndpoint(url) {
  const p = parsePairing({ url, token: "validation-only-".repeat(3) });
  return new URL(p.url).href;
}
function assertStateOrigin(settings) {
  if (!settings.state) return;
  if (!settings.serverId) throw Error("\u65E7\u5FEB\u7167\u7F3A\u5C11\u5DF2\u9A8C\u8BC1\u7684\u670D\u52A1\u5668\u8EAB\u4EFD\uFF1B\u4FDD\u7559\u539F\u5E93\uFF0C\u5728\u65B0\u7A7A\u6D4B\u8BD5\u5E93\u52A0\u5165\u3002");
  if (!settings.stateOrigin) throw Error("\u65E7\u540C\u6B65\u5FEB\u7167\u5C1A\u672A\u7ED1\u5B9A\u670D\u52A1\u5668\uFF1B\u8BF7\u4FDD\u7559\u65E7\u5E93\uFF0C\u5728\u65B0\u7A7A\u6D4B\u8BD5\u5E93\u52A0\u5165\u76EE\u6807\u670D\u52A1\u5668\u3002");
  if (canonicalEndpoint(settings.url) !== canonicalEndpoint(settings.stateOrigin)) throw Error("\u5DF2\u963B\u6B62\u628A\u65E7\u540C\u6B65\u5FEB\u7167\u53D1\u9001\u5230\u4E0D\u540C\u670D\u52A1\u5668\u3002\u8BF7\u4FDD\u7559\u65E7\u5E93\u5E76\u65B0\u5EFA\u7A7A V2 \u6D4B\u8BD5\u5E93\u52A0\u5165\u3002");
}
function planConnection(settings, { url, token, mode }, files) {
  const p = parsePairing({ url, token });
  if (!["create", "join"].includes(mode)) throw Error("\u8BF7\u9009\u62E9\u521B\u5EFA\u6216\u52A0\u5165");
  assertStateOrigin({ ...settings, url: p.url });
  if (!settings.state && files.length) throw Error("\u9996\u6B21\u521B\u5EFA\u6216\u52A0\u5165\u5FC5\u987B\u4F7F\u7528\u7A7A\u6D4B\u8BD5\u5E93\uFF1B\u8BF7\u5148\u4FDD\u5B58\u73B0\u6709\u6587\u4EF6\u3002");
  return { ...settings, url: canonicalEndpoint(p.url), token: p.token, enabled: false, mode };
}

function coalescedTask(enqueue, run, allowed = () => true) {
  let queued = false, dirty = false;
  const request = () => {
    dirty = true;
    if (queued) return;
    queued = true;
    enqueue(async () => {
      dirty = false;
      try {
        if (allowed()) await run();
      } finally {
        queued = false;
        if (dirty && allowed()) request();
      }
    });
  };
  return { request, cancel() {
    dirty = false;
  }, get queued() {
    return queued;
  } };
}

async function inventory(files, read, policy = {}) {
  const result = { totalFiles: files.length, totalBytes: 0, markdownFiles: 0, imageFiles: 0, otherFiles: 0, eligibleFiles: 0, eligibleBytes: 0, unsupportedFiles: 0, excludedFiles: 0, conflicts: [], files: [] };
  const seen = /* @__PURE__ */ new Map();
  for (const f of files) {
    const p = f.path;
    const excluded = p.split("/").some((s) => s.startsWith(".")) || p === "realtime-lab-v2.json" || p === "realtime-lab-v3-files.json";
    if (excluded) {
      result.excludedFiles++;
      result.totalBytes += f.size ?? 0;
      result.files.push({ path: p, status: "excluded", bytes: f.size ?? 0, sha256: null });
      continue;
    }
    if (/\.md$/i.test(p)) result.markdownFiles++;
    else if (IMAGE.test(p)) result.imageFiles++;
    else result.otherFiles++;
    const bytes = new Uint8Array(await read(p)), digest = await crypto.subtle.digest("SHA-256", bytes);
    const sha256 = Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
    const accepted = (policy.supported || supported)(p), limit = policy.maxFileSize ? policy.maxFileSize(p) : /\.md$/i.test(p) ? MAX_TEXT : MAX_IMAGE;
    const status = !accepted ? "unsupported" : bytes.length > limit ? "oversize" : "eligible";
    const row = { path: p, status, bytes: bytes.length, sha256 };
    result.totalBytes += bytes.length;
    result.files.push(row);
    if (status === "eligible") {
      result.eligibleFiles++;
      result.eligibleBytes += bytes.length;
    } else result.unsupportedFiles++;
    const key = p.normalize("NFC").toLowerCase();
    if (seen.has(key)) result.conflicts.push([seen.get(key), p]);
    else seen.set(key, p);
  }
  return result;
}
function diffInventory(local, remote) {
  if (!remote) return { remoteKnown: false, automaticWrites: 0, differences: local.files.map((f) => ({ path: f.path, status: f.status === "excluded" ? "excluded" : f.status === "eligible" ? "remote-unknown" : f.status })) };
  const other = new Map(remote.files.map((f) => [f.path, f]));
  const differences = [];
  for (const f of local.files) {
    const r2 = other.get(f.path);
    other.delete(f.path);
    differences.push({ path: f.path, status: f.status !== "eligible" ? f.status : !r2 ? "local-only" : r2.sha256 === f.sha256 ? "equal" : "different" });
  }
  for (const f of other.values()) differences.push({ path: f.path, status: "remote-only" });
  return { remoteKnown: true, automaticWrites: 0, differences };
}

async function allowedV3(vault) {
  if (!vault.getName().startsWith("Realtime-Lab-V3-Files-")) return false;
  if (await vault.adapter.exists("realtime-lab-v2.json")) return false;
  try {
    const m = JSON.parse(await vault.adapter.read("realtime-lab-v3-files.json"));
    return m.isolatedLab === true && m.protocol === 3 && m.capability === "versioned-files-v1";
  } catch {
    return false;
  }
}
async function initializeV3(vault) {
  if (!vault.getName().startsWith("Realtime-Lab-V3-Files-")) throw Error("Not a V3 isolated vault");
  if (await vault.adapter.exists("realtime-lab-v2.json")) throw Error("V2 marker refused; use a new V3 test vault");
  if (await allowedV3(vault)) return;
  const files = vault.getFiles?.() || [];
  if (files.some((f) => f.path !== "realtime-lab-v3-files.json" && !f.path.startsWith("."))) throw Error("Initialization requires an empty test vault");
  await vault.adapter.write("realtime-lab-v3-files.json", JSON.stringify({ isolatedLab: true, protocol: 3, capability: "versioned-files-v1" }));
}
async function inspectInitialization(vault) {
  if (!vault.getName().startsWith("Realtime-Lab-V3-Files-")) throw Error("Not a V3 isolated vault");
  if (await allowedV3(vault)) return { action: "already-initialized", files: [] };
  const files = (vault.getFiles?.() || []).filter((f) => f.path !== "realtime-lab-v3-files.json" && !f.path.startsWith("."));
  return { action: files.length ? "preview-only" : "initialize-empty", files: files.map((f) => f.path) };
}

var ROOT = ".realtime-lab-v3-cache";
var ObsidianBlobCache = class {
  constructor(adapter, { onOperation = (ms, failed) => {
  }, onStart = () => ((bytes, failed) => {
  }) } = {}) {
    this.onStart = onStart;
    this.onOperation = onOperation;
    this.adapter = adapter;
    this.busy = false;
    this.quota = null;
    this.reservations = Promise.resolve();
    this.metrics = { quotaScans: 0, quotaRecords: 0, reservations: 0, operations: 0, failures: 0, maxOperationMs: 0, lastOperation: null };
  }
  // The cache is private to this plugin instance. Rebuild once on open, including
  // incomplete and retained blobs; never trust a durable quota counter after a crash.
  async scanQuota() {
    await this.mkdir(ROOT);
    const listing = await this.io("list", ROOT);
    let bytes = 0, count = 0;
    for (const folder of listing.folders) {
      const p = folder + "/state.json";
      if (!await this.io("exists", p)) continue;
      const m = JSON.parse(await this.io("read", p));
      if (!Number.isSafeInteger(m.size) || m.size < 0 || m.size > MAX_BLOB_BYTES) throw Error("Invalid cache quota metadata");
      bytes += m.size;
      count++;
      this.metrics.quotaRecords++;
    }
    this.metrics.quotaScans++;
    return { bytes, count };
  }
  invalidateQuota() {
    this.quota = null;
  }
  async io(method, ...args2) {
    const started = Date.now(), done = this.onStart();
    let failed = false;
    this.metrics.operations++;
    this.metrics.lastOperation = method;
    try {
      return await this.adapter[method](...args2);
    } catch (e) {
      failed = true;
      this.metrics.failures++;
      this.invalidateQuota();
      throw new Error("Cache " + method + ": " + String(e?.message || e), { cause: e });
    } finally {
      this.onOperation(Date.now() - started, failed);
      done?.(0, failed);
      this.metrics.maxOperationMs = Math.max(this.metrics.maxOperationMs, Date.now() - started);
    }
  }
  check(ref) {
    if (!ref || !/^[a-f0-9]{64}$/.test(ref.hash) || !Number.isSafeInteger(ref.size) || ref.size < 0 || ref.size > MAX_BLOB_BYTES) throw Error("Invalid cache reference");
  }
  base(ref) {
    this.check(ref);
    return ROOT + "/" + ref.hash;
  }
  async mkdir(p) {
    if (!await this.io("exists", p)) await this.io("mkdir", p);
  }
  async state(ref) {
    const base = this.base(ref), p = base + "/state.json";
    if (!await this.io("exists", p)) return { size: ref.size, offset: 0, complete: false };
    const s = JSON.parse(await this.io("read", p));
    if (s.size !== ref.size || !Number.isSafeInteger(s.offset) || s.offset < 0 || s.offset > ref.size || typeof s.complete !== "boolean" || s.complete && s.offset !== ref.size || !s.complete && s.offset !== ref.size && s.offset % CHUNK_BYTES) throw Error("Invalid cached upload state");
    return s;
  }
  async has(ref) {
    return (await this.state(ref)).complete;
  }
  async read(ref, p, n) {
    this.check(ref);
    if (ref.size === 0 && p === 0 && n === 0) return new Uint8Array();
    if (p % CHUNK_BYTES || n !== Math.min(CHUNK_BYTES, ref.size - p)) throw Error("Unaligned cache read");
    const bytes = new Uint8Array(await this.io("readBinary", this.base(ref) + "/" + p + ".bin"));
    if (bytes.length !== n) throw Error("Short cache chunk");
    return bytes;
  }
  async reserve(ref) {
    const job = this.reservations.then(async () => {
      const base = this.base(ref);
      if (!this.quota) this.quota = await this.scanQuota();
      if (await this.io("exists", base + "/state.json")) return;
      const q = this.quota;
      if (q.count >= MAX_DISK_OBJECTS || q.bytes + ref.size > MAX_DISK_BYTES) throw Error("Local cache quota reached; retained recovery blobs are included");
      await this.mkdir(base);
      await this.io("write", base + "/state.json", JSON.stringify({ size: ref.size, offset: 0, complete: false }));
      q.bytes += ref.size;
      q.count++;
      this.metrics.reservations++;
    });
    this.reservations = job.catch(() => {
      this.invalidateQuota();
    });
    return job;
  }
  async append(ref, p, bytes) {
    await this.reserve(ref);
    const s = await this.state(ref);
    if (s.complete) return;
    if (p !== s.offset || bytes.length !== Math.min(CHUNK_BYTES, ref.size - p)) throw Error("Invalid cache chunk offset");
    await this.io("writeBinary", this.base(ref) + "/" + p + ".bin", bytes.slice().buffer);
    await this.io("write", this.base(ref) + "/state.json", JSON.stringify({ size: ref.size, offset: p + bytes.length, complete: false }));
  }
  async finish(ref) {
    await this.reserve(ref);
    if ((await this.state(ref)).offset !== ref.size) throw Error("Cache incomplete");
    if (await hashSource(this.source(ref)) !== ref.hash) throw Error("Cache hash mismatch");
    await this.io("write", this.base(ref) + "/state.json", JSON.stringify({ size: ref.size, offset: ref.size, complete: true }));
  }
  source(ref) {
    this.check(ref);
    return { size: ref.size, read: (p, n) => this.read(ref, p, n) };
  }
  sink(ref) {
    return { length: async () => (await this.state(ref)).offset, write: (p, b) => this.append(ref, p, b), read: (p, n) => this.read(ref, p, n), commit: () => this.finish(ref) };
  }
  async stage(source, { signal } = {}) {
    if (this.busy) throw Error("Cache staging busy");
    this.busy = true;
    try {
      if (source.size > MAX_BLOB_BYTES) throw Error("Image exceeds 16 MiB");
      const ref = { size: source.size, hash: await hashSource(source, signal) };
      let s = await this.state(ref);
      while (!s.complete && s.offset < ref.size) {
        signal?.throwIfAborted();
        const b = await source.read(s.offset, Math.min(CHUNK_BYTES, ref.size - s.offset));
        await this.append(ref, s.offset, b);
        s = await this.state(ref);
      }
      if (!s.complete) await this.finish(ref);
      return ref;
    } finally {
      this.busy = false;
    }
  }
  async materialize(ref) {
    if (!await this.has(ref)) throw Error("Cache not verified");
    const out = new Uint8Array(ref.size);
    for (let p = 0; p < ref.size; p += CHUNK_BYTES) out.set(await this.read(ref, p, Math.min(CHUNK_BYTES, ref.size - p)), p);
    if (await hashSource({ size: ref.size, read: async (p, n) => out.subarray(p, p + n) }) !== ref.hash) throw Error("Cache changed");
    return out.buffer;
  }
};

function requestFetch(requestUrl2, onOperation = (ms, bytes, failed) => {
}, onStart = () => ((bytes, failed) => {
})) {
  return async (url, options = {}) => {
    const started = Date.now(), done = onStart();
    let bytes = 0, failed = false;
    try {
      options.signal?.throwIfAborted();
      const body = options.body;
      if (body && (!(body instanceof Uint8Array) || body.length > CHUNK_BYTES)) throw Error("Native request frame exceeds 32 KiB");
      const r2 = await requestUrl2({ url: String(url), method: options.method || "GET", headers: { ...options.headers, ...body ? { "Content-Type": "application/octet-stream" } : {} }, body: body ? body.slice().buffer : void 0, throw: false });
      options.signal?.throwIfAborted();
      bytes = r2.arrayBuffer.byteLength;
      if (r2.status >= 400) failed = true;
      const limit = (options.method || "GET") === "GET" && new URL(String(url)).pathname.endsWith("/v3/batch") ? BATCH_BYTES : CHUNK_BYTES;
      if (r2.arrayBuffer.byteLength > limit) throw Error("Native response frame exceeds 32 KiB");
      return new Response(r2.status === 204 ? null : r2.arrayBuffer, { status: r2.status, headers: r2.headers });
    } catch (e) {
      failed = true;
      throw e;
    } finally {
      onOperation(Date.now() - started, bytes, failed);
      done?.(bytes, failed);
    }
  };
}

function transientTransferFailure(error) {
  const s = String(error?.message || error);
  if (/身份|identity mismatch|认证|401|403|quota|capacity|容量|快照|snapshot|persist|storage|磁盘|本地保存|invalid|unsupported/i.test(s)) return false;
  return /blob request failed \(409\)|failed to fetch|fetch failed|load failed|network|网络|ECONN|ENOTFOUND|ETIMEDOUT|disconnected|request timeout|request failed \((?:408|429|5\d\d)\)/i.test(s);
}
function transientFilesystemFailure(error) {
  return /File system operation timed out|(?:^|\W)(?:EBUSY|EAGAIN|EMFILE|ENFILE)(?:\W|$)/i.test(String(error?.message || error));
}
function recoverableSyncFailure(error) {
  return transientFilesystemFailure(error) || transientTransferFailure(error);
}

function changedPaths(doc2, transaction) {
  const paths = /* @__PURE__ */ new Set();
  for (const [name, type] of doc2.share) {
    if (!transaction.changed.has(type)) continue;
    if (name.startsWith("text:")) paths.add(name.slice(5));
    else if (name === "files" || name === "deleted") {
      for (const key of transaction.changed.get(type)) if (typeof key === "string") paths.add(key);
    } else if (name === "blobVersions") for (const key of transaction.changed.get(type)) {
      const v = type.get(key);
      if (v?.path) paths.add(v.path);
    }
  }
  return [...paths];
}
function queueRows({ metadata = [], files = [], dirty = [], failures = [], downloads = [] }) {
  const rows = /* @__PURE__ */ new Map();
  for (const path of metadata) rows.set(path, { path, state: "\u7B49\u5F85\u670D\u52A1\u5668\u786E\u8BA4" });
  for (const p of files) rows.set(p.path, { path: p.path, state: "\u6587\u4EF6\u5F85\u4F20", bytes: p.size });
  for (const path of dirty) rows.set(path, { path, state: "\u7B49\u5F85\u4E0A\u4F20" });
  for (const path of downloads) rows.set(path, { path, state: "\u63A5\u6536\u5904\u7406\u4E2D" });
  for (const [path, error] of failures) rows.set(path, { path, state: transientTransferFailure(error) ? "\u7F51\u7EDC\u4E2D\u65AD\uFF0C\u7B49\u5F85\u81EA\u52A8\u91CD\u8BD5" : "\u5931\u8D25\uFF0C\u53EF\u91CD\u8BD5", error });
  return [...rows.values()];
}
function fileProgress({ known = [], pending = [], failures = [], active = 0, ready = false }) {
  const paths = new Set(known), waiting = new Set(pending.filter((p) => p !== "*"));
  for (const p of waiting) paths.add(p);
  const retry = new Set(failures.filter((p) => p !== "*"));
  for (const p of retry) {
    paths.add(p);
    waiting.add(p);
  }
  const total = paths.size, remaining = waiting.size;
  return { available: ready && !pending.includes("*"), total, completed: Math.max(0, total - remaining), remaining, retry: retry.size, active };
}

var CONFLICT_CAPABILITY = "conflict-review-v1";
var fingerprint = (c) => JSON.stringify(c ? c.kind === "text" ? { kind: "text", data: c.data } : { kind: c.kind, hash: c.hash, size: c.size } : null);
var sameContent = (a, b) => fingerprint(a) === fingerprint(b);
function textDifference(a, b) {
  const x = a.slice(0, 2e4).split("\n"), y = b.slice(0, 2e4).split("\n");
  let start = 0, end = 0;
  while (start < x.length && start < y.length && x[start] === y[start]) start++;
  while (end < x.length - start && end < y.length - start && x[x.length - 1 - end] === y[y.length - 1 - end]) end++;
  const removed = x.slice(start, x.length - end), added = y.slice(start, y.length - end);
  return { removed: removed.slice(0, 100).map((s) => "\u2212 " + s).join("\n"), added: added.slice(0, 100).map((s) => "+ " + s).join("\n"), truncated: a.length > 2e4 || b.length > 2e4 || removed.length > 100 || added.length > 100, equal: a === b };
}

var markdown = (p) => /\.md$/i.test(p);
function content(doc2, p) {
  const m = doc2.getMap("files").get(p);
  if (!m || m.deleted || doc2.getMap("deleted").has(p)) return null;
  return m.kind === "text" ? { kind: "text", data: doc2.getText("text:" + p).toString() } : { kind: m.kind, hash: m.hash, size: m.size, version: m.version };
}
function entries(doc2) {
  const out = {};
  for (const p of doc2.getMap("files").keys()) {
    const c = content(doc2, p);
    if (c) out[p] = c;
  }
  return out;
}
function put(doc2, p, c, origin) {
  if (!supportedFile(p)) throw Error("Unsupported path");
  if (c.kind !== "text" && c.version && doc2.getMap("blobVersions").has(c.version)) {
    const v = doc2.getMap("blobVersions").get(c.version);
    if (v.path !== p) c = { ...c, version: crypto.randomUUID() };
    else {
      if (v.hash !== c.hash || v.size !== c.size) throw Error("Immutable version mismatch");
      return;
    }
  }
  doc2.transact(() => {
    const files = doc2.getMap("files");
    doc2.getMap("deleted").delete(p);
    if (c.kind === "text") {
      if (!markdown(p)) throw Error("Inline text requires Markdown");
      if (files.get(p)?.kind === "file" && origin !== "explicit-history-restore") throw Error("Whole-file Markdown cannot silently switch to inline CRDT");
      patchText(doc2, p, c.data, origin);
      const prior = files.get(p);
      if (!prior || prior.deleted || prior.kind !== "text") files.set(p, { kind: "text", deleted: false });
    } else {
      const version = c.version || crypto.randomUUID(), v = { path: p, hash: c.hash, size: c.size };
      validateRef(v);
      const kind = c.kind === "image" ? "image" : "file";
      if (markdown(p) && kind !== "file" || imagePath(p) && kind !== "image" || !imagePath(p) && kind !== "file") throw Error("File kind/path mismatch");
      doc2.getMap("blobVersions").set(version, v);
      files.set(p, { kind, hash: c.hash, size: c.size, version, deleted: false });
      if (markdown(p)) {
        const text2 = doc2.getText("text:" + p);
        if (text2.length) text2.delete(0, text2.length);
      }
    }
  }, origin);
}
function remove(doc2, p, origin) {
  if (!supportedFile(p)) throw Error("Unsupported path");
  doc2.transact(() => {
    doc2.getMap("deleted").set(p, true);
    doc2.getMap("files").set(p, { kind: doc2.getMap("files").get(p)?.kind || (markdown(p) ? "text" : imagePath(p) ? "image" : "file"), deleted: true });
  }, origin);
}
function validateRef(v) {
  if (!v || !supportedFile(v.path) || !/^[a-f0-9]{64}$/.test(v.hash) || !Number.isSafeInteger(v.size) || v.size < 0 || v.size > maxFileSize(v.path) || Object.keys(v).some((k) => !["path", "hash", "size"].includes(k))) throw Error("Invalid blob reference or per-file size limit");
}
function validate(doc2, hasBlob) {
  let total = 0, count = 0, active = 0, inline = 0;
  const names = /* @__PURE__ */ new Set();
  for (const name of doc2.share.keys()) {
    if (!["files", "deleted", "blobVersions"].includes(name) && !(name.startsWith("text:") && supportedFile(name.slice(5)) && markdown(name))) throw Error("Invalid V3 document root");
    if (name.startsWith("text:")) {
      const n = new TextEncoder().encode(doc2.getText(name).toString()).length;
      if (n > MAX_INLINE_NOTE) throw Error("Inline note exceeds 16 KiB; explicit whole-file mode required");
      inline += n;
    }
  }
  if (inline > MAX_INLINE_TOTAL) throw Error("Inline CRDT budget exceeds 128 KiB; explicit whole-file mode required");
  for (const [id2, v] of doc2.getMap("blobVersions")) {
    if (!/^[a-f0-9-]{36}$/.test(id2)) throw Error("Invalid version id");
    validateRef(v);
    if (hasBlob && !hasBlob(v.hash, v.size)) throw Error("Referenced blob is not durably uploaded");
  }
  if (doc2.getMap("deleted").size > MAX_PATHS) throw Error("Tombstone limit 8192");
  for (const [p, v] of doc2.getMap("deleted")) if (!supportedFile(p) || v !== true) throw Error("Invalid tombstone");
  for (const [p, m] of doc2.getMap("files")) {
    if (!supportedFile(p) || !m || !["text", "image", "file"].includes(m.kind) || typeof m.deleted !== "boolean" || m.kind === "text" && !markdown(p) || m.kind === "image" && !imagePath(p) || m.kind === "file" && imagePath(p) || Object.keys(m).some((k) => !["kind", "deleted", "hash", "size", "version"].includes(k))) throw Error("Invalid V3 file metadata");
    const canonical = p.toLowerCase();
    if (names.has(canonical)) throw Error("Case-insensitive path collision");
    names.add(canonical);
    if (++count > MAX_PATHS) throw Error("Tracked path limit 8192 including tombstones");
    if (m.deleted || doc2.getMap("deleted").has(p)) continue;
    if (++active > MAX_ACTIVE_PATHS) throw Error("Active path limit 6000");
    if (m.kind === "text") total += new TextEncoder().encode(doc2.getText("text:" + p).toString()).length;
    else {
      validateRef({ path: p, hash: m.hash, size: m.size });
      const v = doc2.getMap("blobVersions").get(m.version);
      if (!v || v.path !== p || v.hash !== m.hash || v.size !== m.size) throw Error("Missing immutable blob version");
      total += m.size;
    }
    if (total > MAX_LIVE_BYTES) throw Error("Active logical content exceeds 256 MiB; server/cache disk also capped");
  }
  if (encodeStateAsUpdate(doc2).length > MAX_STATE) throw Error("V3 metadata/text state exceeds 2 MiB");
  return total;
}

var PATH_SAFETY_CAPABILITY = "protected-paths-v1";
var UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
function validatePathOperation(op) {
  if (!op || !UUID.test(op.id) || !["delete", "rename"].includes(op.kind) || Object.keys(op).some((k) => !["id", "kind", "entries"].includes(k)) || !Array.isArray(op.entries) || !op.entries.length || op.entries.length > 3e3 || new TextEncoder().encode(JSON.stringify(op)).length > 2 * 1024 * 1024) throw Error("Invalid protected path operation");
  const sources = /* @__PURE__ */ new Set(), targets = /* @__PURE__ */ new Set();
  for (const e of op.entries) {
    if (!e || !supportedFile(e.from) || sources.has(e.from) || Object.keys(e).some((k) => !["from", "to", "base", "target"].includes(k)) || !e.base || !["text", "image", "file"].includes(e.base.kind)) throw Error("Invalid protected source");
    sources.add(e.from);
    if (op.kind === "rename") {
      if (!supportedFile(e.to) || e.to.toLowerCase() === e.from.toLowerCase() || targets.has(e.to.toLowerCase())) throw Error("Invalid or case-only rename target");
      targets.add(e.to.toLowerCase());
    } else if (e.to !== void 0) throw Error("Delete cannot have target");
  }
  return op;
}
function bulkDeletion(count, total) {
  return count >= 5 || count >= 3 && count / Math.max(1, total) >= 0.25;
}
function operationPaths(op) {
  return op.entries.flatMap((e) => e.to ? [e.from, e.to] : [e.from]);
}
function validateSafetyQueue(queue, serverId) {
  if (!queue) return;
  if (queue.serverId !== serverId || !Array.isArray(queue.items) || queue.items.length > 128 || queue.items.reduce((n, x) => n + x.op.entries.length, 0) > 3e3 || new TextEncoder().encode(JSON.stringify(queue)).length > 2 * 1024 * 1024) throw Error("Protected queue identity or capacity mismatch");
  for (const item of queue.items) {
    validatePathOperation(item.op);
    if (typeof item.approved !== "boolean" || typeof item.backedUp !== "boolean") throw Error("Invalid protected queue item");
  }
}

var DIAGNOSTICS_CAPABILITY = "device-diagnostics-v1";
function documentDigest(doc2) {
  const active = entries(doc2), deleted = new Set(doc2.getMap("deleted").keys());
  for (const [path, m] of doc2.getMap("files")) if (m.deleted) deleted.add(path);
  const state = ["content-v1", Object.keys(active).sort().map((path) => [path, active[path]]), [...deleted].sort()];
  return new Sha256().update(new TextEncoder().encode(JSON.stringify(state))).hex();
}

function badgeState({ ready = false, preparing = false, receiving = false, connecting = false, error = false, confirmed = false, uploads = 0, downloads = 0, unknown = false, known = 0, conflicts = 0, protectedCount = 0, progress, retrying = false }) {
  let tone = "offline", icon = "cloud-off", label = "\u79BB\u7EBF", busy = false;
  if (ready && conflicts) {
    tone = "error";
    icon = "alert-circle";
    label = "\u51B2\u7A81\u5F85\u5904\u7406";
  } else if (ready && protectedCount) {
    tone = "waiting";
    icon = "alert-circle";
    label = "\u8DEF\u5F84\u64CD\u4F5C\u5F85\u786E\u8BA4";
  } else if (error && retrying && ready) {
    tone = "busy";
    icon = "refresh-cw";
    label = "\u6062\u590D\u4E2D";
    busy = true;
  } else if (error) {
    tone = "error";
    icon = "alert-circle";
    label = "\u9700\u5904\u7406";
  } else if (!ready && connecting) {
    tone = "busy";
    icon = "refresh-cw";
    label = "\u8FDE\u63A5\u4E2D";
    busy = true;
  } else if (ready && (preparing || receiving || uploads || downloads || unknown)) {
    tone = "busy";
    icon = "refresh-cw";
    label = preparing ? "\u51C6\u5907\u4E2D" : receiving ? "\u63A5\u6536\u4E2D" : "\u540C\u6B65\u4E2D";
    busy = true;
  } else if (ready && !confirmed) {
    tone = "waiting";
    icon = "clock";
    label = "\u5F85\u786E\u8BA4";
  } else if (ready) {
    tone = "confirmed";
    icon = "check";
    label = "\u5DF2\u786E\u8BA4";
  }
  const legacyCounts = "\u2191" + (unknown ? "?" : uploads) + " \u2193" + downloads;
  let display = "Sync: " + (ready && conflicts ? "\u26A0 \u51B2\u7A81" + conflicts : ready && protectedCount ? "\u26A0 \u5F85\u786E\u8BA4" + protectedCount : tone === "confirmed" ? "\u26A1" : tone === "busy" ? "\u21BB" : tone === "waiting" ? "\u25F7" : tone === "error" ? "\u26A0 \u5F02\u5E38" : "\u25CB \u79BB\u7EBF");
  const counts = progress?.available ? "\u5DF2\u5B8C\u6210 " + progress.completed + "/" + progress.total + " \xB7 \u5269\u4F59 " + progress.remaining + " \xB7 \u5F85\u91CD\u8BD5 " + progress.retry : progress ? "\u8FDB\u5EA6\u5F85\u6838\u5BF9" : legacyCounts;
  if (progress && !conflicts && !protectedCount) {
    display = "Sync: " + (label === "\u6062\u590D\u4E2D" ? "\u6062\u590D\u4E2D" : tone === "busy" ? "\u540C\u6B65\u4E2D" : tone === "confirmed" ? "\u2713" : tone === "error" ? "\u26A0 \u9700\u5904\u7406" : label);
  }
  return { tone, icon, label, display, busy, counts, description: (progress?.available ? counts + "\uFF1B\u5F53\u524D\u63A5\u6536\u5E76\u53D1" + progress.active + "\uFF1B\u5F85\u91CD\u8BD5\u5305\u542B\u5728\u5269\u4F59\u4E2D\uFF1B" : "\u8FDB\u5EA6\u5C1A\u672A\u6838\u5BF9\uFF1B") + label + "\uFF1B\u5F85\u5904\u7406\u51B2\u7A81" + conflicts + "\uFF1B\u5E93\u5185" + known + "\u4E2A\u8DEF\u5F84\uFF1B\u5F85\u4E0A\u4F20\u6216\u786E\u8BA4" + (unknown ? "\u6570\u91CF\u5F85\u6838\u5BF9" : uploads) + "\uFF1B\u5F53\u524D\u63A5\u6536" + downloads + "\u3002\u70B9\u51FB\u67E5\u770B\u540C\u6B65\u8BE6\u60C5\u3002\u670D\u52A1\u5668\u786E\u8BA4\u4E0D\u7B49\u4E8E\u5176\u4ED6\u8BBE\u5907\u5DF2\u6536\u5230\u3002" };
}
var badgeCSS = `
.rl-sync-row{display:flex;justify-content:flex-end;flex:0 0 auto;min-height:25px;padding:0 18px 3px;background:var(--background-primary);z-index:1}
.rl-sync-row .rl-sync-badge{display:inline-flex;align-items:center;gap:7px;width:max-content;max-width:100%;flex-wrap:wrap;justify-content:flex-end;min-height:24px;padding:0;border:0;border-radius:0;background:transparent;color:var(--text-muted);font-size:12px;font-weight:400;line-height:24px;white-space:nowrap;cursor:pointer;box-shadow:none;font-variant-numeric:tabular-nums}
.rl-sync-badge .rl-sync-icon{display:none}
.rl-sync-badge .rl-sync-label,.rl-sync-badge .rl-sync-counts{white-space:nowrap}
.rl-sync-badge[data-tone=error]{color:var(--text-error)}
.rl-sync-badge:hover{color:var(--text-normal)}
.rl-sync-badge:focus-visible{outline:2px solid var(--interactive-accent);outline-offset:3px}
body.is-mobile .rl-sync-row{padding:0 20px 2px;min-height:28px;z-index:5;background:transparent;pointer-events:none}
body.is-mobile .rl-sync-row .rl-sync-badge{pointer-events:auto}
body.is-mobile .rl-sync-row .rl-sync-badge{font-size:11px;min-height:28px;line-height:18px;column-gap:6px;row-gap:0}
.rl-history-modal .setting-item-control{flex-wrap:wrap;gap:8px}
.rl-history-modal .modal-title{overflow-wrap:anywhere}
.rl-history-preview{white-space:pre-wrap;overflow-wrap:anywhere;max-height:45vh;overflow:auto;padding:12px;background:var(--background-secondary);font-size:var(--font-smaller)}
.rl-history-image{display:block;max-width:100%;max-height:45vh;object-fit:contain;margin:12px auto}
.rl-sync-details-note{color:var(--text-muted);font-size:var(--font-ui-small);line-height:1.6}
`;

var SnapshotScheduler = class {
  constructor({ capture, persist, delayMs = 0, lastState = "", onError = () => {
  } }) {
    Object.assign(this, { capture, persist, delayMs, lastState, onError });
    this.dirty = false;
    this.closed = false;
    this.inFlight = false;
    this.pending = void 0;
    this.timer = null;
    this.error = null;
    this.job = Promise.resolve();
  }
  changed() {
    if (!this.persist || this.closed) return;
    this.dirty = true;
    if (!this.inFlight && this.delayMs === 0) this.flush();
    else this.arm();
  }
  arm() {
    if (!this.persist || this.closed || this.inFlight || this.timer !== null) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flush();
    }, this.delayMs);
  }
  flush(force = false) {
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (!this.persist) return this.lastState;
    if (!this.dirty && !force) return this.lastState;
    const state = this.capture();
    this.lastState = state;
    this.dirty = false;
    if (this.inFlight) this.pending = state;
    else this.write(state);
    return state;
  }
  write(state) {
    let value;
    try {
      value = this.persist(state);
    } catch (e) {
      this.failed(e);
      return;
    }
    if (value && typeof value.then === "function") {
      this.inFlight = true;
      this.job = Promise.resolve(value).then(() => this.finish(true), (e) => {
        this.failed(e);
        this.finish(false);
      });
    } else this.finish(true);
  }
  failed(e) {
    this.error = e;
    this.dirty = true;
    this.onError(e);
  }
  finish(ok) {
    this.inFlight = false;
    if (ok) this.error = null;
    if (this.pending !== void 0) {
      const state = this.pending;
      this.pending = void 0;
      this.write(state);
    } else if (ok && this.dirty && !this.closed) this.arm();
  }
  async wait() {
    while (this.inFlight) await this.job;
    return !this.error;
  }
  close() {
    this.closed = true;
    this.flush();
    return this.wait();
  }
};

var encode = (bytes) => {
  const chunks = [];
  for (let offset = 0; offset < bytes.length; offset += 8192) chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + 8192)));
  return btoa(chunks.join(""));
};
var decode = (value) => {
  const binary = atob(value), bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
};

var NO_PERSIST = (_state) => {
};
var VaultClient = class {
  constructor({ url, token, state, mode, room = "realtime-lab-v2", expectedProtocol = void 0, capabilities = [], beforeUpload = async () => {
  }, retryPreparation = () => false, persistDelayMs = 0, maxBufferedBytes = 32 * 1024 * 1024, maxInboxBytes = 32 * 1024 * 1024, serverId, onIdentity = (_id, _mode) => {
  }, WebSocketImpl = globalThis.WebSocket, onStatus = (_s) => {
  }, onReady = () => {
  }, onPersist = NO_PERSIST }) {
    if (state && !serverId) throw Error("Saved state requires verified server identity");
    Object.assign(this, { url, token, WS: WebSocketImpl, onStatus, onReady, onPersist, mode, serverId, onIdentity, maxBufferedBytes, maxInboxBytes, room, expectedProtocol, capabilities, beforeUpload, retryPreparation });
    this.doc = new Doc();
    if (state) applyUpdate(this.doc, decode(state));
    this.ready = false;
    this.stopped = false;
    this.retry = 0;
    this.requests = /* @__PURE__ */ new Map();
    this.id = 0;
    this.transportBlocked = "";
    this.persistence = new SnapshotScheduler({ capture: () => encode(encodeStateAsUpdate(this.doc)), persist: onPersist === NO_PERSIST ? null : onPersist, delayMs: persistDelayMs, lastState: state || "", onError: (e) => this.onStatus("\u672C\u5730\u5FEB\u7167\u4FDD\u5B58\u5931\u8D25\uFF1A" + String(e?.message || e) + "\uFF1B\u8BF7\u4FDD\u7559\u672C\u5730\u5185\u5BB9\u5E76\u68C0\u67E5\u5B58\u50A8\u3002") });
    this.listener = (u, origin) => {
      this.persistence.changed();
      if (origin !== "remote" && this.ready && !this.metadataBatch) this.send({ type: "update", update: encode(u) });
    };
    this.doc.on("update", this.listener);
  }
  send(m) {
    if (this.transportBlocked || this.ws?.readyState !== 1) return false;
    const text2 = JSON.stringify(m), bytes = m.type === "update" ? text2.length : text2.length * 3;
    if ((this.ws.bufferedAmount || 0) + bytes > this.maxBufferedBytes) {
      this.pauseSend(bytes > this.maxBufferedBytes ? "\u5355\u6B21\u53D1\u9001\u8D85\u51FA\u79EF\u538B\u4FDD\u62A4\u4E0A\u9650" : "\u53D1\u9001\u79EF\u538B\u8D85\u8FC7\u4FDD\u62A4\u4E0A\u9650");
      return false;
    }
    try {
      this.ws.send(text2);
      return true;
    } catch (error) {
      this.pauseSend("\u53D1\u9001\u5931\u8D25\uFF1A" + String(error?.message || error));
      return false;
    }
  }
  pauseSend(reason) {
    this.transportBlocked = reason;
    this.ready = false;
    this.persistence.flush(true);
    clearTimeout(this.timer);
    this.timer = void 0;
    this.onStatus(reason + "\uFF1B\u672C\u5730\u5185\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u540C\u6B65\u5DF2\u6682\u505C\u3002\u7F51\u7EDC\u6062\u590D\u540E\u70B9\u51FB\u8FDE\u63A5\u91CD\u8BD5\uFF1B\u4E0D\u8981\u5220\u9664\u672C\u5730\u72B6\u6001\u3002");
    try {
      this.ws.close(4405, "Send paused; local state retained");
    } catch {
    }
  }
  flushPersist(force = false) {
    return this.persistence.flush(force);
  }
  request(type, params2 = {}) {
    if (!this.ready) return Promise.reject(Error("Not connected"));
    const id2 = String(++this.id);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.requests.delete(id2);
        reject(Error("Request timeout"));
      }, 15e3);
      this.requests.set(id2, { resolve, reject, timer });
      this.send({ type, ...params2, id: id2 });
    });
  }
  connect() {
    if (this.stopped || this.ws?.readyState === 0 || this.ws?.readyState === 1 || this.ws?.readyState === 2) return;
    this.transportBlocked = "";
    this.onStatus("\u8FDE\u63A5\u4E2D");
    const ws = new this.WS(this.url);
    this.ws = ws;
    ws.onopen = () => this.send({ type: "hello", room: this.room, capabilities: this.capabilities, token: this.token, mode: this.mode });
    let inbox = Promise.resolve(), inboxBytes = 0;
    ws.onmessage = (e) => {
      if (this.transportBlocked || this.stopped) return;
      const raw = e.data.toString(), size2 = raw.length * 2;
      if (inboxBytes + size2 > this.maxInboxBytes) {
        this.pauseSend("\u63A5\u6536\u79EF\u538B\u8D85\u8FC7\u4FDD\u62A4\u4E0A\u9650");
        return;
      }
      inboxBytes += size2;
      inbox = inbox.then(async () => {
        if (this.stopped || this.transportBlocked || this.ws !== ws) return;
        try {
          const m = JSON.parse(raw);
          if (m.type === "welcome") {
            if (this.capabilities.some((c) => !m.capabilities?.includes(c))) {
              this.onStatus("\u670D\u52A1\u5668\u7F3A\u5C11\u6240\u9700\u6587\u4EF6\u534F\u8BAE\u80FD\u529B\uFF1B\u5DF2\u963B\u6B62\u4E0A\u4F20");
              this.stopped = true;
              ws.close(4402, "Missing required capability");
              return;
            }
            if (this.expectedProtocol !== void 0 && m.protocol !== this.expectedProtocol) {
              this.onStatus("\u534F\u8BAE\u7248\u672C\u4E0D\u517C\u5BB9\uFF1B\u5DF2\u963B\u6B62\u4E0A\u4F20");
              this.stopped = true;
              ws.close(4402, "Protocol mismatch");
              return;
            }
            if (this.serverId && m.serverId !== this.serverId) {
              this.onStatus("\u5DF2\u963B\u6B62\u8FDE\u63A5\u5230\u4E0D\u540C\u7684\u6D4B\u8BD5\u670D\u52A1\u5668\u8EAB\u4EFD");
              this.stopped = true;
              ws.close(4402, "Server identity mismatch");
              return;
            }
            if (typeof m.serverId !== "string") {
              this.onStatus("\u670D\u52A1\u5668\u7F3A\u5C11\u8EAB\u4EFD\u6807\u8BC6\uFF0C\u8BF7\u4F7F\u7528\u65B0\u7248\u72EC\u7ACB\u670D\u52A1\u5668");
              this.stopped = true;
              ws.close(4402, "Missing server identity");
              return;
            }
            this.serverId = m.serverId;
            this.mode = "join";
            try {
              await this.onIdentity(m.serverId, "join");
            } catch (error) {
              this.onStatus("\u672C\u5730\u4FDD\u5B58\u5931\u8D25\uFF1A" + String(error?.message || error) + "\u3002\u8BF7\u4FDD\u7559\u672C\u5730\u5185\u5BB9\uFF0C\u68C0\u67E5\u53EF\u7528\u7A7A\u95F4\u548C\u5B58\u50A8\u6743\u9650\u540E\uFF0C\u70B9\u51FB\u8FDE\u63A5\u91CD\u8BD5\u3002");
              this.stopped = true;
              ws.close(4404, "Local identity persistence failed");
              return;
            }
            if (this.stopped || this.ws !== ws || ws.readyState !== 1) return;
            applyUpdate(this.doc, decode(m.update), "remote");
            this.serverCapabilities = m.capabilities || [];
            this.metadataVerified = true;
            try {
              await this.beforeUpload();
            } catch (error) {
              if (this.retryPreparation(error)) {
                this.onStatus("\u9644\u4EF6\u7F51\u7EDC\u6682\u4E0D\u53EF\u7528\uFF0C\u4FDD\u7559\u5F85\u4F20\u961F\u5217\u5E76\u81EA\u52A8\u91CD\u8FDE\uFF1A" + String(error?.message || error));
                ws.close(1012, "Retry cached upload");
              } else {
                this.onStatus("\u540C\u6B65\u524D\u9644\u4EF6\u51C6\u5907\u5931\u8D25\uFF0C\u4FDD\u7559\u672C\u5730\u5185\u5BB9\u540E\u91CD\u8BD5\uFF1A" + String(error?.message || error));
                this.stopped = true;
                ws.close(4404, "Pre-upload preparation failed");
              }
              return;
            }
            if (this.stopped || this.ws !== ws || ws.readyState !== 1) return;
            this.ready = true;
            this.retry = 0;
            if (!this.send({ type: "update", update: encode(encodeStateAsUpdate(this.doc, decode(m.vector))) })) return;
            this.onReady();
            this.onStatus("\u5DF2\u8FDE\u63A5");
          } else if (m.type === "update") applyUpdate(this.doc, decode(m.update), "remote");
          else if (m.type === "ack") this.onStatus("\u5DF2\u540C\u6B65");
          else if (m.type === "result" || m.type === "error") {
            const r2 = this.requests.get(m.id);
            if (r2) {
              clearTimeout(r2.timer);
              this.requests.delete(m.id);
              m.type === "result" ? r2.resolve(m.result) : r2.reject(Error(m.message));
            }
            if (m.type === "error") this.onStatus("\u9519\u8BEF\uFF1A" + m.message);
          }
        } catch {
          this.onStatus("\u534F\u8BAE\u9519\u8BEF");
          ws.close();
        }
      }).finally(() => {
        inboxBytes -= size2;
      });
    };
    ws.onerror = () => this.onStatus("\u7F51\u7EDC\u9519\u8BEF");
    ws.onclose = (e) => {
      if (this.ws !== ws) return;
      this.ready = false;
      this.metadataVerified = false;
      for (const r2 of this.requests.values()) {
        clearTimeout(r2.timer);
        r2.reject(Error("Disconnected"));
      }
      this.requests.clear();
      if (this.stopped || this.transportBlocked) return;
      if (e.code === 4401 || e.code === 4400 || e.code === 4403) {
        this.onStatus(e.code === 4401 ? "\u8BA4\u8BC1\u5931\u8D25" : e.code === 4403 ? "\u521B\u5EFA\u5931\u8D25\uFF1A\u670D\u52A1\u5668\u5DF2\u6709\u5185\u5BB9\uFF0C\u8BF7\u9009\u62E9\u52A0\u5165" : "\u66F4\u65B0\u88AB\u62D2\u7EDD\uFF0C\u8BF7\u68C0\u67E5\u5BB9\u91CF\u6216\u8DEF\u5F84");
        return;
      }
      this.onStatus("\u79BB\u7EBF\uFF0C\u7B49\u5F85\u91CD\u8FDE");
      this.timer = setTimeout(() => this.connect(), Math.min(1e4, 500 * 2 ** this.retry++));
    };
  }
  close() {
    const saved = this.persistence.close();
    this.stopped = true;
    clearTimeout(this.timer);
    this.ws?.close();
    for (const r2 of this.requests.values()) {
      clearTimeout(r2.timer);
      r2.reject(Error("Closed"));
    }
    this.requests.clear();
    this.doc.off("update", this.listener);
    return saved;
  }
};

async function boundedBytes(r2, limit) {
  const out = new Uint8Array(limit);
  let n = 0;
  if (!r2.body) throw Error("Missing response body");
  const reader = r2.body.getReader();
  try {
    while (true) {
      const v = await reader.read();
      if (v.done) break;
      if (n + v.value.length > limit) {
        await reader.cancel();
        throw Error("Response frame exceeds limit");
      }
      out.set(v.value, n);
      n += v.value.length;
    }
    return out.subarray(0, n);
  } finally {
    reader.releaseLock();
  }
}
var boundedJson = async (r2) => JSON.parse(new TextDecoder().decode(await boundedBytes(r2, 1024)));
function checkRef(ref) {
  if (!ref || !/^[a-f0-9]{64}$/.test(ref.hash) || !Number.isSafeInteger(ref.size) || ref.size < 0 || ref.size > MAX_BLOB_BYTES) throw Error("Invalid blob reference");
}
function checkStatus(s, size2) {
  if (typeof s.complete !== "boolean" || s.size !== size2 || !Number.isSafeInteger(s.offset) || s.offset < 0 || s.offset > size2 || s.complete && s.offset !== size2 || !s.complete && s.offset % CHUNK_BYTES) throw Error("Invalid upload status");
  return s;
}
var BlobTransfer = class {
  constructor({ url, token, fetchImpl = globalThis.fetch, serverId, onIdentity = async () => {
  }, verifyIdentity, responseIdentity = () => false }) {
    Object.assign(this, { url: url.replace(/\/$/, ""), token, fetch: fetchImpl, serverId, onIdentity, verifyIdentity, responseIdentity });
    this.busy = false;
  }
  async identity(signal) {
    if (!this.serverId && !this.verifyIdentity) throw Error("Verified metadata identity required");
    const expected = this.verifyIdentity ? await this.verifyIdentity(signal) : this.serverId;
    const r2 = await this.fetch(this.url + "/v3/identity", { signal, headers: { Authorization: "Bearer " + this.token } });
    if (!r2.ok) throw Error("Identity request failed (" + r2.status + ")");
    const m = await boundedJson(r2);
    if (m.protocol !== 3 || !m.serverId || m.serverId !== expected || this.serverId && m.serverId !== this.serverId) throw Error("Server identity mismatch before blob transfer");
    if (!this.serverId) {
      await this.onIdentity(m.serverId);
      this.serverId = m.serverId;
    }
  }
  async call(hash, query, options = {}) {
    if (!/^[a-f0-9]{64}$/.test(hash)) throw Error("Invalid blob hash");
    const r2 = await this.fetch(`${this.url}/v3/blobs/${hash}?${new URLSearchParams(query)}`, { ...options, headers: { Authorization: "Bearer " + this.token, ...options.headers } });
    if (!r2.ok) throw Error("Blob request failed (" + r2.status + ")");
    if (this.expectedResponseIdentity && r2.headers.get("X-Realtime-Lab-Server") !== this.expectedResponseIdentity) throw Error("Server identity mismatch in blob response");
    return r2;
  }
  async upload(source, { signal, onProgress = () => {
  } } = {}) {
    if (this.busy) throw Error("Transfer busy");
    this.busy = true;
    try {
      await this.identity(signal);
      if (!Number.isSafeInteger(source.size) || source.size < 0 || source.size > MAX_BLOB_BYTES) throw Error("Blob exceeds 16 MiB or invalid size");
      const hash = await hashSource(source, signal);
      let s = await boundedJson(await this.call(hash, { status: "1", size: source.size }, { signal }));
      checkStatus(s, source.size);
      while (!s.complete) {
        signal?.throwIfAborted();
        const offset = s.offset, n = Math.min(CHUNK_BYTES, source.size - offset), bytes = await source.read(offset, n);
        if (!(bytes instanceof Uint8Array) || bytes.length !== n) throw Error("Source changed");
        s = await boundedJson(await this.call(hash, { size: source.size, offset }, { method: "PUT", body: bytes, signal }));
        checkStatus(s, source.size);
        if (s.offset !== offset + n) throw Error("Invalid upload acknowledgement");
        onProgress(s.offset);
      }
      return { hash, size: source.size };
    } finally {
      this.busy = false;
    }
  }
  async downloadBatch(refs, { signal } = {}) {
    if (this.busy) throw Error("Transfer busy");
    this.busy = true;
    try {
      batchRefs(refs);
      if (!this.responseIdentity() || !this.verifyIdentity) throw Error("Verified batch capability required");
      const expected = await this.verifyIdentity(signal);
      signal?.throwIfAborted();
      const query = refs.map((r3) => r3.hash + ":" + r3.size).join(",");
      const r2 = await this.fetch(this.url + "/v3/batch?refs=" + encodeURIComponent(query), { signal, headers: { Authorization: "Bearer " + this.token } });
      if (!r2.ok) throw Error("Blob request failed (" + r2.status + ")");
      if (!expected || r2.headers.get("X-Realtime-Lab-Server") !== expected) throw Error("Server identity mismatch in batch response");
      return await verifyBatch(refs, await boundedBytes(r2, BATCH_BYTES), signal);
    } finally {
      this.busy = false;
    }
  }
  async download(ref, sink, { signal, onProgress = () => {
  } } = {}) {
    if (this.busy) throw Error("Transfer busy");
    this.busy = true;
    const pending = /* @__PURE__ */ new Map();
    try {
      checkRef(ref);
      const bound = this.responseIdentity() && this.verifyIdentity;
      if (bound) {
        this.expectedResponseIdentity = await this.verifyIdentity(signal);
        if (typeof this.expectedResponseIdentity !== "string" || !this.expectedResponseIdentity) throw Error("Verified metadata identity required");
      } else await this.identity(signal);
      const window2 = bound ? 4 : 2;
      if (!ref.size) {
        const s = checkStatus(await boundedJson(await this.call(ref.hash, { status: "1", size: 0 }, { signal })), 0);
        if (!s.complete) throw Error("Remote blob incomplete");
      }
      let offset = await sink.length();
      if (!Number.isSafeInteger(offset) || offset < 0 || offset > ref.size || offset !== ref.size && offset % CHUNK_BYTES) throw Error("Invalid destination length");
      let next = offset;
      const fill = () => {
        while (pending.size < window2 && next < ref.size) {
          signal?.throwIfAborted();
          const p = next;
          next += CHUNK_BYTES;
          pending.set(p, (async () => {
            try {
              const r2 = await this.call(ref.hash, { offset: p }, { signal }), bytes = await boundedBytes(r2, CHUNK_BYTES);
              if (bytes.length !== Math.min(CHUNK_BYTES, ref.size - p)) throw Error("Short download frame");
              return { bytes };
            } catch (error) {
              return { error };
            }
          })());
        }
      };
      fill();
      while (offset < ref.size) {
        signal?.throwIfAborted();
        const result = await pending.get(offset);
        if (result.error) throw result.error;
        signal?.throwIfAborted();
        await sink.write(offset, result.bytes);
        pending.delete(offset);
        offset += result.bytes.length;
        onProgress(offset);
        fill();
      }
      if (await hashSource({ size: ref.size, read: (p, n) => sink.read(p, n) }, signal) !== ref.hash) throw Error("Downloaded blob hash mismatch; discard partial and retry");
      await sink.commit?.(ref);
      return ref;
    } finally {
      await Promise.all(pending.values());
      this.expectedResponseIdentity = void 0;
      this.busy = false;
    }
  }
};

var VaultClientV3 = class extends VaultClient {
  constructor(options) {
    super({ ...options, retryPreparation: transientTransferFailure, room: "realtime-lab-v3", expectedProtocol: 3, capabilities: [FILE_REFS_CAPABILITY, GENERAL_FILES_CAPABILITY], beforeUpload: async () => {
      await options.beforeUpload?.();
      if (this.pending.length) {
        if (!this.blobCache) throw Error("Pending file cache required");
        for (const p of this.pending) await this.putFile(p.path, this.blobCache.source(p), { version: p.version, base: p.base, preserveDeleted: true, prepareOnly: this.serverCapabilities?.includes(CONFLICT_CAPABILITY) });
      }
    }, maxBufferedBytes: 4 * 1024 * 1024, maxInboxBytes: 8 * 1024 * 1024 });
    this.blobs = new BlobTransfer({ url: options.url.replace(/^ws/, "http"), token: options.token, fetchImpl: options.fetchImpl, responseIdentity: () => this.serverCapabilities?.includes(BLOB_RESPONSE_IDENTITY_CAPABILITY), verifyIdentity: async () => {
      if (!this.ready && !this.metadataVerified || !this.serverId) throw Error("Connect verified V3 metadata before transferring blobs");
      return this.serverId;
    } });
    this.blobCache = options.blobCache;
    this.onPending = options.onPending;
    this.pending = options.pending?.items || [];
    if (options.pending && (options.pending.protocol !== 3 || options.pending.serverId !== this.serverId || !this.serverId)) throw Error("Pending uploads require matching verified server identity");
    if (this.pending.length > 6e3) throw Error("Pending reference limit");
    for (const p of this.pending) this.checkPending(p);
    this.binaryBusy = false;
    this.binaryAbort = new AbortController();
    this.onSyncState = options.onSyncState || (() => {
    });
    this.onOutbox = options.onOutbox;
    this.localSequence = 0;
    this.localOutbox = /* @__PURE__ */ new Map();
    const restored = options.outbox ?? (options.state ? ["*"] : []);
    if (!Array.isArray(restored) || restored.length > 8192 || restored.some((p) => p !== "*" && !supportedFile(p))) throw Error("Invalid local outbox");
    for (const p of restored) this.localOutbox.set(p, ++this.localSequence);
    const status = this.onStatus;
    this.onStatus = (s) => {
      this.syncStatus = s;
      if (/错误|失败|拒绝|阻止|暂停/.test(s)) this.lastError = s;
      status(s);
      this.onSyncState();
    };
    const ready = this.onReady;
    this.onReady = () => {
      ready();
      this.queueConfirmation();
    };
    this.progressListener = (tx) => {
      if (tx.origin === "remote") return;
      const paths = changedPaths(this.doc, tx);
      if (!paths.length) return;
      for (const p of paths) this.localOutbox.set(p, ++this.localSequence);
      this.onSyncState();
      this.queueConfirmation();
    };
    this.doc.on("afterTransaction", this.progressListener);
  }
  // iOS can retain an OPEN WebSocket after its network connection is gone.
  // Keep the Y.Doc, verified identity and pending blobs; replace only transport.
  connect() {
    const previous = this.ws;
    super.connect();
    if (!this.ws || this.ws === previous) return;
    this.connectionStartedAt = Date.now();
    this.terminalCloseCode = void 0;
    const ws = this.ws, closed = ws.onclose;
    ws.onclose = (e) => {
      if (this.ws === ws && [4400, 4401, 4403].includes(e.code)) this.terminalCloseCode = e.code;
      closed?.(e);
    };
  }
  resume() {
    if (this.stopped || this.transportBlocked || this.terminalCloseCode) return false;
    clearTimeout(this.timer);
    this.timer = void 0;
    const old = this.ws;
    this.ws = void 0;
    this.ready = false;
    this.metadataVerified = false;
    for (const r2 of this.requests.values()) {
      clearTimeout(r2.timer);
      r2.reject(Error("Foreground reconnect; local edits retained"));
    }
    this.requests.clear();
    if (old) {
      old.onopen = null;
      old.onmessage = null;
      old.onerror = null;
      old.onclose = null;
      try {
        old.close();
      } catch {
      }
    }
    this.connect();
    return true;
  }
  queueConfirmation() {
    clearTimeout(this.confirmTimer);
    if (this.ready && !this.stopped) this.confirmTimer = setTimeout(() => void this.confirmUploads().catch(() => {
    }), 250);
  }
  async confirmUploads() {
    if (!this.ready || this.stopped || this.transportBlocked || this.metadataBatch) return false;
    if (this.confirmation) return this.confirmation;
    const ws = this.ws, boundary = this.localSequence;
    this.confirmation = (async () => {
      await this.request("barrier");
      if (this.ws !== ws || !this.ready || this.stopped) return false;
      if (this.persistence.persist && (this.localOutbox.size || this.persistence.dirty || this.persistence.inFlight)) {
        this.flushPersist(!!this.localOutbox.size);
        if (!await this.persistence.wait()) throw Error("Local snapshot save failed; outbox retained");
      }
      const cleared = [];
      for (const [p, n] of this.localOutbox) if (n <= boundary) {
        cleared.push([p, n]);
        this.localOutbox.delete(p);
      }
      try {
        if (cleared.length) await this.onOutbox?.([...this.localOutbox.keys()]);
      } catch (e) {
        for (const [p, n] of cleared) if (!this.localOutbox.has(p)) this.localOutbox.set(p, n);
        throw e;
      }
      this.lastConfirmedAt = Date.now();
      this.lastError = "";
      this.onSyncState();
      return true;
    })().catch((e) => {
      this.lastError = String(e.message || e);
      this.onSyncState();
      if (this.ws === ws && !this.stopped && !this.transportBlocked && this.lastError !== "Local snapshot save failed; outbox retained") this.resume();
      return false;
    }).finally(() => {
      this.confirmation = null;
      if (this.localSequence > boundary) this.queueConfirmation();
    });
    return this.confirmation;
  }
  async checkConnection() {
    if (this.stopped || this.transportBlocked || this.terminalCloseCode) return false;
    if (!this.ready) {
      if (!this.ws || Date.now() - (this.connectionStartedAt || 0) >= 3e4) this.resume();
      return false;
    }
    if (this.healthCheck) return this.healthCheck;
    const ws = this.ws;
    const job = this.request("barrier").then(() => {
      if (this.ws !== ws || !this.ready) return false;
      this.queueConfirmation();
      return true;
    }).catch((e) => {
      if (this.ws === ws && !this.stopped && !this.transportBlocked) {
        this.lastError = String(e.message || e);
        this.onSyncState();
        this.resume();
      }
      return false;
    });
    this.healthCheck = job;
    try {
      return await job;
    } finally {
      if (this.healthCheck === job) this.healthCheck = null;
    }
  }
  get pendingPaths() {
    return [...this.localOutbox.keys()];
  }
  async batchFiles(fn) {
    if (this.metadataBatch) throw Error("Metadata batch already active");
    const vector = encodeStateVector(this.doc);
    this.metadataBatch = true;
    try {
      return await fn();
    } finally {
      this.metadataBatch = false;
      if (this.ready && !this.stopped) this.send({ type: "update", update: encode(encodeStateAsUpdate(this.doc, vector)) });
      this.queueConfirmation();
    }
  }
  checkPending(p) {
    if (!p || !p.version || !/^[a-f0-9-]{36}$/.test(p.version) || !supportedFile(p.path) || !/^[a-f0-9]{64}$/.test(p.hash) || !Number.isSafeInteger(p.size) || p.size < 0 || p.size > maxFileSize(p.path)) throw Error("Invalid pending image reference");
  }
  async putFile(path, source, options = {}) {
    if (!supportedFile(path) || source.size > maxFileSize(path)) throw Error("Unsupported file or per-type size limit");
    const base = Object.hasOwn(options, "base") ? options.base : content(this.doc, path), version = options.version || crypto.randomUUID();
    const ref = await this.blobs.upload(source, { signal: this.binaryAbort.signal, ...options });
    if (this.stopped) throw Error("Client closed; cached source retained");
    if (options.prepareOnly) return ref;
    if (this.serverCapabilities?.includes(CONFLICT_CAPABILITY) && !this.ready) throw Error("Disconnected before version publication; cached source retained");
    if (this.ready && this.serverCapabilities?.includes(CONFLICT_CAPABILITY)) {
      await this.request("publish-file", { path, ref, version, base, preserveDeleted: !!options.preserveDeleted });
      return ref;
    }
    this.doc.transact(() => {
      const deleted = options.preserveDeleted && this.doc.getMap("deleted").has(path);
      put(this.doc, path, { kind: fileKind(path), ...ref, version });
      if (deleted) remove(this.doc, path);
    });
    return ref;
  }
  async downloadFile(path, sink, options) {
    const ref = content(this.doc, path);
    if (!ref || ref.kind === "text") throw Error("Versioned file missing");
    return this.blobs.download(ref, sink, { signal: this.binaryAbort.signal, ...options });
  }
  async putImage(path, source, options) {
    if (/\.md$|\.pdf$/i.test(path)) throw Error("Image path required");
    return this.putFile(path, source, options);
  }
  async downloadImage(path, sink, options) {
    return this.downloadFile(path, sink, options);
  }
  async stageImage(path, source, options) {
    if (/\.md$|\.pdf$/i.test(path)) throw Error("Image path required");
    return this.stageFile(path, source, options);
  }
  // Offline staging needs an immutable durable cache plus explicit persisted
  // pending manifest. Only refs enter that manifest; never source byte buffers.
  async stageFile(path, source, options) {
    if (this.binaryBusy) throw Error("Binary operation busy");
    if (!this.serverId || !this.blobCache || !this.onPending) throw Error("Verified identity, durable blob cache and pending persistence required");
    if (!supportedFile(path) || source.size > maxFileSize(path)) throw Error("Unsupported file or per-type size limit");
    if (this.pending.length >= 6e3) throw Error("Pending reference limit");
    this.binaryBusy = true;
    try {
      const ref = await this.blobCache.stage(source, { signal: this.binaryAbort.signal, ...options }), previous = [...this.pending].reverse().find((p) => p.path === path), item = { path, ...ref, version: crypto.randomUUID(), base: previous ? { kind: fileKind(path), hash: previous.hash, size: previous.size, version: previous.version } : options && Object.hasOwn(options, "base") ? options.base : content(this.doc, path) };
      if (previous?.hash === ref.hash && previous?.size === ref.size) return ref;
      const next = [...this.pending, item];
      await this.onPending({ protocol: 3, serverId: this.serverId, items: next });
      this.pending = next;
      this.onSyncState();
      return ref;
    } finally {
      this.binaryBusy = false;
    }
  }
  async flushPending(options) {
    if (this.binaryBusy) throw Error("Binary operation busy");
    if (!this.blobCache || !this.onPending || !this.ready) throw Error("Connect before resuming cached uploads");
    this.binaryBusy = true;
    try {
      while (this.pending.length) {
        const p = this.pending[0];
        await this.putFile(p.path, this.blobCache.source(p), { ...options, version: p.version, base: p.base, preserveDeleted: true });
        await this.request("barrier");
        this.flushPersist(true);
        if (!this.persistence.persist || !await this.persistence.wait()) throw Error("Save metadata snapshot before removing pending reference");
        const next = this.pending.slice(1);
        await this.onPending({ protocol: 3, serverId: this.serverId, items: next });
        this.pending = next;
        this.onSyncState();
      }
    } finally {
      this.binaryBusy = false;
    }
  }
  close() {
    clearTimeout(this.confirmTimer);
    this.doc.off("afterTransaction", this.progressListener);
    this.binaryAbort.abort();
    return super.close();
  }
};

var equal = (a, b) => a?.kind === b?.kind && (a?.kind === "text" ? a.data === b?.data : a?.hash === b?.hash && a?.size === b?.size);
var MAX_IMAGE2 = 5 * 1024 * 1024;
var BACKUP = ".realtime-lab-v3-recovery";
var RealtimeLab = class extends import_obsidian.Plugin {
  performance = new PerformanceCounters();
  settings = { protocol: 3, capability: FILE_REFS_CAPABILITY, url: "ws://127.0.0.1:17241", token: "", state: "", enabled: false };
  client = null;
  status;
  bindings = /* @__PURE__ */ new Map();
  queue = Promise.resolve();
  writing = /* @__PURE__ */ new Set();
  timers = /* @__PURE__ */ new Set();
  saveTimer;
  stopping = false;
  initializing = false;
  syncedOnce = false;
  dirtyFiles = /* @__PURE__ */ new Map();
  fileUploads = coalescedTask((fn) => this.enqueue(fn), () => this.flushLocalFiles(), () => !!this.client && !this.stopping);
  reflection = coalescedTask((fn) => this.enqueue(fn), () => this.reflect(), () => !!this.client?.ready && !this.stopping);
  safetyTimer;
  safetyBusy = false;
  receiveAcks = /* @__PURE__ */ new Set();
  receiptFlush;
  receiptLastSaved = 0;
  recoveryBusy = false;
  recoveryAttempts = 0;
  retryAfter = 0;
  prepareConnection;
  localOperations = 0;
  diagnosticBusy = false;
  diagnosticLastSent = 0;
  diagnosticTimer;
  diagnosticError = "";
  uiUnloaded = false;
  connectionStatus = "\u672A\u8FDE\u63A5";
  operationError = "";
  statusDetail;
  syncPanel;
  fileFailures = /* @__PURE__ */ new Map();
  downloadPaths = /* @__PURE__ */ new Set();
  progressTimer;
  setConnectionStatus(s) {
    if (this.uiUnloaded) return;
    this.connectionStatus = s;
    this.status?.setText("Realtime Lab V3\uFF1A" + s);
    this.statusDetail?.setText(s);
    this.updateProgress();
  }
  badges = /* @__PURE__ */ new Map();
  badgeStyle;
  badgeObserver;
  detailPanels = /* @__PURE__ */ new Set();
  detailModals = /* @__PURE__ */ new Set();
  digestCache;
  currentDigest() {
    const doc2 = this.client?.doc;
    if (!doc2) throw Error("\u672A\u8FDE\u63A5\u8BCA\u65AD\u6587\u6863");
    if (this.digestCache?.doc !== doc2) this.digestCache = { doc: doc2, value: documentDigest(doc2) };
    return this.digestCache.value;
  }
  reviewDigest() {
    this.currentDigest();
    const cached = this.digestCache;
    if (!cached.approval) cached.approval = new Sha256().update(encodeStateAsUpdate(cached.doc)).hex();
    return cached.approval;
  }
  cache;
  legacyConfig = null;
  fingerprints = /* @__PURE__ */ new Map();
  configWrites = Promise.resolve();
  pendingRows() {
    const rows = new Map(queueRows({ metadata: this.client?.pendingPaths || this.settings.outbox || [], files: this.client?.pending || this.settings.pending?.items || [], dirty: [...this.dirtyFiles.keys()], failures: [...this.fileFailures], downloads: [.../* @__PURE__ */ new Set([...this.downloadPaths, ...(this.settings.receivePending?.paths || []).filter((p) => !this.receiveAcks.has(p))])] }).map((r2) => [r2.path, r2]));
    for (const i of this.settings.pathSafety?.items || []) for (const path of operationPaths(i.op)) rows.set(path, { path, state: i.error ? "\u8DEF\u5F84\u64CD\u4F5C\u5F85\u590D\u6838\uFF1A" + i.error : "\u5220\u9664\u6216\u91CD\u547D\u540D\u5F85\u4F20\u64AD/\u786E\u8BA4" });
    for (const path of this.settings.remoteDeleteReview?.paths || []) rows.set(path, { path, state: "\u8FDC\u7AEF\u6279\u91CF\u5220\u9664\u5F85\u786E\u8BA4" });
    return [...rows.values()];
  }
  safeError(error) {
    return String(error || "").replaceAll(this.settings.token || "__no_token__", "[\u4EE4\u724C\u5DF2\u9690\u85CF]").slice(0, 240);
  }
  updateProgress() {
    if (this.uiUnloaded) return;
    window.clearTimeout(this.progressTimer);
    this.progressTimer = window.setTimeout(() => this.renderProgress(), 100);
  }
  summaryStatus() {
    const c = this.client;
    if (!c?.ready) return this.connectionStatus;
    if (this.settings.pathSafety?.items.length) return "\u6709" + this.settings.pathSafety.items.length + "\u9879\u5220\u9664\u6216\u91CD\u547D\u540D\u7B49\u5F85\u786E\u8BA4/\u91CD\u8BD5";
    if (this.settings.remoteDeleteReview) return "\u6709" + this.settings.remoteDeleteReview.paths.length + "\u4E2A\u8FDC\u7AEF\u5220\u9664\u7B49\u5F85\u786E\u8BA4";
    if (this.conflicts.length) return "\u6709" + this.conflicts.length + "\u9879\u51B2\u7A81\u5F85\u5904\u7406\uFF0C\u53CC\u65B9\u7248\u672C\u5DF2\u4FDD\u7559";
    if (this.conflictError) return "\u5DF2\u8FDE\u63A5\uFF0C\u51B2\u7A81\u72B6\u6001\u5C1A\u672A\u786E\u8BA4";
    if (this.fileFailures.size && this.downloadPaths.size && [...this.fileFailures.values()].every(recoverableSyncFailure) && !c.lastError && !this.operationError) return "\u6B63\u5728\u6062\u590D\u540C\u6B65\uFF0C\u5931\u8D25\u9879\u76EE\u9010\u9879\u91CD\u8BD5";
    if (c.lastError || this.fileFailures.size || this.operationError) return "\u5DF2\u8FDE\u63A5\uFF0C\u6709\u5931\u8D25\u9879\u76EE\uFF0C\u5185\u5BB9\u4FDD\u7559";
    if (!this.syncedOnce || this.initializing) return "\u5DF2\u8FDE\u63A5\uFF0C\u6B63\u5728\u51C6\u5907\u6587\u4EF6";
    if (this.reflection.queued || this.downloadPaths.size) return "\u5DF2\u8FDE\u63A5\uFF0C\u6B63\u5728\u63A5\u6536\u6587\u4EF6";
    if (this.pendingRows().length) return "\u5DF2\u8FDE\u63A5\uFF0C\u4ECD\u6709\u5185\u5BB9\u5F85\u4E0A\u4F20\u6216\u786E\u8BA4";
    if (this.receiveAcks.size || this.receiptFlush) return "\u6B63\u5728\u4FDD\u5B58\u63A5\u6536\u8FDB\u5EA6";
    if (!c.lastConfirmedAt) return "\u5DF2\u8FDE\u63A5\uFF0C\u7B49\u5F85\u670D\u52A1\u5668\u786E\u8BA4";
    return "\u5DF2\u63D0\u4EA4\u670D\u52A1\u5668";
  }
  renderProgress() {
    if (this.uiUnloaded) return;
    const headline = this.summaryStatus();
    this.status?.setText("Realtime Lab V3\uFF1A" + headline);
    this.syncBadges();
    this.scheduleDiagnostic();
    for (const e of [...this.syncPanel ? [this.syncPanel] : [], ...this.detailPanels]) this.renderPanel(e, headline);
  }
  renderPanel(e, headline) {
    e.empty();
    const c = this.client, rows = this.pendingRows(), progress = this.progressModel();
    e.createEl("p", { text: progress.available ? "\u6587\u4EF6\u8FDB\u5EA6\uFF1A\u5DF2\u5B8C\u6210 " + progress.completed + " / " + progress.total + " \xB7 \u5269\u4F59 " + progress.remaining + " \xB7 \u5F85\u91CD\u8BD5 " + progress.retry : "\u6587\u4EF6\u8FDB\u5EA6\uFF1A\u6B63\u5728\u6838\u5BF9\uFF0C\u5C1A\u4E0D\u80FD\u786E\u8BA4\u5DF2\u5B8C\u6210\u6570\u91CF" });
    e.createEl("p", { text: "\u5F53\u524D\u63A5\u6536\u5E76\u53D1\uFF1A" + progress.active + "\uFF08\u4E0D\u662F\u5269\u4F59\u6587\u4EF6\u6570\uFF09\uFF1B\u5F85\u91CD\u8BD5\u5305\u542B\u5728\u5269\u4F59\u4E2D\uFF0C\u4E0D\u91CD\u590D\u76F8\u52A0\u3002" });
    e.createEl("p", { text: "\u5F53\u524D\u72B6\u6001\uFF1A" + headline });
    e.createEl("p", { text: "\u81EA\u52A8\u8FDE\u63A5\uFF1A" + (this.settings.enabled ? "\u5DF2\u5F00\u542F" : "\u5DF2\u5173\u95ED\uFF0C\u91CD\u542F\u6216\u66F4\u65B0\u540E\u9700\u624B\u52A8\u8FDE\u63A5") });
    e.createEl("p", { text: "\u670D\u52A1\u5668\u6700\u8FD1\u786E\u8BA4\uFF1A" + (c?.lastConfirmedAt ? new Date(c.lastConfirmedAt).toLocaleTimeString() : "\u672C\u6B21\u8FDE\u63A5\u5C1A\u65E0\u786E\u8BA4") + "\uFF1B\u786E\u8BA4\u4EC5\u4EE3\u8868\u670D\u52A1\u5668\u5DF2\u63A5\u6536\uFF0C\u4E0D\u4EE3\u8868\u5176\u4ED6\u8BBE\u5907\u5DF2\u6536\u5230\u3002" });
    e.createEl("p", { text: "\u5F85\u5904\u7406\u51B2\u7A81\uFF1A" + this.conflicts.length });
    if (this.conflictError) e.createEl("p", { text: "\u51B2\u7A81\u68C0\u67E5\uFF1A" + this.conflictError });
    e.createEl("p", { text: "\u5F85\u5904\u7406\u8DEF\u5F84\uFF1A" + rows.length + "\uFF08\u663E\u793A\u524D50\u9879\uFF09" });
    if ([this.operationError, ...this.fileFailures.values()].some(recoverableSyncFailure)) e.createEl("p", { text: "\u7F51\u7EDC\u6216\u4E34\u65F6\u6587\u4EF6\u7CFB\u7EDF\u6545\u969C\u6062\u590D\u540E\u81EA\u52A8\u8865\u4F20\uFF1B\u8BF7\u4FDD\u6301 Obsidian \u5728\u524D\u53F0\u3002\u91CD\u8BD5\u91C7\u7528\u9000\u907F\u95F4\u9694\uFF0C\u6700\u957F\u7EA660\u79D2\u3002" });
    if (this.operationError) e.createEl("p", { text: "\u672C\u5730\u5904\u7406\u9519\u8BEF\uFF1A" + this.safeError(this.operationError) });
    if (c?.lastError) e.createEl("p", { text: "\u6700\u8FD1\u9519\u8BEF\uFF1A" + this.safeError(c.lastError) });
    for (const row of rows.slice(0, 50)) e.createEl("p", { text: (row.path === "*" ? "\u672C\u5730\u79BB\u7EBF\u5FEB\u7167\u5F85\u6838\u5BF9" : row.path) + " \xB7 " + row.state + (row.error ? " \xB7 " + this.safeError(row.error) : "") });
  }
  async recoverQueue() {
    const c = this.client;
    if (!c || this.stopping || c.stopped || c.transportBlocked || !c.ready || this.initializing || this.recoveryBusy || Date.now() < this.retryAfter) return;
    const errors = [this.operationError, ...this.fileFailures.values()].filter(Boolean);
    if (!errors.length || !errors.every(recoverableSyncFailure)) return;
    this.recoveryBusy = true;
    this.retryAfter = Date.now() + Math.min(6e4, 2e3 * 2 ** Math.min(this.recoveryAttempts++, 5));
    try {
      await this.retryQueue();
      await this.queue;
      if (!this.operationError && !this.fileFailures.size) {
        this.recoveryAttempts = 0;
        this.retryAfter = 0;
      }
    } finally {
      this.recoveryBusy = false;
    }
  }
  async retryQueue() {
    this.operationError = "";
    if (!this.client || this.client.stopped || this.client.transportBlocked) {
      await this.start();
      return;
    }
    const c = this.client;
    if (!c.ready) {
      c.resume();
      return;
    }
    this.enqueue(async () => {
      if (!this.syncedOnce && this.prepareConnection) {
        await this.prepareConnection();
        return;
      }
      await this.flushLocalFiles();
      if (c.pending.length) await c.flushPending();
      await this.flushPathSafety();
      await c.confirmUploads();
      await this.reflect();
      this.updateProgress();
    });
  }
  progressModel() {
    const c = this.client;
    return fileProgress({ known: c ? Object.keys(entries(c.doc)) : [], pending: this.pendingRows().map((r2) => r2.path), failures: [...this.fileFailures.keys()], active: this.downloadPaths.size, ready: !!c?.ready && this.settings.receivePending?.serverId === c.serverId });
  }
  badgeModel() {
    const c = this.client, progress = this.progressModel(), uploads = /* @__PURE__ */ new Set([...c?.pendingPaths || this.settings.outbox || [], ...(c?.pending || this.settings.pending?.items || []).map((p) => p.path), ...this.dirtyFiles.keys()]);
    for (const i of this.settings.pathSafety?.items || []) for (const p of operationPaths(i.op)) uploads.add(p);
    const unknown = uploads.delete("*");
    return badgeState({ progress, retrying: !!c?.ready && this.fileFailures.size > 0 && !this.operationError && !this.conflictError && !c.lastError && !c.transportBlocked && (this.recoveryBusy || this.downloadPaths.size > 0) && [...this.fileFailures.values()].every(recoverableSyncFailure), ready: !!c?.ready, connecting: this.connectionStatus.includes("\u8FDE\u63A5\u4E2D"), preparing: !!c?.ready && (!this.syncedOnce || this.initializing || this.receiveAcks.size > 0 || !!this.receiptFlush), receiving: this.reflection.queued || this.downloadPaths.size > 0, error: !!(this.conflictError || c?.lastError || this.fileFailures.size || this.operationError || c?.transportBlocked || /错误|失败|拒绝|阻止/.test(this.connectionStatus)), confirmed: !!c?.lastConfirmedAt, uploads: uploads.size, downloads: this.downloadPaths.size + (this.settings.remoteDeleteReview?.paths.length || 0), unknown, conflicts: this.conflicts.length, protectedCount: (this.settings.pathSafety?.items.length || 0) + (this.settings.remoteDeleteReview?.paths.length || 0), known: c ? Object.keys(entries(c.doc)).length : 0 });
  }
  clearOrphanBadges() {
    const owned = new Set([...this.badges.values()].map((b) => b.el.parentElement));
    for (const row of document.querySelectorAll?.(".rl-sync-row") || []) if (!owned.has(row)) row.remove();
  }
  syncBadges() {
    if (this.uiUnloaded) return;
    if (!this.app.vault.getName().startsWith("Realtime-Lab-V3-Files-")) return;
    this.clearOrphanBadges();
    const Observer = document.defaultView?.MutationObserver;
    if (!this.badgeObserver && Observer && document.body) {
      this.badgeObserver = new Observer((records) => {
        if (!this.uiUnloaded && records.some((r2) => [...r2.addedNodes].some((n) => n.matches?.(".rl-sync-row")))) this.clearOrphanBadges();
      });
      this.badgeObserver.observe(document.body, { childList: true, subtree: true });
    }
    const mobile = document.body?.classList.contains("is-mobile");
    const active = mobile ? this.app.workspace.getActiveViewOfType?.(import_obsidian.MarkdownView) : null;
    const seen = /* @__PURE__ */ new Set(), model = this.badgeModel(), signature = JSON.stringify(model);
    for (const leaf of this.app.workspace.getLeavesOfType("markdown")) {
      const view = leaf.view;
      if (!(view instanceof import_obsidian.MarkdownView) || !view.file || !supportedFile(view.file.path) || mobile && view !== active) continue;
      seen.add(view);
      let badge = this.badges.get(view);
      if (badge && !badge.el.isConnected) {
        badge.el.parentElement?.remove();
        this.badges.delete(view);
        badge = void 0;
      }
      if (!badge) {
        const row2 = document.createElement("div");
        row2.className = "rl-sync-row";
        const el = document.createElement("div");
        row2.appendChild(el);
        view.contentEl.before(row2);
        el.addEventListener("click", () => this.openSyncDetails());
        el.addClass("rl-sync-badge");
        el.setAttribute("role", "button");
        el.tabIndex = 0;
        el.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            el.click();
          }
        });
        badge = { el, icon: el.createSpan({ cls: "rl-sync-icon" }), label: el.createSpan({ cls: "rl-sync-label" }), counts: el.createSpan({ cls: "rl-sync-counts" }), signature: "" };
        this.badges.set(view, badge);
      }
      const row = badge.el.parentElement;
      if (row && document.body?.classList.contains("is-mobile")) {
        if (row.parentElement !== document.body) document.body.appendChild(row);
        const header = view.containerEl?.querySelector(".view-header"), rect = header?.getBoundingClientRect();
        row.style.position = "fixed";
        row.style.top = rect && rect.height > 0 ? `${Math.ceil(rect.bottom) + 4}px` : "";
        row.style.right = "0";
        row.style.left = "0";
        row.style.visibility = rect && rect.height > 0 ? "visible" : "hidden";
      }
      if (badge.signature !== signature) {
        (0, import_obsidian.setIcon)(badge.icon, model.icon);
        badge.label.setText(model.display);
        badge.counts.setText(model.counts);
        badge.counts.hidden = !model.counts;
        badge.el.dataset.tone = model.tone;
        badge.el.dataset.busy = String(model.busy);
        badge.el.setAttribute("aria-label", model.description);
        badge.el.setAttribute("title", model.description);
        badge.signature = signature;
      }
    }
    for (const [view, badge] of this.badges) if (!seen.has(view)) {
      badge.el.parentElement?.remove();
      this.badges.delete(view);
    }
  }
  openSyncDetails() {
    const m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u540C\u6B65\u72B6\u6001");
    const panel = m.contentEl.createDiv();
    this.detailPanels.add(panel);
    this.detailModals.add(m);
    m.contentEl.createEl("p", { cls: "rl-sync-details-note", text: "\u8FDB\u5EA6\u6309\u552F\u4E00\u6587\u4EF6\u8DEF\u5F84\u7EDF\u8BA1\uFF0C\u5305\u542B\u4E0A\u4F20\u3001\u63A5\u6536\u53CA\u5F85\u786E\u8BA4\uFF1B\u5F85\u91CD\u8BD5\u662F\u5269\u4F59\u4E2D\u7684\u4E00\u90E8\u5206\u3002\u5F53\u524D\u63A5\u6536\u6570\u662F\u5E76\u53D1\u6570\u3002\u5DF2\u5B8C\u6210\u8868\u793A\u672C\u673A\u6587\u4EF6\u5904\u7406\u53CA\u670D\u52A1\u5668\u786E\u8BA4\u961F\u5217\u5DF2\u6E05\u9664\uFF0C\u4E0D\u4EE3\u8868\u5176\u4ED6\u8BBE\u5907\u5DF2\u6536\u5230\u3002\u79BB\u7EBF\u65F6\u6570\u91CF\u4EC5\u4F9B\u53C2\u8003\u3002" });
    new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u5220\u9664\u4E0E\u91CD\u547D\u540D\u4FDD\u62A4").onClick(() => void this.openPathSafety())).addButton((b) => b.setButtonText("\u8BBE\u5907\u8FDC\u7A0B\u8BCA\u65AD").onClick(() => void this.openDeviceDiagnostics())).addButton((b) => b.setButtonText("\u67E5\u770B\u540C\u6B65\u51B2\u7A81").onClick(() => void this.openConflicts())).addButton((b) => b.setButtonText("\u91CD\u8BD5\u5F85\u4F20\u4E0E\u63A5\u6536").onClick(() => void this.retryQueue())).addButton((b) => b.setButtonText("\u5173\u95ED").onClick(() => m.close()));
    m.onClose = () => {
      this.detailPanels.delete(panel);
      this.detailModals.delete(m);
    };
    m.open();
    this.renderProgress();
  }
  scheduleDiagnostic() {
    if (!this.client?.ready || this.uiUnloaded || this.diagnosticTimer !== void 0 || Date.now() - this.diagnosticLastSent < 2e3) return;
    this.diagnosticTimer = window.setTimeout(() => {
      this.diagnosticTimer = void 0;
      void this.reportDiagnostic();
    }, 300);
  }
  async reportDiagnostic() {
    const c = this.client;
    if (this.uiUnloaded || this.diagnosticBusy || !c?.ready || !this.settings.deviceId || !c.serverCapabilities?.includes(DIAGNOSTICS_CAPABILITY)) return;
    this.diagnosticBusy = true;
    try {
      const rows = this.pendingRows(), platform = import_obsidian.Platform?.isIosApp ? "ios" : import_obsidian.Platform?.isAndroidApp ? "android" : import_obsidian.Platform?.isMacOS ? "macos" : import_obsidian.Platform?.isWin ? "windows" : import_obsidian.Platform?.isLinux ? "linux" : "unknown";
      await c.request("device-report", { report: { deviceId: this.settings.deviceId, platform, version: this.manifest?.version || "0.5.0-alpha.22", foreground: !document.hidden, ready: c.ready, busy: !!(this.initializing || !this.syncedOnce || this.safetyBusy || this.reflection.queued || this.fileUploads.queued || this.localOperations || this.writing.size || this.recoveryBusy || this.stopping || this.receiveAcks.size || this.receiptFlush || c.binaryBusy || c.persistence.dirty || c.persistence.inFlight || this.operationError || c.lastError || this.conflictError), queued: rows.length, metadata: c.pendingPaths.length, files: c.pending.length, dirty: this.dirtyFiles.size, receiving: this.downloadPaths.size, failed: this.fileFailures.size, conflicts: this.conflicts.length, confirmedAgeMs: c.lastConfirmedAt ? Math.min(6048e5, Math.max(0, Date.now() - c.lastConfirmedAt)) : null, digest: this.currentDigest(), ...c.serverCapabilities.includes(PERFORMANCE_CAPABILITY) ? { performance: this.performance.snapshot() } : {} } });
      this.diagnosticError = "";
    } catch {
      this.diagnosticError = "\u8FDC\u7A0B\u8BCA\u65AD\u6682\u672A\u4E0A\u62A5\uFF1B\u4E0D\u5F71\u54CD\u539F\u540C\u6B65\u961F\u5217";
    } finally {
      this.diagnosticLastSent = Date.now();
      this.diagnosticBusy = false;
    }
  }
  async openDeviceDiagnostics() {
    const m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u8BBE\u5907\u8FDC\u7A0B\u540C\u6B65\u8BCA\u65AD");
    const panel = m.contentEl.createDiv();
    this.detailModals.add(m);
    m.onClose = () => this.detailModals.delete(m);
    const refresh = async () => {
      panel.empty();
      try {
        const c = this.client;
        if (!c?.ready || !c.serverCapabilities?.includes(DIAGNOSTICS_CAPABILITY)) throw Error("\u8BF7\u8FDE\u63A5\u652F\u6301\u8BBE\u5907\u8BCA\u65AD\u7684\u65B0\u7248\u6D4B\u8BD5\u670D\u52A1\u5668");
        await this.reportDiagnostic();
        const result = await c.request("device-diagnostics");
        panel.createEl("p", { text: "\u4EC5\u663E\u793A\u6700\u8FD1\u4E00\u6B21\u8BBE\u5907\u81EA\u62A5\u72B6\u6001\uFF1B\u8D85\u8FC730\u79D2\u3001\u540E\u53F0\u6216\u79BB\u7EBF\u5747\u4E0D\u5224\u4E3A\u540C\u6B65\u5B8C\u6210\u3002\u670D\u52A1\u5668\u91CD\u542F\u6E05\u7A7A\u8BCA\u65AD\uFF0C\u4E0D\u5F71\u54CD\u7B14\u8BB0\u3002" });
        for (const d of result.devices) panel.createEl("p", { text: d.platform + " \xB7 " + d.deviceId.slice(0, 8) + " \xB7 " + d.version + "\uFF1A" + (d.completeAtReport ? "\u6700\u8FD1\u4E0A\u62A5\u5DF2\u540C\u6B65" : !d.connected ? "\u5DF2\u79BB\u7EBF" : !d.fresh ? "\u4E0A\u62A5\u5DF2\u8FC7\u671F" : !d.foreground ? "\u540E\u53F0\uFF0C\u72B6\u6001\u5F85\u786E\u8BA4" : "\u5C1A\u672A\u786E\u8BA4\u5B8C\u6210") + "\uFF1B\u5F85\u5904\u7406 " + d.queued + "\uFF0C\u63A5\u6536 " + d.receiving + "\uFF0C\u5931\u8D25 " + d.failed + "\uFF0C\u51B2\u7A81 " + d.conflicts + "\uFF1B" + Math.floor(d.ageMs / 1e3) + "\u79D2\u524D\u4E0A\u62A5" });
        for (const d of result.devices) if (d.performance) {
          const p = d.performance;
          panel.createEl("p", { text: d.platform + " \u5206\u9636\u6BB5\u7D2F\u8BA1\uFF1A\u7F51\u7EDC/\u539F\u751F\u8BF7\u6C42\u7B49\u5F85 " + p.network.wallMs + "ms\uFF08" + p.network.count + "\u6B21\uFF09\uFF1B\u7F13\u5B58\u8BFB\u5199 " + p.cache.wallMs + "ms\uFF1B\u6587\u4EF6\u5199\u5165 " + p.vault.wallMs + "ms\uFF1B\u914D\u7F6E\u4FDD\u5B58 " + p.config.wallMs + "ms\u3002\u8BA1\u65F6\u81EA\u672C\u6B21\u63D2\u4EF6\u542F\u52A8\uFF0C\u90E8\u5206\u9636\u6BB5\u91CD\u53E0\uFF0C\u4E0D\u80FD\u76F8\u52A0\u4F5C\u4E3A\u603B\u8017\u65F6\u3002" });
        }
        if (result.unreportedConnections) panel.createEl("p", { text: result.unreportedConnections + "\u4E2A\u8FDE\u63A5\u672A\u4E0A\u62A5\uFF0C\u53EF\u80FD\u662F\u65E7\u7248\u6216\u8F6F\u4EF6\u68C0\u67E5\u7AEF\uFF0C\u4E0D\u80FD\u636E\u6B64\u5224\u5B9A\u5176\u961F\u5217\u3002" });
        if (this.diagnosticError) panel.createEl("p", { text: this.diagnosticError });
      } catch (e) {
        panel.createEl("p", { text: this.safeError(e) });
      }
    };
    new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u5237\u65B0\u8BCA\u65AD").onClick(() => void refresh())).addButton((b) => b.setButtonText("\u5173\u95ED").onClick(() => m.close()));
    m.open();
    await refresh();
  }
  pathBase(path) {
    const pending = [...this.client?.pending || []].reverse().find((p) => p.path === path);
    if (pending) return { kind: fileKind(path), hash: pending.hash, size: pending.size, version: pending.version };
    const live = this.client ? content(this.client.doc, path) : null;
    if (live) return live;
    for (const i of [...this.settings.pathSafety?.items || []].reverse()) for (const e of i.op.entries) if (e.to === path) return e.target || e.base;
    return null;
  }
  pathBlocked(path) {
    return (this.settings.pathSafety?.items || []).some((i) => operationPaths(i.op).includes(path));
  }
  queuePathSafety(kind, entries2, review = false, approved = false) {
    const c = this.client;
    if (!c?.serverId || !entries2.length) return;
    const prior = this.settings.pathSafety?.items || [];
    if (kind === "delete") entries2 = entries2.filter((e) => !prior.some((i) => i.op.kind === "delete" && i.op.entries.some((x) => x.from === e.from)));
    if (!entries2.length) return;
    const item = { op: { id: crypto.randomUUID(), kind, entries: entries2 }, approved, backedUp: false, review, prepared: false, error: "" }, next = { serverId: c.serverId, items: [...prior, item] };
    try {
      validateSafetyQueue(next, c.serverId);
    } catch (e) {
      this.operationError = this.safeError(e);
      new import_obsidian.Notice("\u8DEF\u5F84\u4FDD\u62A4\u65E0\u6CD5\u8BB0\u5F55\u8BA1\u5212\uFF0C\u672A\u5411\u670D\u52A1\u5668\u4F20\u64AD\uFF1A" + this.operationError);
      return;
    }
    this.settings.pathSafety = next;
    for (const e of entries2) {
      this.dirtyFiles.delete(e.from);
      this.fileFailures.delete(e.from);
    }
    this.updateProgress();
    this.enqueue(async () => {
      await this.persistConfig();
      this.schedulePathSafety();
    });
  }
  schedulePathSafety() {
    if (this.uiUnloaded || this.stopping || !this.client?.ready || this.safetyTimer !== void 0) return;
    this.safetyTimer = window.setTimeout(() => {
      this.safetyTimer = void 0;
      this.enqueue(() => this.flushPathSafety());
    }, 750);
  }
  async flushPathSafety() {
    const c = this.client;
    if (this.safetyBusy || !c?.ready || this.stopping) return;
    const queue = this.settings.pathSafety;
    if (!queue?.items.length) return;
    validateSafetyQueue(queue, c.serverId);
    this.safetyBusy = true;
    try {
      const deleted = new Set(queue.items.filter((i) => i.op.kind === "delete").flatMap((i) => i.op.entries.map((e) => e.from))), bulk = bulkDeletion(deleted.size, Object.keys(entries(c.doc)).length);
      if (bulk) {
        for (const i of queue.items) if (i.op.kind === "delete") i.review = true;
        await this.persistConfig();
      }
      while (queue.items.length && this.client === c && c.ready) {
        const item = queue.items[0];
        if (!c.serverCapabilities.includes(PATH_SAFETY_CAPABILITY)) {
          item.error = "\u670D\u52A1\u5668\u5C1A\u4E0D\u652F\u6301\u8DEF\u5F84\u4FDD\u62A4\uFF0C\u672A\u964D\u7EA7\u4E3A\u76F4\u63A5\u5220\u9664";
          await this.persistConfig();
          return;
        }
        if (!item.approved && (item.review || (item.op.kind === "delete" ? bulk : item.op.entries.length >= 5))) {
          item.error = "\u6279\u91CF\u6216\u8303\u56F4\u53D8\u5316\u64CD\u4F5C\u7B49\u5F85\u660E\u786E\u786E\u8BA4";
          await this.persistConfig();
          return;
        }
        try {
          for (const e of item.op.entries) if (this.app.vault.getAbstractFileByPath(e.from)) throw Error("\u539F\u8DEF\u5F84\u53C8\u6709\u672C\u673A\u6587\u4EF6\uFF0C\u672A\u4F20\u64AD\u5220\u9664/\u91CD\u547D\u540D\uFF0C\u8BF7\u68C0\u67E5");
          if (!item.prepared) {
            for (const e of item.op.entries) {
              const local = item.op.kind === "rename" ? this.app.vault.getAbstractFileByPath(e.to) : null;
              let saved = e.base;
              if (local instanceof import_obsidian.TFile) {
                saved = e.base.kind === "text" ? { kind: "text", data: await this.app.vault.read(local) } : await this.read(local);
                await this.backup(e.to, saved);
                e.target = saved.kind === "text" ? saved : { ...saved, version: crypto.randomUUID() };
                if (saved.kind !== "text") await c.blobs.upload(this.cache.source(saved));
              } else {
                if (saved.kind !== "text" && !await this.cache.has(saved)) await c.blobs.download(saved, this.cache.sink(saved));
                await this.backup(e.from, saved);
              }
            }
            item.backedUp = true;
            item.prepared = true;
            await this.persistConfig();
          }
          await c.request("path-operation", { op: item.op });
          if (item.op.kind === "rename") for (const e of item.op.entries) {
            const f = this.app.vault.getAbstractFileByPath(e.to);
            if (!(f instanceof import_obsidian.TFile)) continue;
            const current = e.base.kind === "text" ? { kind: "text", data: await this.app.vault.read(f) } : await this.read(f), published = e.target || e.base;
            if (!equal(current, published)) {
              if (current.kind === "text") {
                const b = new TextEncoder().encode(current.data);
                const ref = await this.cache.stage({ size: b.length, read: async (p, n) => b.subarray(p, p + n) });
                await c.stageFile(e.to, this.cache.source(ref), { base: published });
              } else await c.stageFile(e.to, this.cache.source(current), { base: published });
            }
          }
          queue.items.shift();
          for (const e of item.op.entries) {
            this.dirtyFiles.delete(e.from);
            this.fileFailures.delete(e.from);
            if (e.to) {
              this.dirtyFiles.delete(e.to);
              this.fileFailures.delete(e.to);
            }
          }
          await this.persistConfig();
          const confirmed = await c.confirmUploads();
          if (confirmed && !queue.items.length && !this.fileFailures.size && !this.operationError) this.setConnectionStatus("\u6587\u4EF6\u5DF2\u5C31\u7EEA");
        } catch (e) {
          item.error = this.safeError(e);
          await this.persistConfig();
          return;
        }
      }
    } finally {
      this.safetyBusy = false;
      this.updateProgress();
    }
  }
  async prepareRemoteDeletes() {
    const c = this.client;
    if (!c?.ready) return;
    const paths = [...c.doc.getMap("files")].filter(([p, m]) => (m.deleted || c.doc.getMap("deleted").has(p)) && !this.pathBlocked(p) && this.app.vault.getAbstractFileByPath(p) instanceof import_obsidian.TFile).map(([p]) => p).sort();
    if (!paths.length) {
      if (this.settings.remoteDeleteReview) {
        this.settings.remoteDeleteReview = void 0;
        await this.persistConfig();
      }
      return;
    }
    const signature = this.reviewDigest(), prior = this.settings.remoteDeleteReview;
    if (prior?.signature === signature) return;
    if (bulkDeletion(paths.length, this.app.vault.getFiles().filter((f) => supportedFile(f.path)).length) || prior) {
      this.settings.remoteDeleteReview = { signature, paths, approved: false };
      await this.persistConfig();
      new import_obsidian.Notice("\u68C0\u6D4B\u5230" + paths.length + "\u4E2A\u8FDC\u7AEF\u5220\u9664\uFF0C\u5DF2\u4FDD\u7559\u672C\u673A\u6587\u4EF6\uFF1B\u8BF7\u6253\u5F00\u5220\u9664\u4E0E\u91CD\u547D\u540D\u4FDD\u62A4\u786E\u8BA4\u3002");
    }
  }
  remoteDeleteAllowed(path) {
    const r2 = this.settings.remoteDeleteReview;
    if (!r2) return true;
    return !!r2.approved && r2.signature === this.reviewDigest() && r2.paths.includes(path);
  }
  async approvePathSafety(reviewed) {
    if (this.uiUnloaded || !this.client?.ready) throw Error("\u8BF7\u8FDE\u63A5\u5F53\u524D\u7248\u672C\u5E76\u91CD\u65B0\u5BA1\u6838");
    const q = this.settings.pathSafety;
    if (!q) return;
    const selected = reviewed || q.items.map((i) => ({ id: i.op.id, plan: JSON.stringify(i.op) }));
    for (const r2 of selected) if (!q.items.some((i) => i.op.id === r2.id && JSON.stringify(i.op) === r2.plan)) throw Error("\u8DEF\u5F84\u8BA1\u5212\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u5BA1\u6838");
    for (const i of q.items) if (selected.some((r2) => r2.id === i.op.id)) {
      i.approved = true;
      i.error = "";
    }
    await this.persistConfig();
    await this.flushPathSafety();
    await this.flushLocalFiles();
    await this.reflect();
  }
  async cancelPathSafety(reviewed) {
    const q = this.settings.pathSafety, c = this.client;
    if (this.uiUnloaded || !q || !c?.ready) throw Error("\u8BF7\u5148\u8FDE\u63A5\u5F53\u524D\u7248\u672C\u4EE5\u5B89\u5168\u4FDD\u7559\u53CC\u65B9");
    const selected = reviewed || q.items.map((i) => ({ id: i.op.id, plan: JSON.stringify(i.op) }));
    for (const r2 of selected) if (!q.items.some((i) => i.op.id === r2.id && JSON.stringify(i.op) === r2.plan)) throw Error("\u8DEF\u5F84\u8BA1\u5212\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u5BA1\u6838");
    const items = q.items.filter((i) => selected.some((r2) => r2.id === i.op.id));
    const paths = [...new Set(items.flatMap((i) => operationPaths(i.op)))];
    const newFiles = [];
    for (const path of paths) {
      const f = this.app.vault.getAbstractFileByPath(path);
      if (!(f instanceof import_obsidian.TFile)) continue;
      const local = await this.read(f), remote = content(c.doc, path), known = c.doc.getMap("files").has(path) || c.doc.getMap("deleted").has(path);
      if (known && !equal(local, remote)) {
        await this.backup(path, local);
        const copy2 = "\u6062\u590D\u526F\u672C/\u53D6\u6D88\u8DEF\u5F84\u64CD\u4F5C-" + Date.now() + "-" + crypto.randomUUID().slice(0, 8) + "-" + path.slice(path.lastIndexOf("/") + 1).slice(-180);
        await this.parents(copy2);
        this.writing.add(copy2);
        try {
          if (local.kind === "text") await this.app.vault.create(copy2, local.data);
          else await this.app.vault.createBinary(copy2, await this.cache.materialize(local));
        } finally {
          this.writing.delete(copy2);
        }
        newFiles.push(copy2);
      } else if (!known) newFiles.push(path);
      this.dirtyFiles.delete(path);
    }
    this.settings.pathSafety = { serverId: q.serverId, items: q.items.filter((i) => !selected.some((r2) => r2.id === i.op.id)) };
    await this.persistConfig();
    for (const path of newFiles) {
      const f = this.app.vault.getAbstractFileByPath(path);
      if (f instanceof import_obsidian.TFile) this.dirtyFiles.set(path, f);
    }
    await this.flushLocalFiles();
    await this.reflect();
    this.updateProgress();
  }
  ownPathModal(m) {
    this.detailModals.add(m);
    m.onClose = () => this.detailModals.delete(m);
    return m;
  }
  async openPathSafety() {
    const reviewed = (this.settings.pathSafety?.items || []).map((i) => ({ id: i.op.id, plan: JSON.stringify(i.op) }));
    const m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u5220\u9664\u4E0E\u91CD\u547D\u540D\u4FDD\u62A4");
    this.detailModals.add(m);
    m.onClose = () => this.detailModals.delete(m);
    m.contentEl.createEl("p", { text: "\u672C\u673A\u5220\u9664\u6216\u6539\u540D\u5DF2\u53D1\u751F\uFF0C\u4F20\u64AD\u8BA1\u5212\u5148\u6301\u4E45\u5316\u5E76\u5907\u4EFD\u3002\u6279\u91CF\u64CD\u4F5C\u9700\u786E\u8BA4\uFF1B\u670D\u52A1\u5668\u7248\u672C\u53D8\u5316\u6216\u76EE\u6807\u5DF2\u5B58\u5728\u4F1A\u62D2\u7EDD\u6574\u7EC4\u64CD\u4F5C\uFF0C\u4E0D\u81EA\u52A8\u8986\u76D6\u3002\u6539\u540D\u540E\u7684\u7B14\u8BB0\u94FE\u63A5\u7531 Obsidian \u7684\u201C\u81EA\u52A8\u66F4\u65B0\u5185\u90E8\u94FE\u63A5\u201D\u5904\u7406\uFF0C\u672C\u63D2\u4EF6\u540C\u6B65\u5176\u4FDD\u5B58\u7ED3\u679C\uFF0C\u4E0D\u6279\u91CF\u6539\u5199\u5176\u4ED6\u7B14\u8BB0\u3002" });
    for (const i of this.settings.pathSafety?.items || []) m.contentEl.createEl("pre", { text: i.op.kind + " \xB7 " + i.op.entries.map((e) => e.from + (e.to ? " \u2192 " + e.to : "")).join("\n") + (i.error ? "\n" + i.error : "") });
    if (this.settings.pathSafety?.items.length) new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u5BA1\u6838\u540E\u786E\u8BA4\u4F20\u64AD").onClick(() => {
      m.close();
      const confirm = this.ownPathModal(new import_obsidian.Modal(this.app));
      confirm.titleEl.setText("\u786E\u8BA4\u4F20\u64AD\u5220\u9664\u6216\u91CD\u547D\u540D");
      confirm.contentEl.createEl("p", { text: "\u4EC5\u5BF9\u521A\u624D\u5C55\u793A\u7684\u8BA1\u5212\u8FDB\u884C\u7248\u672C\u68C0\u67E5\u548C\u4F20\u64AD\uFF1B\u7248\u672C\u53D8\u5316\u4ECD\u4F1A\u62D2\u7EDD\u3002\u5F53\u524D\u5185\u5BB9\u5148\u5907\u4EFD\uFF0C\u6279\u91CF\u8DEF\u5F84\u4F1A\u5F71\u54CD\u5176\u4ED6\u6D4B\u8BD5\u8BBE\u5907\u3002" });
      new import_obsidian.Setting(confirm.contentEl).addButton((x) => x.setButtonText("\u786E\u8BA4\u4F20\u64AD").onClick(() => {
        confirm.close();
        this.enqueue(() => this.approvePathSafety(reviewed));
      })).addButton((x) => x.setButtonText("\u53D6\u6D88").onClick(() => confirm.close()));
      confirm.open();
    })).addButton((b) => b.setButtonText("\u53D6\u6D88\u4F20\u64AD\u5E76\u4FDD\u7559\u53CC\u65B9").onClick(() => {
      m.close();
      this.enqueue(() => this.cancelPathSafety(reviewed));
    }));
    const review = this.settings.remoteDeleteReview;
    if (review) {
      m.contentEl.createEl("pre", { text: "\u8FDC\u7AEF\u5220\u9664\u7B49\u5F85\u786E\u8BA4\uFF1A\n" + review.paths.join("\n") });
      new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u5907\u4EFD\u540E\u5E94\u7528\u8FD9\u4E9B\u8FDC\u7AEF\u5220\u9664").onClick(() => {
        m.close();
        const confirm = this.ownPathModal(new import_obsidian.Modal(this.app));
        confirm.titleEl.setText("\u786E\u8BA4\u5E94\u7528\u8FDC\u7AEF\u6279\u91CF\u5220\u9664");
        confirm.contentEl.createEl("p", { text: "\u5148\u4FDD\u5B58\u672C\u673A\u6062\u590D\u526F\u672C\uFF0C\u518D\u79FB\u5165 Obsidian \u56DE\u6536\u7AD9\u3002\u670D\u52A1\u5668\u72B6\u6001\u82E5\u5DF2\u6539\u53D8\uFF0C\u672C\u6B21\u786E\u8BA4\u5931\u6548\u3002" });
        new import_obsidian.Setting(confirm.contentEl).addButton((x) => x.setButtonText("\u786E\u8BA4\u5E94\u7528").onClick(() => {
          confirm.close();
          this.enqueue(async () => {
            if (this.uiUnloaded || this.settings.remoteDeleteReview !== review || this.reviewDigest() !== review.signature) throw Error("\u5220\u9664\u8BA1\u5212\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u5BA1\u6838");
            review.approved = true;
            await this.persistConfig();
            await this.reflect();
          });
        })).addButton((x) => x.setButtonText("\u53D6\u6D88").onClick(() => confirm.close()));
        confirm.open();
      }));
    }
    if (!this.settings.pathSafety?.items.length && !review) m.contentEl.createEl("p", { text: "\u6CA1\u6709\u5F85\u786E\u8BA4\u7684\u8DEF\u5F84\u64CD\u4F5C\u3002" });
    new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u5173\u95ED").onClick(() => m.close()));
    m.open();
  }
  async persistConfig() {
    if (this.legacyConfig) throw Error("\u65E7\u8BBE\u7F6E\u5C1A\u672A\u5907\u4EFD\uFF1B\u62D2\u7EDD\u8986\u76D6");
    const snapshot = structuredClone(this.settings);
    this.configWrites = this.configWrites.catch(() => {
    }).then(() => this.performance.measure("config", () => this.saveData(snapshot)));
    await this.configWrites;
  }
  async onload() {
    if (document.head) {
      this.badgeStyle = document.createElement("style");
      this.badgeStyle.textContent = badgeCSS;
      document.head.appendChild(this.badgeStyle);
    }
    const loaded = await this.loadData();
    if (loaded && (loaded.protocol !== 3 || loaded.capability !== FILE_REFS_CAPABILITY)) this.legacyConfig = loaded;
    else this.settings = { ...this.settings, ...loaded };
    if (!this.legacyConfig && !this.settings.deviceId) {
      this.settings.deviceId = crypto.randomUUID();
      await this.persistConfig();
    }
    this.cache = new ObsidianBlobCache(this.app.vault.adapter, { onStart: () => this.performance.begin("cache") });
    this.status = this.addStatusBarItem();
    this.setConnectionStatus("\u672A\u8FDE\u63A5");
    this.addSettingTab(new Settings(this.app, this));
    this.addCommand({ id: "start", name: "\u8FDE\u63A5\u6574\u4E2A\u72EC\u7ACB\u6D4B\u8BD5\u5E93", callback: () => void this.start() });
    this.addCommand({ id: "path-safety", name: "\u67E5\u770B\u5220\u9664\u4E0E\u91CD\u547D\u540D\u4FDD\u62A4", callback: () => void this.openPathSafety() });
    this.addCommand({ id: "device-diagnostics", name: "\u67E5\u770B\u8BBE\u5907\u8FDC\u7A0B\u540C\u6B65\u8BCA\u65AD", callback: () => void this.openDeviceDiagnostics() });
    this.addCommand({ id: "conflicts", name: "\u67E5\u770B\u4E0E\u5904\u7406\u540C\u6B65\u51B2\u7A81", callback: () => void this.openConflicts() });
    this.addCommand({ id: "history", name: "\u67E5\u770B\u4E0E\u6062\u590D\u5386\u53F2\u7248\u672C", callback: () => void this.history() });
    this.addCommand({ id: "stop", name: "\u65AD\u5F00\u6D4B\u8BD5\u5E93\u540C\u6B65", callback: () => this.stop() });
    for (const event of ["create", "modify", "delete"]) this.registerEvent(this.app.vault.on(event, (f) => {
      if (f instanceof import_obsidian.TFile) this.fingerprints.delete(f.path);
      if (!this.client || !this.syncedOnce || this.initializing) return;
      if (event === "delete") {
        if (this.writing.has(f.path)) return;
        const paths = f instanceof import_obsidian.TFile ? [f.path] : [...this.client.doc.getMap("files").keys()].filter((p) => p.startsWith(f.path + "/"));
        this.queuePathSafety("delete", paths.filter(supportedFile).map((from2) => ({ from: from2, base: this.pathBase(from2) })).filter((e) => e.base));
        return;
      }
      if (!(f instanceof import_obsidian.TFile) || !supportedFile(f.path) || this.writing.has(f.path)) return;
      if (this.dirtyFiles.size >= 6e3 && !this.dirtyFiles.has(f.path)) {
        new import_obsidian.Notice("\u672C\u5730\u5F85\u540C\u6B65\u8DEF\u5F84\u8D85\u8FC76000\uFF0C\u672A\u4E22\u5F03\u539F\u6587\u4EF6\uFF1B\u8BF7\u68C0\u67E5\u5BB9\u91CF\u3002");
        return;
      }
      this.dirtyFiles.set(f.path, f);
      this.updateProgress();
      this.fileUploads.request();
    }));
    this.registerEvent(this.app.vault.on("rename", (f, old) => {
      if (!this.client || !this.syncedOnce || this.initializing || this.writing.has(old) || this.writing.has(f.path)) return;
      const moved = f instanceof import_obsidian.TFile ? [{ file: f, from: old }] : this.app.vault.getFiles().filter((x) => x.path.startsWith(f.path + "/")).map((file) => ({ file, from: old + file.path.slice(f.path.length) }));
      for (const { file, from: from2 } of moved) {
        this.fingerprints.delete(from2);
        this.fingerprints.delete(file.path);
        this.dirtyFiles.delete(from2);
        if (supportedFile(file.path)) this.dirtyFiles.set(file.path, file);
      }
      const plans = moved.filter(({ from: from2 }) => supportedFile(from2)).map(({ file, from: from2 }) => ({ from: from2, to: file.path, base: this.pathBase(from2) })).filter((e) => e.base);
      if (plans.every((e) => supportedFile(e.to))) this.queuePathSafety("rename", plans);
      else {
        this.queuePathSafety("delete", plans.map(({ from: from2, base }) => ({ from: from2, base })), true);
        new import_obsidian.Notice("\u6587\u4EF6\u5DF2\u79FB\u51FA\u540C\u6B65\u8303\u56F4\uFF1B\u8FDC\u7AEF\u5220\u9664\u5DF2\u6682\u505C\uFF0C\u8BF7\u67E5\u770B\u8DEF\u5F84\u4FDD\u62A4\u3002");
      }
    }));
    this.registerEvent(this.app.workspace.on("editor-change", (editor, view) => {
      const c = this.client, p = view.file?.path;
      if (!c || this.stopping || !this.syncedOnce || !p || this.writing.has(p) || !supportedFile(p) || content(c.doc, p)?.kind !== "text") return;
      const data = editor.getValue();
      if (new TextEncoder().encode(data).length > MAX_INLINE_NOTE) return;
      if (c.doc.getText("text:" + p).toString() === data) return;
      try {
        const trial = new Doc();
        try {
          applyUpdate(trial, encodeStateAsUpdate(c.doc));
          patchText(trial, p, data, "editor-fallback");
          validate(trial);
        } finally {
          trial.destroy();
        }
        patchText(c.doc, p, data, "editor-fallback");
      } catch (e) {
        new import_obsidian.Notice("\u7F16\u8F91\u540C\u6B65\u5931\u8D25\uFF0C\u539F\u6587\u4ECD\u4FDD\u7559\u5728\u7F16\u8F91\u5668\uFF1A" + String(e));
      }
    }));
    this.registerEvent(this.app.workspace.on("layout-change", () => {
      this.refresh();
      this.updateProgress();
      if (this.client?.ready) this.reflection.request();
    }));
    this.registerEvent(this.app.workspace.on("active-leaf-change", () => this.updateProgress()));
    this.registerEvent(this.app.workspace.on("file-open", () => this.updateProgress()));
    this.registerDomEvent(window, "resize", () => this.updateProgress());
    this.registerDomEvent(window, "online", () => {
      if (!this.client || this.stopping || this.client.stopped || this.client.transportBlocked) return;
      this.retryAfter = 0;
      if (!this.client.ready) this.client.resume();
      else void this.recoverQueue();
      void this.refreshConflicts();
    });
    this.registerDomEvent(document, "visibilitychange", () => {
      if (!document.hidden) this.client?.resume();
      else void this.flushReceipts().catch(() => this.updateProgress());
      void this.reportDiagnostic();
    });
    this.registerInterval(window.setInterval(() => {
      if (!document.hidden) {
        void this.client?.checkConnection();
        void this.recoverQueue();
        void this.refreshConflicts();
        void this.reportDiagnostic();
        if (this.settings.pathSafety?.items.length) this.schedulePathSafety();
      }
    }, 1e4));
    this.app.workspace.onLayoutReady(() => {
      if (this.settings.enabled) void this.start();
      else this.setConnectionStatus("\u672A\u8FDE\u63A5\uFF08\u81EA\u52A8\u8FDE\u63A5\u5DF2\u5173\u95ED\uFF09");
    });
  }
  enqueue(fn) {
    this.queue = this.queue.then(async () => {
      this.localOperations++;
      try {
        await fn();
      } finally {
        this.localOperations--;
        this.updateProgress();
      }
    }).catch((e) => {
      new import_obsidian.Notice("\u6D4B\u8BD5\u5E93\u540C\u6B65\uFF1A" + String(e.message || e));
      this.operationError = this.safeError(e.message || e);
      this.setConnectionStatus("\u64CD\u4F5C\u5931\u8D25\uFF1A" + this.operationError);
    });
  }
  async flushLocalFiles() {
    for (const p of [...this.dirtyFiles.keys()]) {
      const f = this.dirtyFiles.get(p);
      this.dirtyFiles.delete(p);
      if (!f || !this.client || this.stopping) return;
      if (this.pathBlocked(p)) {
        this.dirtyFiles.set(p, f);
        continue;
      }
      try {
        await this.upload(f);
        this.fileFailures.delete(p);
      } catch (e) {
        this.dirtyFiles.set(p, f);
        this.fileFailures.set(p, this.safeError(e));
        this.setConnectionStatus("\u6709\u6587\u4EF6\u4E0A\u4F20\u5931\u8D25\uFF0C\u5185\u5BB9\u4FDD\u7559\uFF0C\u53EF\u91CD\u8BD5");
      }
    }
    this.updateProgress();
  }
  async allowed() {
    return allowedV3(this.app.vault);
  }
  async initialize() {
    if (!this.app.vault.getName().startsWith("Realtime-Lab-V3-Files-")) {
      new import_obsidian.Notice("\u8BF7\u65B0\u5EFA\u7A7A\u5E93\uFF0C\u540D\u79F0\u4EE5 Realtime-Lab-V3-Files- \u5F00\u5934\uFF1B\u65E7\u5E93\u4E0D\u4F1A\u88AB\u521D\u59CB\u5316\u3002");
      return;
    }
    if (this.liveSync()) {
      new import_obsidian.Notice("\u8BF7\u5173\u95ED\u6D4B\u8BD5\u5E93\u4E2D\u7684 LiveSync");
      return;
    }
    try {
      const plan = await inspectInitialization(this.app.vault);
      if (plan.action === "preview-only") {
        new import_obsidian.Notice("\u6B64\u6D4B\u8BD5\u5E93\u5DF2\u6709\u5185\u5BB9\uFF0C\u4EC5\u663E\u793A\u53EA\u8BFB\u9884\u89C8\uFF1B\u4E0D\u4F1A\u5199\u5165\u6807\u8BB0\u6216\u542F\u52A8\u540C\u6B65\u3002");
        await this.previewInventory(true);
        return;
      }
      await initializeV3(this.app.vault);
      new import_obsidian.Notice("V3 \u72EC\u7ACB\u6D4B\u8BD5\u5E93\u5DF2\u521D\u59CB\u5316");
    } catch (e) {
      new import_obsidian.Notice(String(e));
    }
  }
  liveSync() {
    return this.app.plugins?.enabledPlugins?.has("obsidian-livesync");
  }
  async read(f) {
    const md = /\.md$/i.test(f.path), known = this.client ? content(this.client.doc, f.path) : null;
    const inline = md && known?.kind !== "file" && (known?.kind === "text" || f.path === "\u5B9E\u65F6\u534F\u4F5C\u6D4B\u8BD5.md") && f.stat.size <= MAX_INLINE_NOTE;
    if (inline) return { kind: "text", data: await this.app.vault.read(f) };
    const limit = maxFileSize(f.path);
    if (f.stat.size > limit) throw Error("\u6587\u4EF6\u8D85\u8FC7\u5F53\u524D\u7C7B\u578B\u4E0A\u9650\uFF0C\u672A\u8BFB\u53D6\u6216\u4E0A\u4F20\uFF1A" + f.path);
    const key = f.stat.size + ":" + f.stat.mtime, prior = this.fingerprints.get(f.path);
    if (prior?.key === key) return prior.item;
    const bytes = new Uint8Array(await this.app.vault.readBinary(f));
    if (bytes.length > limit) throw Error("\u6587\u4EF6\u8BFB\u53D6\u671F\u95F4\u8D85\u51FA\u4E0A\u9650\uFF1A" + f.path);
    const ref = await this.cache.stage({ size: bytes.length, read: async (p, n) => bytes.subarray(p, p + n) }), item = { kind: fileKind(f.path), ...ref };
    this.fingerprints.set(f.path, { key, item });
    return item;
  }
  async upload(f) {
    const path = f.path;
    if (this.pathBlocked(path)) return;
    const c = this.client;
    if (!c) return;
    if (/\.md$/i.test(f.path) && [...this.bindings.values()].some((b) => b.path === f.path)) {
      if (f.stat.size <= MAX_INLINE_NOTE) return;
      for (const [cm, b] of this.bindings) if (b.path === f.path) {
        cm.dispatch({ effects: b.c.reconfigure([]) });
        b.undo.destroy();
        this.bindings.delete(cm);
      }
    }
    const item = await this.read(f);
    if (f.path !== path) throw Error("\u6587\u4EF6\u8BFB\u53D6\u671F\u95F4\u53D1\u751F\u91CD\u547D\u540D\uFF0C\u5DF2\u4FDD\u7559\u672C\u5730\u6587\u4EF6");
    const old = content(c.doc, f.path);
    if (equal(old, item)) return;
    if (item.kind !== "text") {
      const source = this.cache.source(item);
      await c.stageFile(f.path, source);
      if (c.ready) await c.flushPending();
      return;
    }
    const trial = new Doc();
    try {
      applyUpdate(trial, encodeStateAsUpdate(c.doc));
      put(trial, f.path, item);
      validate(trial);
    } finally {
      trial.destroy();
    }
    put(c.doc, f.path, item, "disk");
    this.refresh();
  }
  async backup(p, c) {
    const name = (0, import_obsidian.normalizePath)(BACKUP + "/" + Date.now() + "-" + Math.random().toString(36).slice(2, 8) + "-" + p.replaceAll("/", "_"));
    if (!await this.app.vault.adapter.exists(BACKUP)) await this.app.vault.adapter.mkdir(BACKUP);
    const list = await this.app.vault.adapter.list(BACKUP);
    let used = 0;
    for (const f of list.files) used += (await this.app.vault.adapter.stat(f))?.size || 0;
    const size2 = c.kind === "text" ? new TextEncoder().encode(c.data).length : c.size;
    if (list.files.length >= MAX_DISK_OBJECTS || used + size2 > MAX_DISK_BYTES) throw Error("\u672C\u5730\u6062\u590D\u526F\u672C\u8FBE\u5230512 MiB/8192\u9879\u4E0A\u9650\uFF1B\u4FDD\u7559\u5F53\u524D\u6587\u4EF6\uFF0C\u672A\u8986\u76D6\uFF0C\u8BF7\u5148\u5BFC\u51FA\u6062\u590D\u526F\u672C\u3002");
    if (c.kind === "text") await this.app.vault.adapter.write(name, c.data);
    else await this.app.vault.adapter.writeBinary(name, await this.cache.materialize(c));
  }
  async backupRejectedState() {
    if (!this.legacyConfig || !await this.allowed()) return;
    const p = BACKUP + "/rejected-old-settings-" + Date.now() + ".json";
    if (!await this.app.vault.adapter.exists(BACKUP)) await this.app.vault.adapter.mkdir(BACKUP);
    await this.app.vault.adapter.write(p, JSON.stringify(this.legacyConfig));
    const legacy = this.legacyConfig;
    this.legacyConfig = null;
    try {
      await this.persistConfig();
    } catch (e) {
      this.legacyConfig = legacy;
      throw e;
    }
    new import_obsidian.Notice("\u65E7\u8BBE\u7F6E\u5DF2\u5907\u4EFD\u5230\u672C\u6D4B\u8BD5\u5E93\u9690\u85CF\u6062\u590D\u76EE\u5F55\uFF1B\u672A\u5BFC\u5165 V3\u3002");
  }
  async resolveMissing(paths) {
    return new Promise((resolve) => {
      const m = new import_obsidian.Modal(this.app);
      let decided = false;
      const done = (v) => {
        decided = true;
        resolve(v);
        m.close();
      };
      m.titleEl.setText("\u68C0\u6D4B\u5230\u505C\u7528\u671F\u95F4\u7F3A\u5931\u7684\u6D4B\u8BD5\u6587\u4EF6");
      m.contentEl.createEl("p", { text: "\u672C\u5730\u540C\u6B65\u5FEB\u7167\u8BB0\u5F55\u4E86\u4EE5\u4E0B\u6587\u4EF6\uFF0C\u4F46\u78C1\u76D8\u4E0A\u5DF2\u4E0D\u5B58\u5728\u3002\u53EF\u80FD\u662F\u624B\u52A8\u5220\u9664\uFF0C\u4E5F\u53EF\u80FD\u662F\u4E0A\u6B21\u5199\u5165\u672A\u5B8C\u6210\u3002\u8BF7\u9009\u62E9\u672C\u6B21\u65B9\u5411\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u731C\u6D4B\u5220\u9664\u610F\u56FE\u3002" });
      m.contentEl.createEl("pre", { text: paths.join("\n") });
      new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u4ECE\u670D\u52A1\u5668\u6062\u590D\u7F3A\u5931\u6587\u4EF6").onClick(() => done("restore"))).addButton((b) => b.setButtonText("\u786E\u8BA4\u5220\u9664\u5E76\u540C\u6B65\u5230\u5176\u4ED6\u6D4B\u8BD5\u8BBE\u5907").onClick(() => done("delete"))).addButton((b) => b.setButtonText("\u53D6\u6D88\u8FDE\u63A5").onClick(() => done("cancel")));
      m.onClose = () => {
        if (!decided) resolve("cancel");
      };
      m.open();
    });
  }
  async start() {
    if (this.legacyConfig) {
      new import_obsidian.Notice("\u62D2\u7EDD\u8BFB\u53D6\u65E7\u534F\u8BAE\u8BBE\u7F6E\u3002\u8BF7\u5728\u65B0 V3 \u6D4B\u8BD5\u5E93\u5907\u4EFD\u5E76\u6E05\u7A7A\u8BEF\u7F6E\u65E7\u72B6\u6001\u3002");
      return;
    }
    if (await this.stop() === false) {
      new import_obsidian.Notice("\u672C\u5730\u5FEB\u7167\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u4FDD\u7559\u5185\u5BB9\u5E76\u68C0\u67E5\u5B58\u50A8\u540E\u91CD\u8BD5\u3002");
      return;
    }
    await this.queue;
    if (!await this.allowed() || this.liveSync()) {
      new import_obsidian.Notice("\u4EC5\u652F\u6301\u5DF2\u521D\u59CB\u5316\u4E14\u672A\u5F00\u542F LiveSync \u7684 Realtime-Lab-V3-Files- \u6D4B\u8BD5\u5E93");
      return;
    }
    if (!/^wss?:\/\//.test(this.settings.url) || this.settings.token.length < 32) {
      new import_obsidian.Notice("\u8BF7\u914D\u7F6E V3 \u670D\u52A1\u5668\u53CA\u4EE4\u724C");
      return;
    }
    try {
      assertStateOrigin(this.settings);
      validateSafetyQueue(this.settings.pathSafety, this.settings.serverId);
      if (this.settings.pending?.items?.length && canonicalEndpoint(this.settings.url) !== canonicalEndpoint(this.settings.stateOrigin || "")) throw Error("\u5F85\u4E0A\u4F20\u9644\u4EF6\u7ED1\u5B9A\u65E7\u670D\u52A1\u5668\u5730\u5740\uFF1B\u62D2\u7EDD\u8DE8\u5730\u5740\u53D1\u9001");
    } catch (e) {
      new import_obsidian.Notice(String(e));
      return;
    }
    const activeOrigin = canonicalEndpoint(this.settings.url);
    this.operationError = "";
    this.stopping = false;
    this.syncedOnce = false;
    const hadState = !!this.settings.state;
    let first = true;
    const c = new VaultClientV3({ url: this.settings.url, token: this.settings.token, fetchImpl: requestFetch(import_obsidian.requestUrl, void 0, () => this.performance.begin("network")), mode: this.settings.mode, serverId: this.settings.serverId, blobCache: this.cache, pending: this.settings.pending, outbox: this.settings.outbox, onSyncState: () => this.updateProgress(), onOutbox: async (outbox) => {
      this.settings.outbox = outbox;
      await this.persistConfig();
    }, onPending: async (pending) => {
      this.settings.pending = pending;
      await this.persistConfig();
    }, onIdentity: async (id2) => {
      this.settings.serverId = id2;
      this.settings.mode = "join";
      this.settings.stateOrigin = activeOrigin;
      await this.persistConfig();
    }, state: this.settings.state || void 0, onStatus: (s) => this.setConnectionStatus((s === "\u5DF2\u8FDE\u63A5" || s === "\u5DF2\u540C\u6B65") && (!this.syncedOnce || this.initializing) ? "\u5DF2\u9274\u6743\uFF0C\u6B63\u5728\u51C6\u5907\u6D4B\u8BD5\u6587\u4EF6" : s), persistDelayMs: 200, onPersist: async (s) => {
      this.settings.state = s;
      this.settings.outbox = c.pendingPaths;
      this.settings.stateOrigin = activeOrigin;
      await this.persistConfig();
    }, onReady: () => {
      this.enqueue(this.prepareConnection);
    } });
    this.prepareConnection = async () => {
      if (this.client !== c) return;
      this.initializing = true;
      try {
        await this.flushLocalFiles();
        if (c.pending.length) await c.flushPending();
        await this.flushPathSafety();
        if (first) {
          new import_obsidian.Notice("\u6587\u4EF6\u6A21\u5F0F\uFF1A\u5B9E\u65F6\u534F\u4F5C\u6D4B\u8BD5.md\uFF08\u226416 KiB\uFF09\u9010\u5B57\u534F\u4F5C\uFF1B\u5176\u4F59\u65B0 Markdown \u6574\u6587\u4EF6\u7248\u672C\u540C\u6B65\uFF0C\u51B2\u7A81\u53CC\u65B9\u4FDD\u7559\u5386\u53F2\u3002");
          const remote = entries(c.doc);
          await c.batchFiles(async () => {
            for (const f of this.app.vault.getFiles().filter((f2) => supportedFile(f2.path))) {
              if (this.pathBlocked(f.path)) continue;
              const local = await this.read(f), r2 = remote[f.path];
              const meta = c.doc.getMap("files").get(f.path);
              if (r2) {
                if (!equal(local, r2)) await this.backup(f.path, local);
              } else if (meta?.deleted || c.doc.getMap("deleted").has(f.path)) {
                await this.backup(f.path, local);
              } else if (!hadState || !meta) await this.upload(f);
            }
          });
          first = false;
        }
        this.syncedOnce = true;
        await this.refreshConflicts();
        await this.reflect();
        this.refresh();
        const confirmed = await c.confirmUploads();
        if (c.ready && !this.stopping) {
          this.setConnectionStatus(confirmed && !this.pendingRows().length ? "\u6587\u4EF6\u5DF2\u5C31\u7EEA" : "\u5DF2\u8FDE\u63A5\uFF0C\u4ECD\u6709\u5185\u5BB9\u5F85\u786E\u8BA4");
          if (confirmed && !this.fileFailures.size && !this.pendingRows().length) {
            if (recoverableSyncFailure(this.operationError)) this.operationError = "";
            new import_obsidian.Notice("\u6D4B\u8BD5\u6587\u4EF6\u5DF2\u5C31\u7EEA\uFF0C\u53EF\u4EE5\u5F00\u59CB\u7F16\u8F91\u540C\u6B65");
          }
        }
      } finally {
        this.initializing = false;
      }
    };
    this.client = c;
    c.doc.on("update", (_u, origin) => {
      this.digestCache = void 0;
      if (origin === "remote" && c.ready) {
        this.scheduleConflicts();
        this.reflection.request();
        this.updateProgress();
      }
    });
    if (hadState) {
      const missing = [.../* @__PURE__ */ new Set([...Object.keys(entries(c.doc)), ...c.pending.map((p) => p.path)])].filter((p) => !this.app.vault.getAbstractFileByPath(p) && !this.pathBlocked(p) && !(this.settings.receivePending?.serverId === c.serverId && this.settings.receivePending?.paths.includes(p)));
      if (missing.length) {
        const choice = await this.resolveMissing(missing);
        if (choice === "cancel") {
          this.stop();
          return;
        }
        if (choice === "delete") this.queuePathSafety("delete", missing.map((from2) => ({ from: from2, base: this.pathBase(from2) })).filter((e) => e.base), false, true);
      }
      for (const f of this.app.vault.getFiles().filter((f2) => supportedFile(f2.path))) {
        if (this.pathBlocked(f.path)) continue;
        const local = await this.read(f), known = content(c.doc, f.path), meta = c.doc.getMap("files").get(f.path);
        if (meta?.deleted || c.doc.getMap("deleted").has(f.path)) {
          await this.backup(f.path, local);
          continue;
        }
        if (known && !equal(known, local)) {
          await this.backup(f.path, local);
          if (local.kind === "text") patchText(c.doc, f.path, local.data, "disk-before-connect");
          else await c.stageFile(f.path, this.cache.source(local));
        } else if (!known) await this.upload(f);
      }
    }
    c.connect();
  }
  async reflect() {
    const c = this.client;
    if (!c?.ready || this.stopping) return;
    const files = c.doc.getMap("files");
    await this.checkpointReceives();
    await this.prepareRemoteDeletes();
    const pipeline = c.serverCapabilities?.includes(SMALL_BATCH_CAPABILITY) ? new SmallBlobPipeline(Object.values(entries(c.doc)).filter((r2) => r2.kind !== "text" && r2.size <= 32768), async (refs) => {
      const missing = [];
      for (const r2 of refs) if (!await this.cache.has(r2)) missing.push(r2);
      return missing.length ? c.blobs.downloadBatch(missing, { signal: c.binaryAbort.signal }) : /* @__PURE__ */ new Map();
    }, { canRun: () => c.ready && !this.stopping && this.client === c }) : null;
    try {
      let transportFailures = 0;
      for (const [p, m] of [...files].sort((a, b) => Number(!!(a[1].deleted || c.doc.getMap("deleted").has(a[0]))) - Number(!!(b[1].deleted || c.doc.getMap("deleted").has(b[0]))))) {
        if (this.stopping || this.client !== c) return;
        if (!c.ready) break;
        if (!supportedFile(p) || this.pathBlocked(p) || this.dirtyFiles.has(p) || c.pending.some((x) => x.path === p)) continue;
        try {
          const f = this.app.vault.getAbstractFileByPath(p);
          if (m.deleted || c.doc.getMap("deleted").has(p)) {
            if (f instanceof import_obsidian.TFile) {
              if (this.fileFailures.size || this.downloadPaths.size || !this.remoteDeleteAllowed(p)) continue;
              const saved = await this.read(f);
              await this.backup(p, saved);
              if (content(c.doc, p) || this.dirtyFiles.has(p) || !equal(await this.read(f), saved) || !this.remoteDeleteAllowed(p)) continue;
              this.writing.add(p);
              try {
                await this.app.vault.trash(f, false);
              } finally {
                this.writing.delete(p);
              }
            }
            continue;
          }
          const item = content(c.doc, p);
          if (!item) continue;
          if (item.kind !== "text") {
            for (const [cm, b] of this.bindings) if (b.path === p) {
              cm.dispatch({ effects: b.c.reconfigure([]) });
              b.undo.destroy();
              this.bindings.delete(cm);
            }
          }
          const bound = [...this.bindings.values()].some((b) => b.path === p);
          if (bound && item.kind === "text") continue;
          if (f instanceof import_obsidian.TFile) {
            const old = await this.read(f);
            if (equal(old, item)) {
              await this.received(p);
              this.fileFailures.delete(p);
              transportFailures = 0;
              continue;
            }
            await this.backup(p, old);
          }
          await this.parents(p);
          this.writing.add(p);
          try {
            if (item.kind === "text") {
              if (f instanceof import_obsidian.TFile) await this.performance.measure("vault", () => this.app.vault.modify(f, item.data));
              else await this.performance.measure("vault", () => this.app.vault.create(p, item.data));
            } else {
              if (!await this.cache.has(item)) {
                this.downloadPaths.add(p);
                this.updateProgress();
                try {
                  const small = pipeline && item.size <= 32768 ? await pipeline.take(item) : null;
                  if (small) {
                    const sink = this.cache.sink(item);
                    const offset = await sink.length();
                    if (offset === 0 && item.size) await sink.write(0, small);
                    else if (offset !== item.size) throw Error("Invalid small cache offset");
                    await sink.commit();
                  } else {
                    await pipeline?.idle();
                    await c.blobs.download(item, this.cache.sink(item));
                  }
                  this.fileFailures.delete(p);
                } catch (e) {
                  this.fileFailures.set(p, this.safeError(e));
                  throw e;
                } finally {
                  this.downloadPaths.delete(p);
                  this.updateProgress();
                }
              }
              if (this.dirtyFiles.has(p) || content(c.doc, p)?.hash !== item.hash) {
                this.reflection.request();
                continue;
              }
              const bytes = await this.cache.materialize(item);
              if (/\.md$/i.test(p)) {
                const text2 = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
                if (f instanceof import_obsidian.TFile) await this.performance.measure("vault", () => this.app.vault.modify(f, text2));
                else await this.performance.measure("vault", () => this.app.vault.create(p, text2));
              } else if (f instanceof import_obsidian.TFile) await this.performance.measure("vault", () => this.app.vault.modifyBinary(f, bytes));
              else await this.performance.measure("vault", () => this.app.vault.createBinary(p, bytes));
            }
          } finally {
            this.writing.delete(p);
          }
          if (item.kind !== "text") {
            const written = this.app.vault.getAbstractFileByPath(p);
            if (written instanceof import_obsidian.TFile) this.fingerprints.set(p, { key: written.stat.size + ":" + written.stat.mtime, item });
          }
          await this.received(p);
          this.fileFailures.delete(p);
          transportFailures = 0;
        } catch (e) {
          this.fileFailures.set(p, this.safeError(c.ready ? e : "Disconnected during receive: " + this.safeError(e)));
          this.updateProgress();
          if (!c.ready) break;
          if (transientFilesystemFailure(e)) {
            this.cache.invalidateQuota();
            break;
          }
          if (transientTransferFailure(e) && ++transportFailures >= 3) break;
        }
      }
      if (this.settings.remoteDeleteReview?.approved && this.settings.remoteDeleteReview.paths.every((p) => !this.app.vault.getAbstractFileByPath(p))) {
        this.settings.remoteDeleteReview = void 0;
        await this.persistConfig();
      }
      await this.flushReceipts();
      this.refresh();
      this.updateProgress();
    } finally {
      await pipeline?.close();
    }
  }
  // Record receive intent before any file mutation. Only these never-present
  // paths may resume without interpreting a genuine local deletion as a download.
  async checkpointReceives() {
    const c = this.client;
    if (!c?.serverId) return;
    const prior = this.settings.receivePending;
    if (prior && prior.serverId !== c.serverId) throw Error("\u63A5\u6536\u8BA1\u5212\u7ED1\u5B9A\u5176\u4ED6\u670D\u52A1\u5668\uFF0C\u672A\u5E94\u7528");
    if (prior && (!Array.isArray(prior.paths) || prior.paths.length > 6e3 || prior.paths.some((p) => !supportedFile(p)))) throw Error("Invalid receive checkpoint");
    const paths = new Set((prior?.paths || []).filter((p) => content(c.doc, p)));
    for (const p of Object.keys(entries(c.doc))) if (!this.app.vault.getAbstractFileByPath(p) && !this.pathBlocked(p) && !c.pending.some((x) => x.path === p)) paths.add(p);
    if (paths.size !== prior?.paths.length || prior?.paths.some((p) => !paths.has(p))) {
      this.settings.receivePending = { serverId: c.serverId, paths: [...paths] };
      await this.persistConfig();
    }
  }
  async received(path) {
    const plan = this.settings.receivePending;
    if (plan?.serverId !== this.client?.serverId || !plan?.paths.includes(path)) return;
    this.receiveAcks.add(path);
    if (this.receiveAcks.size >= 16 || Date.now() - this.receiptLastSaved >= 1e3) await this.flushReceipts();
  }
  async flushReceipts() {
    if (this.receiptFlush) return this.receiptFlush;
    const plan = this.settings.receivePending;
    if (!plan || !this.receiveAcks.size) return;
    const paths = plan.paths.filter((p) => this.receiveAcks.has(p));
    if (!paths.length) {
      this.receiveAcks.clear();
      return;
    }
    const job = (async () => {
      this.settings.receivePending = { serverId: plan.serverId, paths: plan.paths.filter((p) => !paths.includes(p)) };
      try {
        await this.persistConfig();
        for (const p of paths) this.receiveAcks.delete(p);
        this.receiptLastSaved = Date.now();
      } catch (e) {
        const current = this.settings.receivePending;
        if (current?.serverId === plan.serverId) this.settings.receivePending = { serverId: plan.serverId, paths: [.../* @__PURE__ */ new Set([...current.paths, ...paths])] };
        this.operationError = this.safeError(e);
        throw e;
      }
    })();
    this.receiptFlush = job;
    try {
      await job;
    } finally {
      if (this.receiptFlush === job) this.receiptFlush = void 0;
    }
  }
  async parents(p) {
    const parts = p.split("/");
    parts.pop();
    let cur = "";
    for (const part of parts) {
      cur = cur ? cur + "/" + part : part;
      if (!this.app.vault.getAbstractFileByPath(cur)) await this.performance.measure("vault", () => this.app.vault.createFolder(cur));
    }
  }
  refresh() {
    const c = this.client;
    if (!c?.ready || this.stopping) return;
    const seen = /* @__PURE__ */ new Set();
    for (const leaf of this.app.workspace.getLeavesOfType("markdown")) {
      const view = leaf.view;
      if (!(view instanceof import_obsidian.MarkdownView)) continue;
      const cm = view.editor.cm, p = view.file?.path;
      if (!cm || !p || !supportedFile(p) || content(c.doc, p)?.kind !== "text") continue;
      seen.add(cm);
      const prior = this.bindings.get(cm);
      if (prior?.path === p) continue;
      if (prior) {
        cm.dispatch({ effects: prior.c.reconfigure([]) });
        prior.undo.destroy();
      }
      const text2 = c.doc.getText("text:" + p), compartment = new import_state.Compartment(), undo2 = new UndoManager(text2);
      cm.dispatch({ changes: { from: 0, to: cm.state.doc.length, insert: text2.toString() }, effects: import_state.StateEffect.appendConfig.of(compartment.of(yCollab(text2, null, { undoManager: undo2 }))) });
      this.bindings.set(cm, { c: compartment, path: p, undo: undo2 });
    }
    for (const [cm, b] of this.bindings) if (!seen.has(cm)) {
      try {
        cm.dispatch({ effects: b.c.reconfigure([]) });
      } catch {
      }
      b.undo.destroy();
      this.bindings.delete(cm);
    }
  }
  async setupConnection() {
    if (!await this.allowed()) {
      new import_obsidian.Notice("\u8BF7\u5148\u521D\u59CB\u5316\u4E00\u4E2A\u65B0\u7684\u7A7A V3 \u6D4B\u8BD5\u5E93");
      return;
    }
    const modal = new import_obsidian.Modal(this.app);
    modal.titleEl.setText("\u521B\u5EFA\u6216\u52A0\u5165\u72EC\u7ACB\u540C\u6B65\u5E93");
    let url = this.settings.url, token = this.settings.token, autoConnect = this.settings.serverId ? this.settings.enabled : true;
    modal.contentEl.createEl("p", { text: "\u521B\u5EFA\uFF1A\u4EC5\u5EFA\u7ACB\u7A7A\u540C\u6B65\u7A7A\u95F4\uFF0C\u670D\u52A1\u5668\u5FC5\u987B\u4E3A\u7A7A\uFF1B\u52A0\u5165\uFF1A\u4ECE\u5DF2\u6709\u670D\u52A1\u5668\u63A5\u6536\u5185\u5BB9\u3002\u9996\u6B21\u64CD\u4F5C\u8981\u6C42\u672C\u5730\u7A7A\u5E93\u3002\u65E7\u72B6\u6001\u4E0D\u8DE8\u670D\u52A1\u5668\u590D\u5236\uFF0C\u539F\u5E93\u548C\u5FEB\u7167\u59CB\u7EC8\u4FDD\u7559\u3002\u6B64\u5411\u5BFC\u4E0D\u4F1A\u521B\u5EFA\u670D\u52A1\u5668\u6216\u751F\u6210\u51ED\u636E\u3002\u81EA\u52A8\u8FDE\u63A5\u53EF\u5728\u4E0B\u65B9\u9009\u62E9\uFF1B\u5DF2\u6709\u5185\u5BB9\u548C\u72B6\u6001\u4E0D\u4F1A\u91CD\u7F6E\u3002" });
    new import_obsidian.Setting(modal.contentEl).setName("\u6D4B\u8BD5\u670D\u52A1\u5668\u5730\u5740").addText((t) => t.setValue(url).onChange((v) => url = v));
    new import_obsidian.Setting(modal.contentEl).setName("\u6D4B\u8BD5\u8BBF\u95EE\u4EE4\u724C").addText((t) => {
      t.inputEl.type = "password";
      t.setValue(token).onChange((v) => token = v);
    });
    new import_obsidian.Setting(modal.contentEl).setName("\u52A0\u5165\u540E\u6253\u5F00\u6D4B\u8BD5\u5E93\u81EA\u52A8\u8FDE\u63A5").addToggle((t) => t.setValue(autoConnect).onChange((v) => autoConnect = v));
    const use = async (mode) => {
      try {
        const files = this.app.vault.getFiles().filter((f) => f.path !== "realtime-lab-v3-files.json" && !f.path.startsWith("."));
        if (await this.stop() === false) throw Error("\u672C\u5730\u4FDD\u5B58\u5931\u8D25\uFF0C\u672A\u5207\u6362\u8FDE\u63A5");
        await this.queue;
        const next = planConnection(this.settings, { url, token, mode }, files);
        this.settings = { ...next, protocol: 3, capability: FILE_REFS_CAPABILITY, enabled: autoConnect };
        await this.persistConfig();
        modal.close();
        await this.start();
      } catch (e) {
        new import_obsidian.Notice(String(e));
      }
    };
    new import_obsidian.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u521B\u5EFA\u7A7A\u540C\u6B65\u5E93").onClick(() => void use("create"))).addButton((b) => b.setButtonText("\u52A0\u5165\u5DF2\u6709\u540C\u6B65\u5E93").onClick(() => void use("join"))).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => modal.close()));
    modal.open();
  }
  async previewInventory(allowUninitialized = false) {
    if (!this.app.vault.getName().startsWith("Realtime-Lab-V3-Files-") || !allowUninitialized && !await this.allowed()) {
      new import_obsidian.Notice("\u4EC5\u9884\u89C8\u5F53\u524D\u72EC\u7ACB V3 \u6D4B\u8BD5\u5E93");
      return;
    }
    const m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u53EA\u8BFB\u8FC1\u79FB\u9884\u89C8\uFF08\u4E0D\u6267\u884C\u590D\u5236\uFF09");
    m.open();
    try {
      const files = this.app.vault.getFiles(), accepted = files.filter((f) => supportedFile(f.path) && f.stat.size <= maxFileSize(f.path)), excluded = files.filter((f) => !accepted.includes(f)).map((f) => ({ path: f.path, size: f.stat.size, reason: "\u4E0D\u652F\u6301\u7C7B\u578B\u3001\u63A7\u5236/\u9690\u85CF\u6587\u4EF6\u6216\u8D85\u8FC7\u5355\u6587\u4EF6\u4E0A\u9650\uFF1B\u4EC5\u5217\u5143\u6570\u636E\uFF0C\u672A\u8BFB\u53D6\u6B63\u6587" }));
      const result = await inventory(accepted.map((f) => ({ path: f.path, size: f.stat.size })), async (p) => {
        const f = this.app.vault.getAbstractFileByPath(p);
        if (!(f instanceof import_obsidian.TFile)) throw Error("\u6587\u4EF6\u5DF2\u53D8\u5316\uFF1A" + p);
        return this.app.vault.readBinary(f);
      }, { supported: supportedFile, maxFileSize });
      let remoteReport;
      const remote = this.client?.ready ? entries(this.client.doc) : void 0;
      if (remote) m.contentEl.createEl("pre", { text: JSON.stringify({ remoteReferences: remote }, null, 2) });
      const differences = diffInventory(result, remoteReport);
      m.contentEl.createEl("p", { text: "\u9ED8\u8BA4\u4E0D\u5199\u5165\uFF1B\u672A\u8FDE\u63A5\u65F6\u8FDC\u7AEF\u5DEE\u5F02\u6807\u8BB0\u4E3A\u672A\u77E5\u3002\u8FDC\u7AEF\u4EC5\u663E\u793A\u6587\u672C\u548C\u9644\u4EF6\u5F15\u7528\uFF1B\u672C\u5730\u8BA1\u7B97\u6587\u4EF6\u6E05\u5355\u548C SHA256\uFF0C\u4E0D\u4E0A\u4F20\u3001\u4E0D\u4FEE\u6539\u3001\u4E0D\u8FC1\u79FB\u3002\u914D\u7F6E\u53CA\u9690\u85CF\u76EE\u5F55\u4EC5\u5217\u4E3A\u6392\u9664\uFF0C\u4E0D\u8BFB\u53D6\u5185\u5BB9\u3001\u4E0D\u8BA1\u7B97\u51ED\u636E\u54C8\u5E0C\u3002" });
      m.contentEl.createEl("pre", { text: JSON.stringify({ inventory: result, excluded, comparison: differences }, null, 2) });
    } catch (e) {
      m.contentEl.createEl("p", { text: String(e) });
    }
  }
  conflicts = [];
  conflictRefresh = null;
  conflictTimer;
  conflictSeen = /* @__PURE__ */ new Set();
  conflictError = "";
  async refreshConflicts() {
    const c = this.client;
    if (!c?.ready) return;
    if (!c.serverCapabilities?.includes(CONFLICT_CAPABILITY)) {
      this.conflictError = "\u6B64\u670D\u52A1\u5668\u5C1A\u672A\u652F\u6301\u51B2\u7A81\u68C0\u67E5\uFF0C\u672A\u786E\u8BA4\u51B2\u7A81\u72B6\u6001";
      return;
    }
    if (this.conflictRefresh) return this.conflictRefresh;
    this.conflictRefresh = (async () => {
      try {
        const rows = await c.request("conflicts");
        if (this.client !== c) return;
        this.conflicts = rows;
        this.conflictError = "";
        for (const row of rows) if (!this.conflictSeen.has(row.id)) {
          this.conflictSeen.add(row.id);
          new import_obsidian.Notice("\u53D1\u73B0\u6574\u6587\u4EF6\u7248\u672C\u51B2\u7A81\uFF1A" + row.path + "\uFF1B\u53CC\u65B9\u5185\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u70B9\u51FB\u540C\u6B65\u72B6\u6001\u67E5\u770B\u3002");
        }
        this.updateProgress();
      } catch (e) {
        if (this.client === c) {
          this.conflictError = this.safeError(e);
          this.updateProgress();
        }
      }
    })().finally(() => {
      this.conflictRefresh = null;
    });
    return this.conflictRefresh;
  }
  scheduleConflicts() {
    window.clearTimeout(this.conflictTimer);
    this.conflictTimer = window.setTimeout(() => void this.refreshConflicts(), 500);
  }
  async resolveConflict(review, strategy, version, expected) {
    const c = this.client;
    if (!c?.ready) throw Error("\u8BF7\u5148\u8FDE\u63A5\u6D4B\u8BD5\u5E93");
    const task = this.queue.then(async () => {
      if (c !== this.client || !c.ready) throw Error("\u8FDE\u63A5\u5DF2\u6539\u53D8");
      if (this.dirtyFiles.has(review.path) || c.pending.some((p) => p.path === review.path) || c.pendingPaths.includes(review.path) || c.pendingPaths.includes("*")) throw Error("\u6B64\u6587\u4EF6\u4ECD\u6709\u5F85\u4F20\u4FEE\u6539\uFF0C\u8BF7\u5148\u540C\u6B65");
      if (!sameContent(content(c.doc, review.path), expected)) throw Error("\u5F53\u524D\u5185\u5BB9\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u67E5\u770B\u51B2\u7A81");
      if (strategy === "use-version") {
        const f = this.app.vault.getAbstractFileByPath(review.path);
        if (f instanceof import_obsidian.TFile) {
          const local = await this.read(f);
          if (!equal(local, expected)) throw Error("\u672C\u5730\u5185\u5BB9\u5C1A\u672A\u540C\u6B65\uFF0C\u672A\u66FF\u6362");
          await this.backup(review.path, local);
        }
      }
      if (this.dirtyFiles.has(review.path) || !sameContent(content(c.doc, review.path), expected)) throw Error("\u5F53\u524D\u5185\u5BB9\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u67E5\u770B\u51B2\u7A81");
      await c.request("resolve-conflict", { path: review.path, reviewId: review.id, strategy, version, expected });
      await this.reflect();
      await c.confirmUploads();
      await this.refreshConflicts();
    });
    this.queue = task.catch(() => {
    });
    return task;
  }
  async conflictText(path, v) {
    if (!v) return "[\u5F53\u524D\u6587\u4EF6\u5DF2\u5220\u9664]";
    if (v.kind === "text") return v.data;
    if (!/\.md$/i.test(path)) return null;
    if (!await this.cache.has(v)) await this.client.blobs.download(v, this.cache.sink(v));
    return new TextDecoder("utf-8", { fatal: true }).decode(await this.cache.materialize(v));
  }
  async openConflicts() {
    await this.refreshConflicts();
    const m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u540C\u6B65\u51B2\u7A81");
    m.modalEl.addClass("rl-history-modal");
    m.contentEl.createEl("p", { text: "\u9010\u5B57\u534F\u4F5C\u7B14\u8BB0\u81EA\u52A8\u5408\u5E76\uFF1B\u8FD9\u91CC\u5217\u51FA\u6574\u6587\u4EF6\u7684\u7248\u672C\u5206\u53C9\u3002\u5904\u7406\u4E0D\u4F1A\u4E22\u5F03\u5386\u53F2\uFF0C\u6240\u6709\u5019\u9009\u7248\u672C\u4F1A\u53E6\u5B58\u5230\u201C\u51B2\u7A81\u526F\u672C\u201D\u3002" });
    if (this.conflictError) m.contentEl.createEl("p", { text: "\u51B2\u7A81\u5217\u8868\u5C1A\u672A\u786E\u8BA4\uFF1A" + this.conflictError });
    if (!this.conflicts.length && !this.conflictError) m.contentEl.createEl("p", { text: this.client?.ready ? "\u5F53\u524D\u6CA1\u6709\u5F85\u5904\u7406\u7684\u6574\u6587\u4EF6\u51B2\u7A81\u3002" : "\u5F53\u524D\u672A\u8FDE\u63A5\uFF0C\u8BF7\u8FDE\u63A5\u540E\u5237\u65B0\u51B2\u7A81\u5217\u8868\u3002" });
    for (const r2 of this.conflicts) new import_obsidian.Setting(m.contentEl).setName(r2.path).setDesc(r2.reason + " \xB7 " + r2.versions.length + " \u4E2A\u4FDD\u7559\u7248\u672C").addButton((b) => b.setButtonText("\u67E5\u770B\u4E0E\u5904\u7406").onClick(() => {
      m.close();
      void this.showConflict(r2);
    }));
    m.open();
  }
  async showConflict(review) {
    const c = this.client;
    if (!c?.ready) return;
    const expected = content(c.doc, review.path), m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u5904\u7406\u51B2\u7A81 \xB7 " + review.path);
    m.modalEl.addClass("rl-history-modal");
    m.contentEl.createEl("p", { text: "\u5F53\u524D\u6587\u4EF6\u5148\u4FDD\u6301\u539F\u6837\u3002\u53EF\u4FDD\u7559\u6240\u6709\u7248\u672C\u4E3A\u526F\u672C\uFF0C\u6216\u9884\u89C8\u3001\u6BD4\u8F83\u540E\u660E\u786E\u9009\u62E9\u4E00\u4E2A\u7248\u672C\u3002\u9009\u62E9\u7248\u672C\u4E5F\u4F1A\u4FDD\u7559\u5176\u4F59\u7248\u672C\u526F\u672C\u3002" });
    m.open();
    try {
      const list = await c.request("history", { path: review.path });
      const confirm = (strategy, version) => {
        const ask = new import_obsidian.Modal(this.app);
        ask.titleEl.setText(strategy === "keep-both" ? "\u4FDD\u7559\u6240\u6709\u7248\u672C" : "\u786E\u8BA4\u4F7F\u7528\u6B64\u7248\u672C");
        ask.contentEl.createEl("p", { text: strategy === "keep-both" ? "\u539F\u6587\u4EF6\u4E0D\u53D8\uFF0C\u6240\u6709\u5019\u9009\u7248\u672C\u53E6\u5B58\u4E3A\u51B2\u7A81\u526F\u672C\u5E76\u6807\u8BB0\u5DF2\u5904\u7406\u3002" : "\u5F53\u524D\u5185\u5BB9\u5148\u5907\u4EFD\uFF0C\u6240\u6709\u5019\u9009\u7248\u672C\u53E6\u5B58\u4E3A\u51B2\u7A81\u526F\u672C\uFF0C\u518D\u66FF\u6362\u539F\u6587\u4EF6\u5E76\u540C\u6B65\u5230\u6D4B\u8BD5\u8BBE\u5907\u3002" });
        new import_obsidian.Setting(ask.contentEl).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => ask.close())).addButton((b) => b.setButtonText("\u786E\u8BA4\u5904\u7406").onClick(async () => {
          try {
            await this.resolveConflict(review, strategy, version, expected);
            new import_obsidian.Notice("\u51B2\u7A81\u5DF2\u5904\u7406\uFF0C\u5019\u9009\u7248\u672C\u526F\u672C\u5DF2\u540C\u6B65");
            ask.close();
            m.close();
          } catch (e) {
            new import_obsidian.Notice(this.safeError(e));
          }
        }));
        ask.open();
      };
      new import_obsidian.Setting(m.contentEl).addButton((b) => b.setButtonText("\u4FDD\u7559\u6240\u6709\u7248\u672C\u4E3A\u526F\u672C").onClick(() => confirm("keep-both")));
      for (const id2 of review.versions) {
        const v = list.find((x) => x.id === id2);
        if (!v) {
          m.contentEl.createEl("p", { text: "\u7248\u672C\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5148\u5BFC\u51FA\u53EF\u7528\u5386\u53F2\uFF0C\u672A\u81EA\u52A8\u5904\u7406\u3002" });
          continue;
        }
        new import_obsidian.Setting(m.contentEl).setName(new Date(v.time).toLocaleString()).setDesc(sameContent(v, expected) ? "\u5F53\u524D\u7248\u672C" : "\u4FDD\u7559\u7248\u672C").addButton((b) => b.setButtonText("\u9884\u89C8").onClick(() => void this.previewVersion(review.path, id2))).addButton((b) => b.setButtonText("\u5DEE\u5F02").onClick(async () => {
          try {
            const selected = await c.request("history-preview", { path: review.path, version: id2 }), a = await this.conflictText(review.path, expected), b2 = await this.conflictText(review.path, selected), diff = new import_obsidian.Modal(this.app);
            diff.titleEl.setText("\u4E0E\u5F53\u524D\u7248\u672C\u6BD4\u8F83");
            diff.modalEl.addClass("rl-history-modal");
            if (a === null || b2 === null) diff.contentEl.createEl("p", { text: "\u56FE\u7247\u4E0E PDF \u8BF7\u5206\u522B\u70B9\u51FB\u9884\u89C8\u67E5\u770B\uFF1B\u6B64\u5904\u4E0D\u505A\u9010\u884C\u6BD4\u8F83\u3002" });
            else {
              const d = textDifference(a, b2);
              diff.contentEl.createEl("p", { text: d.equal ? "\u6587\u5B57\u5185\u5BB9\u76F8\u540C" : "\u8FDE\u7EED\u53D8\u5316\u533A\u95F4\uFF1A\u2212 \u5F53\u524D\u7248\u672C\uFF1B+ \u6240\u9009\u7248\u672C\u3002" + (d.truncated ? "\u5185\u5BB9\u8F83\u957F\uFF0C\u6458\u8981\u5DF2\u622A\u65AD\uFF1B\u5B8C\u6574\u7248\u672C\u4ECD\u4FDD\u7559\u3002" : "") });
              diff.contentEl.createEl("pre", { cls: "rl-history-preview", text: d.removed + "\n" + d.added });
            }
            diff.open();
          } catch (e) {
            new import_obsidian.Notice(this.safeError(e));
          }
        })).addButton((b) => b.setButtonText("\u4F7F\u7528\u6B64\u7248\u672C").onClick(() => confirm("use-version", id2)));
      }
    } catch (e) {
      m.contentEl.createEl("p", { text: "\u672A\u5904\u7406\u4EFB\u4F55\u6587\u4EF6\uFF1A" + this.safeError(e) });
    }
  }
  async restoreVersion(path, version, target, expected) {
    const c = this.client;
    if (!c?.ready) throw Error("\u8BF7\u5148\u8FDE\u63A5\u6D4B\u8BD5\u5E93");
    const task = this.queue.then(async () => {
      if (this.client !== c || !c.ready) throw Error("\u8FDE\u63A5\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8");
      if (this.dirtyFiles.has(target) || c.pending.some((p) => p.path === target) || c.pendingPaths.includes(target) || c.pendingPaths.includes("*")) throw Error("\u5F53\u524D\u6587\u4EF6\u4ECD\u6709\u5F85\u4F20\u5185\u5BB9\uFF0C\u8BF7\u5148\u5B8C\u6210\u540C\u6B65");
      const f = this.app.vault.getAbstractFileByPath(target);
      if (target !== path && f) throw Error("\u526F\u672C\u8DEF\u5F84\u5DF2\u5B58\u5728");
      if (target === path) {
        if (JSON.stringify(content(c.doc, path)) !== JSON.stringify(expected)) throw Error("\u6587\u4EF6\u5728\u9884\u89C8\u540E\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8");
        if (f instanceof import_obsidian.TFile) {
          const local = await this.read(f);
          if (!equal(local, expected)) throw Error("\u78C1\u76D8\u5185\u5BB9\u4E0E\u9884\u89C8\u65F6\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u5148\u5B8C\u6210\u540C\u6B65");
          await this.backup(path, local);
        }
      }
      if (this.dirtyFiles.has(target) || JSON.stringify(content(c.doc, target)) !== JSON.stringify(expected)) throw Error("\u6587\u4EF6\u5728\u9884\u89C8\u540E\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8");
      await c.request("restore", { path, version, target, expected });
      await this.reflect();
      await c.confirmUploads();
      this.updateProgress();
    });
    this.queue = task.catch(() => {
    });
    return task;
  }
  async previewVersion(path, id2) {
    const c = this.client;
    if (!c?.ready) return;
    const m = new import_obsidian.Modal(this.app);
    m.titleEl.setText("\u7248\u672C\u9884\u89C8 \xB7 " + path);
    m.modalEl.addClass("rl-history-modal");
    m.contentEl.createEl("p", { text: "\u6B63\u5728\u8BFB\u53D6\u5386\u53F2\u7248\u672C\u2026" });
    let imageURL, closed = false;
    m.onClose = () => {
      closed = true;
      if (imageURL) URL.revokeObjectURL(imageURL);
    };
    m.open();
    try {
      const expected = content(c.doc, path), v = await c.request("history-preview", { path, version: id2 });
      if (closed) return;
      m.contentEl.empty();
      m.contentEl.createEl("p", { text: new Date(v.time).toLocaleString() + (v.conflict ? " \xB7 \u5E76\u53D1\u4FDD\u7559\u7248\u672C" : "") });
      if (v.deleted) m.contentEl.createEl("p", { text: "\u6B64\u7248\u672C\u8868\u793A\u6587\u4EF6\u5DF2\u5220\u9664\u3002\u66FF\u6362\u64CD\u4F5C\u4F1A\u540C\u6B65\u5220\u9664\uFF0C\u5F53\u524D\u6587\u4EF6\u5148\u5907\u4EFD\u3002" });
      else if (v.kind === "text") m.contentEl.createEl("pre", { cls: "rl-history-preview", text: v.data });
      else {
        m.contentEl.createEl("p", { text: "\u6587\u4EF6\u5927\u5C0F\uFF1A" + v.size + " \u5B57\u8282" });
        if (textPreviewPath(path) || /\.(png|jpe?g|gif|webp)$/i.test(path)) {
          if (!await this.cache.has(v)) await c.blobs.download(v, this.cache.sink(v));
          if (closed) return;
          const bytes = await this.cache.materialize(v);
          if (textPreviewPath(path)) {
            const text2 = decodeTextPreview(bytes);
            if (text2 === null) m.contentEl.createEl("p", { text: "\u6B64\u6587\u4EF6\u4E0D\u662F UTF-8 \u6587\u672C\uFF1B\u4ECD\u53EF\u6309\u539F\u59CB\u5B57\u8282\u6062\u590D\uFF0C\u4E0D\u8F6C\u6362\u7F16\u7801\u3002" });
            else {
              m.contentEl.createEl("pre", { cls: "rl-history-preview", text: text2.slice(0, 2e4) });
              if (text2.length > 2e4) m.contentEl.createEl("p", { text: "\u9884\u89C8\u4EC5\u663E\u793A\u524D20000\u5B57\u7B26\uFF0C\u6062\u590D\u4F7F\u7528\u5B8C\u6574\u7248\u672C\u3002" });
            }
          } else {
            imageURL = URL.createObjectURL(new Blob([bytes], { type: /\.png$/i.test(path) ? "image/png" : /\.jpe?g$/i.test(path) ? "image/jpeg" : /\.gif$/i.test(path) ? "image/gif" : "image/webp" }));
            m.contentEl.createEl("img", { cls: "rl-history-image", attr: { src: imageURL, alt: "\u5386\u53F2\u56FE\u7247\u9884\u89C8" } });
          }
        } else m.contentEl.createEl("p", { text: "\u6B64\u9644\u4EF6\u4EC5\u663E\u793A\u7248\u672C\u4FE1\u606F\uFF0C\u53EF\u6062\u590D\u4E3A\u526F\u672C\u540E\u6253\u5F00\u67E5\u770B\u3002" });
      }
      m.contentEl.createEl("p", { text: "\u6062\u590D\u4E3A\u526F\u672C\u4FDD\u7559\u539F\u6587\u4EF6\uFF1B\u66FF\u6362\u5F53\u524D\u6587\u4EF6\u4F1A\u540C\u6B65\u5230\u6D4B\u8BD5\u8BBE\u5907\uFF0C\u5F53\u524D\u5185\u5BB9\u5148\u5907\u4EFD\u3002\u9884\u89C8\u540E\u82E5\u6709\u65B0\u4FEE\u6539\uFF0C\u5C06\u62D2\u7EDD\u66FF\u6362\u5E76\u8981\u6C42\u91CD\u65B0\u9884\u89C8\u3002" });
      const controls = new import_obsidian.Setting(m.contentEl);
      if (!v.deleted) controls.addButton((b) => b.setButtonText("\u6062\u590D\u4E3A\u526F\u672C").onClick(async () => {
        try {
          const name = path.slice(path.lastIndexOf("/") + 1), dot = name.lastIndexOf("."), target = "\u6062\u590D\u526F\u672C/" + name.slice(0, dot) + "-" + Date.now() + "-" + crypto.randomUUID().slice(0, 6) + name.slice(dot);
          await this.restoreVersion(path, id2, target, null);
          new import_obsidian.Notice("\u526F\u672C\u5DF2\u6062\u590D\u5E76\u540C\u6B65\uFF1A" + target);
          m.close();
        } catch (e) {
          new import_obsidian.Notice(this.safeError(e));
        }
      }));
      controls.addButton((b) => b.setButtonText(v.deleted ? "\u6062\u590D\u5220\u9664\u72B6\u6001" : "\u66FF\u6362\u5F53\u524D\u6587\u4EF6").onClick(() => {
        const confirm = new import_obsidian.Modal(this.app);
        confirm.titleEl.setText("\u786E\u8BA4\u66FF\u6362 \xB7 " + path);
        confirm.contentEl.createEl("p", { text: "\u5C06\u7528\u9884\u89C8\u7684\u5386\u53F2\u7248\u672C\u66FF\u6362\u5F53\u524D\u6587\u4EF6\u5E76\u540C\u6B65\u5230\u6D4B\u8BD5\u8BBE\u5907\uFF1B\u5F53\u524D\u5185\u5BB9\u5148\u5907\u4EFD\u3002" });
        new import_obsidian.Setting(confirm.contentEl).addButton((b2) => b2.setButtonText("\u53D6\u6D88").onClick(() => confirm.close())).addButton((b2) => b2.setButtonText("\u786E\u8BA4\u66FF\u6362").onClick(async () => {
          try {
            await this.restoreVersion(path, id2, path, expected);
            new import_obsidian.Notice("\u5386\u53F2\u7248\u672C\u5DF2\u6062\u590D");
            confirm.close();
            m.close();
          } catch (e) {
            new import_obsidian.Notice(this.safeError(e));
          }
        }));
        confirm.open();
      }));
    } catch (e) {
      if (!closed) {
        m.contentEl.empty();
        m.contentEl.createEl("p", { text: "\u65E0\u6CD5\u9884\u89C8\uFF0C\u672A\u6062\u590D\u4EFB\u4F55\u6587\u4EF6\uFF1A" + this.safeError(e) });
      }
    }
  }
  async history() {
    if (!this.client?.ready) {
      new import_obsidian.Notice("\u8BF7\u5148\u8FDE\u63A5 Files \u6D4B\u8BD5\u670D\u52A1\u5668");
      return;
    }
    const modal = new import_obsidian.Modal(this.app);
    modal.titleEl.setText("\u6D4B\u8BD5\u5E93\u5386\u53F2\u7248\u672C");
    modal.open();
    try {
      const paths = await this.client.request("history");
      modal.contentEl.createEl("p", { text: "\u6BCF\u6587\u4EF6\u6700\u8FD130\u4E2A\u7248\u672C\uFF1B\u6574\u6587\u4EF6\u51B2\u7A81\u53CC\u65B9\u4FDD\u7559\u5728\u53EF\u7528\u5386\u53F2\u4E2D\u3002\u53EA\u663E\u793A\u524D100\u4E2A\u5339\u914D\u8DEF\u5F84\uFF0C\u8BF7\u641C\u7D22\u5B8C\u6574\u8DEF\u5F84\u67E5\u627E\u5176\u4F59\u6587\u4EF6\u3002\u6062\u590D\u65B0\u589E\u7248\u672C\uFF0C\u5F53\u524D\u5185\u5BB9\u5148\u4FDD\u5B58\u5230\u672C\u5730\u6062\u590D\u76EE\u5F55\u3002" });
      let query = "";
      const search = new import_obsidian.Setting(modal.contentEl).setName("\u641C\u7D22\u6587\u4EF6\u8DEF\u5F84");
      const rows = modal.contentEl.createDiv();
      const versions = async (path) => {
        try {
          const list = await this.client.request("history", { path });
          modal.contentEl.empty();
          modal.titleEl.setText(path);
          new import_obsidian.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u8FD4\u56DE\u8DEF\u5F84\u641C\u7D22").onClick(() => {
            modal.close();
            void this.history();
          }));
          for (const v of [...list].reverse()) new import_obsidian.Setting(modal.contentEl).setName(new Date(v.time).toLocaleString()).setDesc(v.deleted ? "\u5DF2\u5220\u9664" : v.conflict ? "\u5E76\u53D1\u4FDD\u7559\u7248\u672C" : v.kind === "text" ? "\u9010\u5B57\u6587\u672C\u7248\u672C" : "\u6574\u6587\u4EF6\u7248\u672C").addButton((btn) => btn.setButtonText("\u9884\u89C8\u4E0E\u6062\u590D").onClick(() => void this.previewVersion(path, v.id)));
        } catch (e) {
          new import_obsidian.Notice(String(e));
        }
      };
      const render = () => {
        rows.empty();
        const matching = paths.filter((p) => p.path.includes(query));
        rows.createEl("p", { text: matching.length + " \u4E2A\u5339\u914D\u8DEF\u5F84\uFF0C\u663E\u793A\u524D100\u4E2A" });
        for (const { path, versions: count } of matching.slice(0, 100)) new import_obsidian.Setting(rows).setName(path).setDesc(count + " \u4E2A\u7248\u672C").addButton((b) => b.setButtonText("\u67E5\u770B").onClick(() => void versions(path)));
      };
      search.addText((t) => t.onChange((v) => {
        query = v;
        render();
      }));
      render();
    } catch (e) {
      modal.contentEl.createEl("p", { text: String(e) });
    }
  }
  stop() {
    window.clearTimeout(this.safetyTimer);
    this.safetyTimer = void 0;
    this.stopping = true;
    window.clearTimeout(this.conflictTimer);
    this.reflection.cancel();
    this.fileUploads.cancel();
    this.dirtyFiles.clear();
    let saved = Promise.resolve(true);
    window.clearTimeout(this.saveTimer);
    if (this.client) {
      if (this.client.serverId) this.settings.state = this.client.flushPersist(true) || this.settings.state;
      saved = this.client.close();
      this.client = null;
    }
    for (const [cm, b] of this.bindings) {
      try {
        cm.dispatch({ effects: b.c.reconfigure([]) });
      } catch {
      }
      b.undo.destroy();
    }
    this.bindings.clear();
    this.setConnectionStatus("\u5DF2\u65AD\u5F00");
    return saved.then(async (ok) => {
      try {
        await this.flushReceipts();
        return ok;
      } catch {
        return false;
      }
    });
  }
  onunload() {
    this.uiUnloaded = true;
    window.clearTimeout(this.safetyTimer);
    window.clearTimeout(this.diagnosticTimer);
    this.badgeObserver?.disconnect();
    this.stop();
    window.clearTimeout(this.progressTimer);
    this.syncPanel = void 0;
    for (const m of [...this.detailModals]) m.close();
    for (const b of this.badges.values()) b.el.parentElement?.remove();
    this.badges.clear();
    this.badgeStyle?.remove();
  }
};
var Settings = class extends import_obsidian.PluginSettingTab {
  constructor(app, p) {
    super(app, p);
    this.p = p;
  }
  display() {
    const e = this.containerEl;
    e.empty();
    e.createEl("h2", { text: "Realtime Lab V3 \xB7 \u6574\u5E93\u6D4B\u8BD5" });
    this.p.syncPanel = e.createDiv();
    this.p.renderProgress();
    new import_obsidian.Setting(e).addButton((b) => b.setButtonText("\u5237\u65B0\u72B6\u6001").onClick(() => this.p.renderProgress())).addButton((b) => b.setButtonText("\u91CD\u8BD5\u5F85\u4F20\u4E0E\u63A5\u6536").onClick(() => void this.p.retryQueue()));
    new import_obsidian.Setting(e).setName("\u8BEF\u7F6E\u65E7\u534F\u8BAE\u8BBE\u7F6E").addButton((b) => b.setButtonText("\u5907\u4EFD\u5E76\u6E05\u7A7A\u65E7\u72B6\u6001").onClick(() => void this.p.backupRejectedState()));
    e.createEl("p", { text: "\u4EC5 Realtime-Lab-V3-Files- \u72EC\u7ACB\u6D4B\u8BD5\u5E93\u3002\u652F\u6301 Markdown\u3001\u56FE\u7247\u3001PDF\u53CA JSON/CSV/JSONL/HTML/Python/TXT/\u6821\u9A8C/\u65E5\u5FD7/ZIP/\u5907\u4EFD\u6587\u4EF6\uFF08\u4EC5\u4F20\u8F93\uFF0C\u4E0D\u6267\u884C\uFF09\uFF1A\u5B9E\u65F6\u534F\u4F5C\u6D4B\u8BD5.md \u5728\u226416 KiB\u65F6\u9010\u5B57\u534F\u4F5C\uFF1B\u5176\u4F59 Markdown \u6309\u6574\u6587\u4EF6\u7248\u672C\u540C\u6B65\uFF08\u226416 MiB\uFF09\uFF0C\u51B2\u7A81\u53CC\u65B9\u4FDD\u7559\u5386\u53F2\uFF1B\u56FE\u7247/PDF\u22645 MiB\uFF0C\u5176\u4ED6\u8D44\u6599\u226416 MiB\uFF1B\u6D3B\u52A8\u5185\u5BB9\u2264256 MiB\u3001\u6700\u591A6000\u6D3B\u52A8\u8DEF\u5F84/8192\u8DDF\u8E2A\u8DEF\u5F84\uFF08\u542B\u5893\u7891\uFF09\uFF0C\u670D\u52A1\u7AEF\u4E0E\u672C\u5730\u7F13\u5B58\u5404\u2264512 MiB\u3001CRDT\u72B6\u6001\u22642 MiB\u3002\u914D\u7F6E\u3001\u9690\u85CF\u6587\u4EF6\u548C\u6062\u590D\u526F\u672C\u4E0D\u53C2\u4E0E\u540C\u6B65\u3002V3 \u670D\u52A1\u5668\u4E0E\u65E7\u7248\u4E0D\u517C\u5BB9\uFF0C\u8BF7\u52FF\u590D\u7528\u65E7\u8FDE\u63A5\u3002" });
    new import_obsidian.Setting(e).setName("\u521B\u5EFA\u6216\u52A0\u5165\u5411\u5BFC").addButton((b) => b.setButtonText("\u914D\u7F6E\u8FDE\u63A5").onClick(() => void this.p.setupConnection()));
    new import_obsidian.Setting(e).setName("\u53EA\u8BFB\u6587\u4EF6\u53CA\u9644\u4EF6\u6E05\u5355").addButton((b) => b.setButtonText("\u9884\u89C8\uFF0C\u4E0D\u8FC1\u79FB").onClick(() => void this.p.previewInventory()));
    new import_obsidian.Setting(e).setName("\u521D\u59CB\u5316\u72EC\u7ACB\u6D4B\u8BD5\u5E93").addButton((b) => b.setButtonText("\u521D\u59CB\u5316").onClick(() => void this.p.initialize()));
    new import_obsidian.Setting(e).setName("V3 WebSocket \u5730\u5740").addText((t) => t.setValue(this.p.settings.url).onChange(async (v) => {
      if (this.p.settings.state && !this.p.settings.stateOrigin) this.p.settings.stateOrigin = this.p.settings.url;
      this.p.settings.url = v.trim();
      await this.p.persistConfig();
    }));
    new import_obsidian.Setting(e).setName("\u8BBF\u95EE\u4EE4\u724C").addText((t) => {
      t.inputEl.type = "password";
      t.setValue(this.p.settings.token).onChange(async (v) => {
        this.p.settings.token = v.trim();
        await this.p.persistConfig();
      });
    });
    new import_obsidian.Setting(e).setName("\u6253\u5F00\u65F6\u81EA\u52A8\u8FDE\u63A5").addToggle((t) => t.setValue(this.p.settings.enabled).onChange(async (v) => {
      this.p.settings.enabled = v;
      await this.p.persistConfig();
      this.p.renderProgress();
      if (v && !this.p.client) await this.p.start();
    }));
    new import_obsidian.Setting(e).setName("\u8FDE\u63A5\u6574\u4E2A\u6D4B\u8BD5\u5E93").addButton((b) => b.setButtonText("\u8FDE\u63A5").onClick(() => void this.p.start()));
    new import_obsidian.Setting(e).setName("\u5220\u9664\u4E0E\u91CD\u547D\u540D\u4FDD\u62A4").addButton((b) => b.setButtonText("\u67E5\u770B\u5F85\u786E\u8BA4\u64CD\u4F5C").onClick(() => void this.p.openPathSafety()));
    new import_obsidian.Setting(e).setName("\u8BBE\u5907\u8FDC\u7A0B\u8BCA\u65AD").addButton((b) => b.setButtonText("\u67E5\u770B\u8BBE\u5907\u72B6\u6001").onClick(() => void this.p.openDeviceDiagnostics()));
    new import_obsidian.Setting(e).setName("\u540C\u6B65\u51B2\u7A81").addButton((b) => b.setButtonText("\u67E5\u770B\u4E0E\u5904\u7406").onClick(() => void this.p.openConflicts()));
    new import_obsidian.Setting(e).setName("\u5386\u53F2\u7248\u672C\uFF08\u542B\u5DF2\u5220\u9664\u6587\u4EF6\uFF09").addButton((b) => b.setButtonText("\u67E5\u770B\u4E0E\u6062\u590D").onClick(() => void this.p.history()));
    new import_obsidian.Setting(e).setName("\u65AD\u5F00").addButton((b) => b.setButtonText("\u65AD\u5F00").onClick(() => this.p.stop()));
  }
};
