# Realtime Lab 0.4.0-alpha.6 — isolated whole-vault candidate

Extends the existing project. This is a local candidate, not the published 0.3.0 release. No existing vault, public service, tunnel, plugin installation, or CouchDB database is replaced.

## Features

Nested Markdown notes have individual Y.Text documents for incremental concurrent editing. PNG/JPEG/GIF/WebP/SVG/AVIF/BMP images synchronize with relative Markdown embeds. Create, modify, rename and delete events synchronize. Empty directories and automatic rewriting of all links after rename are not supported.

History records visible content changes and deletion. Restore through plugin settings or the history command; confirmation is required and the current local file is backed up first. Restore creates a new revision and broadcasts it. Latest 30 visible changes per path are retained, with a 100 MiB total history budget. These are updates, not days of backups; old versions are evicted. Concurrent image uploads carry immutable revision records, so a losing image branch remains restorable in history within the same retention budget.

Offline file events update client state. Startup with saved state reconciles changed disk Markdown before receiving remote operations. Separate deletion tombstones prevent stale edits from silently reviving a file. Conflicting local content is preserved under .realtime-lab-recovery/, which is excluded from sync. Concurrent image replacement has one visible winner; losing uploaded image variants are retained as conflict versions, and overwritten local disk images are backed up.

## Isolation and join direction

Create a NEW empty vault named Realtime-Lab-V2-MacMini or Realtime-Lab-V2-iPhone. Install this candidate there and initialize it. Name plus realtime-lab-v2.json marker with isolatedLab=true and protocol=2 are required. Ordinary vaults and v1 test vaults are rejected. LiveSync must not be enabled in this isolated vault.

V2 requires a separate V2 server and separate private data directory. Do not reuse the v1 endpoint or directory. There is no automatic migration, replacement or production switch.

First join: matching server files are used, differing local files are backed up first, and local-only supported files are uploaded. Existing snapshot: modified disk content is reconciled first, then remote operations merge. If saved-state files are missing while the plugin was not running, connection pauses for an explicit choice: restore from server, propagate confirmed deletions, or cancel. No deletion direction is guessed.

Hidden paths, .obsidian/, recovery copies, tokens, JSON configuration, and unsupported types do not sync. This candidate synchronizes Markdown plus the listed images, not every byte of a vault.

## Limits and security

Single image <=5 MiB, note <=1 MiB, active total <=50 MiB, <=1000 paths including tombstones, encoded CRDT state <=100 MiB. Unicode NFC and cross-platform-safe names required; case-insensitive collisions are rejected rather than guessed.

Shared token grants access to the one isolated room including history. Tokens remain in local plugin data and the server private directory, never in install artifacts. WSS is transport encryption, not end-to-end encryption. iOS background execution is not guaranteed. Client settings have a 200 ms debounce; process kill can lose that window. Disk reconciliation can recover only content already saved by Obsidian. Keep independent backups.

## Build and test

Node 22: npm ci; npm run typecheck; npm test; npm run build; npm run privacy-check.

npm start launches the V2 loopback server on port 17237. A new private test token is generated in work/vault-v2/token. LAB_DATA_DIR, LAB_PORT, LAB_HOST and LAB_TOKEN override values. Dockerfile is for a new isolated V2 service, never replacement of a running service.

Automated evidence includes actual WebSocket and Yjs transport, real CodeMirror bindings, server restart and history persistence, duplicate delivery, path validation, image bytes and limits, deletion tombstones, plus the actual plugin bundle with a simulated Obsidian filesystem/event adapter. Adapter tests cover offline disk changes, reconnect, delete recovery, and a fresh plugin instance reconciling changed disk content from saved state.

The preceding 0.4.0-alpha.1 build in native Mac mini Obsidian 1.14.4 verified nested notes, image rendering and byte equality, native editor upload, create/rename, image filesystem upload, history restore through the native UI, deletion recovery, and service interruption followed by offline editing and reconnect persistence. The second endpoint was a software test client, not a physical iPhone. The alpha.3 native candidate subsequently passed preview cancellation, explicit Join, concurrent image recovery and independent-directory snapshot checks, but failed automatic reconnect after Create (CREATE_MODE_RETRY). The alpha.4 build subsequently passed the actual Mac Create→populate→disconnect→offline edit→test-window Force Reload→automatic reconnect chain without manual Join. Alpha.5 and this alpha.6 source candidate have not been installed or run in native Obsidian. NOT YET VERIFIED: physical iPhone or Windows V2 Obsidian, native process kill, mobile memory pressure, large-vault soak. Earlier 0.3.0 phone-to-Mac evidence does not establish V2 acceptance.

## Recovery

Stop V2 before rollback. Keep the entire test vault including hidden recovery directory and plugin data, and a private server data backup. Use the operating system file manager to inspect .realtime-lab-recovery/. Server history requires an authenticated V2 connection. Old v1 test vault and service remain separate.

## Alpha.2 configuration protections (source-only candidate)

A persisted server UUID is included in the authenticated welcome. A cached snapshot requires its verified server ID and endpoint origin. A different server ID, missing identity, changed endpoint, or same-URL rebuilt database stops before old state is uploaded. No state or tombstone is silently cleared. Alias URLs to the same server ID are conservatively refused; alias approval is not implemented.

The Create/Join setup dialog uses existing operator-supplied test credentials, never creates credentials or servers. Create refuses a populated server; Join receives existing contents. First use requires an empty test vault. An unmarked nonempty test vault opens a read-only inventory/difference preview; no marker is written and synchronization does not start. An explicitly marked existing test vault can be reviewed. This is not a one-click nonempty migration wizard.

Read-only inventory is limited to the current marked test vault. It reports Markdown/image/other counts, bytes, SHA256 for ordinary files (including unsupported PDF or canvas files), and normalization/case collisions. Hidden configuration and marker files are listed as excluded without reading their contents or hashing credentials. This UI is a preview only: it does not copy, upload, migrate, reset, or create a backup snapshot. A separate explicit test-only snapshot CLI is available below. Unsupported files remain in place; syncing all attachment types and production migration remain future work.

The native alpha.3 installation is unchanged by this source-only alpha.4 fix; old alpha.1 vault/state/server backups are retained. The public 0.3.0 release is unchanged. Alpha.4 requires its own compatible server for identity checks; do not point an alpha.4 candidate at the old native server and expect it to connect.

## Alpha.3 isolated snapshot and rollback tool

This standalone Node tool only accepts source directory names starting with Realtime-Lab-V2- and an explicit valid realtime-lab-v2.json test marker. It has no default real-vault path and was tested only against disposable synthetic directories. Never invoke it on production notes or credentials.

Commands (all targets must be NEW, existing destinations are refused):

    node src/snapshot-tool.mjs preview SOURCE_TEST_DIRECTORY
    node src/snapshot-tool.mjs create SOURCE_TEST_DIRECTORY NEW_Realtime-Lab-V2-Snapshot_DIRECTORY
    node src/snapshot-tool.mjs verify SNAPSHOT_DIRECTORY
    node src/snapshot-tool.mjs restore SNAPSHOT_DIRECTORY NEW_Realtime-Lab-V2-Restored_DIRECTORY

The actual basename of a snapshot must start with Realtime-Lab-V2-Snapshot-, and a restore destination with Realtime-Lab-V2-Restored-. Their parent directories must exist. Source/target overlaps, symlinks, traversal entries, existing targets, unexpected snapshot files and SHA256 mismatches are rejected. Payload copies use no-follow file opens, exclusive writes and hash verification. Restores never delete or replace an existing vault. No token or hidden .obsidian directory is copied; hidden content is only named in the exclusion list. Ordinary Markdown and all ordinary attachment formats, including unsupported PDF/canvas, are preserved byte for byte.

A partial snapshot is retained for inspection with no valid completed manifest and cannot be restored. Retry into a different new snapshot directory. There is no chunk-level resume. A partial restore also stays in its new directory and never modifies the source or other directories. Rollback means restoring snapshot bytes to a new isolated directory, not rewinding or deleting subsequent user changes in the original directory. SHA256 detects integrity changes against the manifest; it is not a signature protecting against an attacker who replaces both manifest and payload.

Synthetic tests cover preview cancellation with zero writes, source change preservation, same relative filenames in separate old/new directories, attachment byte equality, tamper rejection before destination creation, symlink/overlap/traversal rejection, existing-target refusal and an injected interruption followed by a successful fresh retry. Native and multi-device migration are not certified. This does not import a real vault, migrate a running service, or enable unsupported formats for live sync.

## Alpha.4 minimal Create reconnect fix (source only)

A successful verified welcome consumes Create intent in the active client and persists Join plus server identity/origin immediately, including when the room is still empty. Reconnect no longer repeats Create. Incoming frames are serialized while that persistence completes; no state upload precedes it. Failed first creation of a populated room is still rejected. Unknown/different server identity still stops before sending cached content. Tests include offline automatic reconnect, empty-room persistence, fresh plugin instance recovery without editing its mode, and frame ordering during persistence. No server changes, new features, release publication, deployment or native installation update accompany this fix.

Additional alpha.4 failure-injection coverage: failed identity persistence sends no state and does not bypass a later nonempty Create refusal. A deliberately dropped acknowledgement after durable acceptance reconnects in Join mode without duplicating history. This does not certify atomic settings persistence under an OS process kill; native crash acceptance remains outstanding.

## Alpha.5 release audit and storage-error guidance

The release builder strips only esbuild standalone module-path comments, preserving executable source and normal/legal comments without minification. A clean alternate-directory build must reproduce identical asset bytes. No source maps or private configuration are distributed.

If verified identity cannot be saved locally, the client displays the actual storage failure and asks the user to retain local content, check disk space/permissions, and click Connect again. It stops automatic retry and sends no cached state. Ordinary transient network reconnects update the status bar, not repeated popup dialogs. This change does not establish OS-kill-safe atomic Obsidian settings storage or remove the documented 200 ms state-save window.

BRAT publication guard: marking a GitHub release as non-Latest does not isolate it from BRAT latest-by-semver selection. Before publishing V2 in the same repository, old 0.3.0 installations must be verified frozen/pinned with relevant automatic updates disabled; otherwise seek explicit authorization for a separate V2 repository. New test installations must pin the exact candidate version. Nothing has been published by this candidate.

Capacity is unchanged: <=1000 tracked paths including tombstones. 1000 Markdown plus 20 attachments exceeds the limit and is rejected. A separate software-only reduced batch exercise at 900 notes plus 20 attachments is not proof of 20 MiB load, native per-file import speed, or iPhone memory performance.

## Alpha.6 bounded browser codec and optional persistence

Base64 encoding uses 8192-byte argument chunks and joins bounded chunks before btoa. Decoding allocates one output Uint8Array and fills it with charCodeAt, avoiding Uint8Array.from over a string iterator. The exact same implementation runs on iOS and Node; there is no Node-only Buffer optimization. Full binary strings and output buffers still exist, so this is not zero-copy or streaming attachment transfer.

Both clients skip full-document snapshot encoding when onPersist was omitted. Explicit callbacks, including the native plugin callback, still receive complete snapshots on every update with the existing plugin debounce. Network updates, identity checks, conflict handling, protocol and all resource limits are unchanged. Codec tests cover empty input, 8192-byte boundaries, nonzero views and multi-MiB byte equality against an independent test oracle; they also run without a global Node Buffer.

Prior alpha.5 12 MiB combined server-plus-two-client benchmark hit V8 heap OOM at its 768 MiB heap budget. This alpha.6 candidate requires the same benchmark and budget to be rerun; unit success does not mean that load or iPhone now passes. Full-document cloning/persistence and duplicate attachment state remain architectural memory costs.
