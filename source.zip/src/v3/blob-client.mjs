import {MAX_BLOB_BYTES} from './limits.mjs';
import {CHUNK_BYTES,hashSource} from './sha256.mjs';
async function boundedBytes(r,limit){const out=new Uint8Array(limit);let n=0;if(!r.body)throw Error('Missing response body');const reader=r.body.getReader();try{while(true){const v=await reader.read();if(v.done)break;if(n+v.value.length>limit){await reader.cancel();throw Error('Response frame exceeds limit');}out.set(v.value,n);n+=v.value.length;}return out.subarray(0,n);}finally{reader.releaseLock();}}
const boundedJson=async r=>JSON.parse(new TextDecoder().decode(await boundedBytes(r,1024)));
function checkRef(ref){if(!ref||!/^[a-f0-9]{64}$/.test(ref.hash)||!Number.isSafeInteger(ref.size)||ref.size<0||ref.size>MAX_BLOB_BYTES)throw Error('Invalid blob reference');}
function checkStatus(s,size){if(typeof s.complete!=='boolean'||s.size!==size||!Number.isSafeInteger(s.offset)||s.offset<0||s.offset>size||s.complete&&s.offset!==size||!s.complete&&s.offset%CHUNK_BYTES)throw Error('Invalid upload status');return s;}
// All calls share one transfer lane. A second concurrent transfer is rejected,
// never queued with a retained file buffer. Caller reopens sources on retry.
export class BlobTransfer{
 constructor({url,token,fetchImpl=globalThis.fetch,serverId,onIdentity=async()=>{},verifyIdentity}){Object.assign(this,{url:url.replace(/\/$/,''),token,fetch:fetchImpl,serverId,onIdentity,verifyIdentity});this.busy=false;}
 async identity(signal){if(!this.serverId&&!this.verifyIdentity)throw Error('Verified metadata identity required');const expected=this.verifyIdentity?await this.verifyIdentity(signal):this.serverId;const r=await this.fetch(this.url+'/v3/identity',{signal,headers:{Authorization:'Bearer '+this.token}});if(!r.ok)throw Error('Identity request failed ('+r.status+')');const m=await boundedJson(r);if(m.protocol!==3||!m.serverId||m.serverId!==expected||this.serverId&&m.serverId!==this.serverId)throw Error('Server identity mismatch before blob transfer');if(!this.serverId){await this.onIdentity(m.serverId);this.serverId=m.serverId;}}
 async call(hash,query,options={}){if(!/^[a-f0-9]{64}$/.test(hash))throw Error('Invalid blob hash');const r=await this.fetch(`${this.url}/v3/blobs/${hash}?${new URLSearchParams(query)}`,{...options,headers:{Authorization:'Bearer '+this.token,...options.headers}});if(!r.ok)throw Error('Blob request failed ('+r.status+')');return r;}
 async upload(source,{signal,onProgress=()=>{}}={}){if(this.busy)throw Error('Transfer busy');this.busy=true;try{await this.identity(signal);if(!Number.isSafeInteger(source.size)||source.size<0||source.size>MAX_BLOB_BYTES)throw Error('Blob exceeds 16 MiB or invalid size');const hash=await hashSource(source,signal);let s=await boundedJson(await this.call(hash,{status:'1',size:source.size},{signal}));checkStatus(s,source.size);while(!s.complete){signal?.throwIfAborted();const offset=s.offset,n=Math.min(CHUNK_BYTES,source.size-offset),bytes=await source.read(offset,n);if(!(bytes instanceof Uint8Array)||bytes.length!==n)throw Error('Source changed');s=await boundedJson(await this.call(hash,{size:source.size,offset},{method:'PUT',body:bytes,signal}));checkStatus(s,source.size);if(s.offset!==offset+n)throw Error('Invalid upload acknowledgement');onProgress(s.offset);}return {hash,size:source.size};}finally{this.busy=false;}}
 async download(ref,sink,{signal,onProgress=()=>{}}={}){if(this.busy)throw Error('Transfer busy');this.busy=true;
 const pending=new Map();
 try{checkRef(ref);await this.identity(signal);
  // Non-empty GETs read committed blobs only. Exact frame lengths plus the final
  // content hash replace the redundant status round trip; empty blobs need status.
  if(!ref.size){const s=checkStatus(await boundedJson(await this.call(ref.hash,{status:'1',size:0},{signal})),0);if(!s.complete)throw Error('Remote blob incomplete');}
  let offset=await sink.length();if(!Number.isSafeInteger(offset)||offset<0||offset>ref.size||offset!==ref.size&&offset%CHUNK_BYTES)throw Error('Invalid destination length');
  let next=offset;
  const fill=()=>{while(pending.size<2&&next<ref.size){signal?.throwIfAborted();const p=next;next+=CHUNK_BYTES;
   // Capture errors immediately: a later prefetched frame may fail first.
   pending.set(p,(async()=>{try{const r=await this.call(ref.hash,{offset:p},{signal}),bytes=await boundedBytes(r,CHUNK_BYTES);if(bytes.length!==Math.min(CHUNK_BYTES,ref.size-p))throw Error('Short download frame');return {bytes};}catch(error){return {error};}})());
  }};
  fill();while(offset<ref.size){signal?.throwIfAborted();const result=await pending.get(offset);if(result.error)throw result.error;signal?.throwIfAborted();await sink.write(offset,result.bytes);pending.delete(offset);offset+=result.bytes.length;onProgress(offset);fill();}
  if(await hashSource({size:ref.size,read:(p,n)=>sink.read(p,n)},signal)!==ref.hash)throw Error('Downloaded blob hash mismatch; discard partial and retry');await sink.commit?.(ref);return ref;
 }finally{await Promise.all(pending.values());this.busy=false;}}
}
