import * as Y from 'yjs';
import {encode} from '../client.mjs';
import {FILE_REFS_CAPABILITY,MAX_BINARY,MAX_FILE_TEXT} from './limits.mjs';
import {VaultClient} from '../vault-client.mjs';
import {BlobTransfer} from './blob-client.mjs';
import {put,remove,content,supported} from './model.mjs';
import {changedPaths} from './sync-progress.mjs';
export class VaultClientV3 extends VaultClient{
 constructor(options){super({...options,room:'realtime-lab-v3',expectedProtocol:3,capabilities:[FILE_REFS_CAPABILITY],beforeUpload:async()=>{await options.beforeUpload?.();if(this.pending.length){if(!this.blobCache)throw Error('Pending file cache required');for(const p of this.pending)await this.putFile(p.path,this.blobCache.source(p),{version:p.version,preserveDeleted:true});}},maxBufferedBytes:4*1024*1024,maxInboxBytes:8*1024*1024});this.blobs=new BlobTransfer({url:options.url.replace(/^ws/,'http'),token:options.token,fetchImpl:options.fetchImpl,verifyIdentity:async()=>{if((!this.ready&&!this.metadataVerified)||!this.serverId)throw Error('Connect verified V3 metadata before transferring blobs');return this.serverId;}});this.blobCache=options.blobCache;this.onPending=options.onPending;this.pending=options.pending?.items||[];if(options.pending&&(options.pending.protocol!==3||options.pending.serverId!==this.serverId||!this.serverId))throw Error('Pending uploads require matching verified server identity');if(this.pending.length>3000)throw Error('Pending reference limit');for(const p of this.pending)this.checkPending(p);this.binaryBusy=false;this.binaryAbort=new AbortController();
 this.onSyncState=options.onSyncState||(()=>{});this.onOutbox=options.onOutbox;this.localSequence=0;this.localOutbox=new Map();
 const restored=options.outbox??(options.state?['*']:[]);if(!Array.isArray(restored)||restored.length>8192||restored.some(p=>p!=='*'&&!supported(p)))throw Error('Invalid local outbox');
 for(const p of restored)this.localOutbox.set(p,++this.localSequence);
 const status=this.onStatus;this.onStatus=s=>{this.syncStatus=s;if(/错误|失败|拒绝|阻止|暂停/.test(s))this.lastError=s;status(s);this.onSyncState();};
 const ready=this.onReady;this.onReady=()=>{ready();this.queueConfirmation();};
 this.progressListener=tx=>{if(tx.origin==='remote')return;const paths=changedPaths(this.doc,tx);if(!paths.length)return;for(const p of paths)this.localOutbox.set(p,++this.localSequence);this.onSyncState();this.queueConfirmation();};this.doc.on('afterTransaction',this.progressListener);
 }
 // iOS can retain an OPEN WebSocket after its network connection is gone.
 // Keep the Y.Doc, verified identity and pending blobs; replace only transport.
 resume(){
  if(this.stopped||this.transportBlocked)return false;
  clearTimeout(this.timer);this.timer=undefined;const old=this.ws;
  this.ws=undefined;this.ready=false;this.metadataVerified=false;
  for(const r of this.requests.values()){clearTimeout(r.timer);r.reject(Error('Foreground reconnect; local edits retained'));}this.requests.clear();
  if(old){old.onopen=null;old.onmessage=null;old.onerror=null;old.onclose=null;try{old.close();}catch{}}
  this.connect();return true;
 }
 queueConfirmation(){clearTimeout(this.confirmTimer);if(this.ready&&!this.stopped)this.confirmTimer=setTimeout(()=>void this.confirmUploads().catch(()=>{}),250);}
 async confirmUploads(){
  if(!this.ready||this.stopped||this.transportBlocked||this.metadataBatch)return false;
  if(this.confirmation)return this.confirmation;
  const ws=this.ws,boundary=this.localSequence;
  this.confirmation=(async()=>{
   await this.request('barrier');if(this.ws!==ws||!this.ready||this.stopped)return false;
   if(this.persistence.persist&&(this.localOutbox.size||this.persistence.dirty||this.persistence.inFlight)){this.flushPersist(!!this.localOutbox.size);if(!await this.persistence.wait())throw Error('Local snapshot save failed; outbox retained');}
   const cleared=[];for(const [p,n] of this.localOutbox)if(n<=boundary){cleared.push([p,n]);this.localOutbox.delete(p);}
   try{if(cleared.length)await this.onOutbox?.([...this.localOutbox.keys()]);}catch(e){for(const [p,n] of cleared)if(!this.localOutbox.has(p))this.localOutbox.set(p,n);throw e;}
   this.lastConfirmedAt=Date.now();this.lastError='';this.onSyncState();return true;
  })().catch(e=>{this.lastError=String(e.message||e);this.onSyncState();if(this.ws===ws&&!this.stopped&&!this.transportBlocked&&this.lastError!=='Local snapshot save failed; outbox retained')this.resume();return false;}).finally(()=>{this.confirmation=null;if(this.localSequence>boundary)this.queueConfirmation();});
  return this.confirmation;
 }
 async checkConnection(){return this.confirmUploads();}
 get pendingPaths(){return [...this.localOutbox.keys()];}
 async batchFiles(fn){if(this.metadataBatch)throw Error('Metadata batch already active');const vector=Y.encodeStateVector(this.doc);this.metadataBatch=true;try{return await fn();}finally{this.metadataBatch=false;if(this.ready&&!this.stopped)this.send({type:'update',update:encode(Y.encodeStateAsUpdate(this.doc,vector))});this.queueConfirmation();}}
 checkPending(p){if(!p||!p.version||!/^[a-f0-9-]{36}$/.test(p.version)||!supported(p.path)||!/^[a-f0-9]{64}$/.test(p.hash)||!Number.isSafeInteger(p.size)||p.size<0||p.size>(/\.md$/i.test(p.path)?MAX_FILE_TEXT:MAX_BINARY))throw Error('Invalid pending image reference');}
 async putFile(path,source,options){if(!supported(path)||source.size>(/\.md$/i.test(path)?MAX_FILE_TEXT:MAX_BINARY))throw Error('Unsupported file or per-type size limit');const ref=await this.blobs.upload(source,{signal:this.binaryAbort.signal,...options});if(this.stopped)throw Error('Client closed; cached source retained');this.doc.transact(()=>{const deleted=options?.preserveDeleted&&this.doc.getMap('deleted').has(path);put(this.doc,path,{kind:/\.md$|\.pdf$/i.test(path)?'file':'image',...ref,...(options?.version?{version:options.version}:{})});if(deleted)remove(this.doc,path);});return ref;}
 async downloadFile(path,sink,options){const ref=content(this.doc,path);if(!ref||ref.kind==='text')throw Error('Versioned file missing');return this.blobs.download(ref,sink,{signal:this.binaryAbort.signal,...options});}
 async putImage(path,source,options){if(/\.md$|\.pdf$/i.test(path))throw Error('Image path required');return this.putFile(path,source,options);}
 async downloadImage(path,sink,options){return this.downloadFile(path,sink,options);}
 async stageImage(path,source,options){if(/\.md$|\.pdf$/i.test(path))throw Error('Image path required');return this.stageFile(path,source,options);}
 // Offline staging needs an immutable durable cache plus explicit persisted
 // pending manifest. Only refs enter that manifest; never source byte buffers.
 async stageFile(path,source,options){if(this.binaryBusy)throw Error('Binary operation busy');if(!this.serverId||!this.blobCache||!this.onPending)throw Error('Verified identity, durable blob cache and pending persistence required');if(!supported(path)||source.size>(/\.md$/i.test(path)?MAX_FILE_TEXT:MAX_BINARY))throw Error('Unsupported file or per-type size limit');if(this.pending.length>=3000)throw Error('Pending reference limit');this.binaryBusy=true;try{const ref=await this.blobCache.stage(source,{signal:this.binaryAbort.signal,...options}),item={path,...ref,version:crypto.randomUUID()},previous=[...this.pending].reverse().find(p=>p.path===path);if(previous?.hash===ref.hash&&previous?.size===ref.size)return ref;const next=[...this.pending,item];await this.onPending({protocol:3,serverId:this.serverId,items:next});this.pending=next;this.onSyncState();return ref;}finally{this.binaryBusy=false;}}
 async flushPending(options){if(this.binaryBusy)throw Error('Binary operation busy');if(!this.blobCache||!this.onPending||!this.ready)throw Error('Connect before resuming cached uploads');this.binaryBusy=true;try{while(this.pending.length){const p=this.pending[0];await this.putFile(p.path,this.blobCache.source(p),{...options,version:p.version,preserveDeleted:true});await this.request('barrier');this.flushPersist(true);if(!this.persistence.persist||!await this.persistence.wait())throw Error('Save metadata snapshot before removing pending reference');const next=this.pending.slice(1);await this.onPending({protocol:3,serverId:this.serverId,items:next});this.pending=next;this.onSyncState();}}finally{this.binaryBusy=false;}}
 close(){clearTimeout(this.confirmTimer);this.doc.off('afterTransaction',this.progressListener);this.binaryAbort.abort();return super.close();}
}
