import {CHUNK_BYTES} from './sha256.mjs';
// Obsidian native HTTP bridge avoids WebView CORS dependence. requestUrl has no
// cancellation API: on abort, at most two in-flight 32 KiB download requests finish;
// the caller stops before scheduling another and can resume its durable offset.
export function requestFetch(requestUrl){return async(url,options={})=>{options.signal?.throwIfAborted();const body=options.body;if(body&&(!(body instanceof Uint8Array)||body.length>CHUNK_BYTES))throw Error('Native request frame exceeds 32 KiB');const r=await requestUrl({url:String(url),method:options.method||'GET',headers:{...options.headers,...(body?{'Content-Type':'application/octet-stream'}:{})},body:body?body.slice().buffer:undefined,throw:false});options.signal?.throwIfAborted();if(r.arrayBuffer.byteLength>CHUNK_BYTES)throw Error('Native response frame exceeds 32 KiB');return new Response(r.status===204?null:r.arrayBuffer,{status:r.status,headers:r.headers});};}
