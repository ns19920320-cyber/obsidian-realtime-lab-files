// Only retry recognisable transport failures. Authentication, identity, quota,
// invalid data and local persistence failures still require explicit handling.
export function transientTransferFailure(error){
 const s=String(error?.message||error);
 if(/身份|identity mismatch|认证|401|403|quota|capacity|容量|快照|snapshot|persist|storage|磁盘|本地保存|invalid|unsupported/i.test(s))return false;
 return /failed to fetch|fetch failed|load failed|network|网络|ECONN|ENOTFOUND|ETIMEDOUT|disconnected|request timeout|request failed \((?:408|429|5\d\d)\)/i.test(s);
}
