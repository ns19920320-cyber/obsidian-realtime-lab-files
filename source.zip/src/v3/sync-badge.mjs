export function badgeState({ready=false,preparing=false,receiving=false,connecting=false,error=false,confirmed=false,uploads=0,downloads=0,unknown=false,known=0}){
 let tone='offline',icon='cloud-off',label='离线',busy=false;
 if(error){tone='error';icon='alert-circle';label='需处理';}
 else if(!ready&&connecting){tone='busy';icon='refresh-cw';label='连接中';busy=true;}
 else if(ready&&(preparing||receiving||uploads||downloads||unknown)){tone='busy';icon='refresh-cw';label=preparing?'准备中':receiving?'接收中':'同步中';busy=true;}
 else if(ready&&!confirmed){tone='waiting';icon='clock';label='待确认';}
 else if(ready){tone='confirmed';icon='check';label='已确认';}
 const counts='↑'+(unknown?'?':uploads)+' ↓'+downloads;
 const display='Sync: '+(tone==='confirmed'?'⚡':tone==='busy'?'↻':tone==='waiting'?'◷':tone==='error'?'⚠ 异常':'○ 离线');
 return {tone,icon,label,display,busy,counts,description:label+'；库内'+known+'个路径；待上传或确认'+(unknown?'数量待核对':uploads)+'；当前接收'+downloads+'。点击查看同步详情。服务器确认不等于其他设备已收到。'};
}
export const badgeCSS=`
.rl-sync-row{display:flex;justify-content:flex-end;flex:0 0 auto;min-height:25px;padding:0 18px 3px;background:var(--background-primary);z-index:1}
.rl-sync-row .rl-sync-badge{display:inline-flex;align-items:center;gap:7px;width:max-content;max-width:100%;min-height:24px;padding:0;border:0;border-radius:0;background:transparent;color:var(--text-muted);font-size:12px;font-weight:400;line-height:24px;white-space:nowrap;cursor:pointer;box-shadow:none;font-variant-numeric:tabular-nums}
.rl-sync-badge .rl-sync-icon{display:none}
.rl-sync-badge .rl-sync-label,.rl-sync-badge .rl-sync-counts{white-space:nowrap}
.rl-sync-badge[data-tone=error]{color:var(--text-error)}
.rl-sync-badge:hover{color:var(--text-normal)}
.rl-sync-badge:focus-visible{outline:2px solid var(--interactive-accent);outline-offset:3px}
body.is-mobile .rl-sync-row{padding:0 20px 2px;min-height:28px}
body.is-mobile .rl-sync-row .rl-sync-badge{font-size:12px;min-height:28px;line-height:28px}
.rl-sync-details-note{color:var(--text-muted);font-size:var(--font-ui-small);line-height:1.6}
`;
