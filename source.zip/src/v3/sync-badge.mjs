export function badgeState({ready=false,preparing=false,receiving=false,connecting=false,error=false,confirmed=false,uploads=0,downloads=0,unknown=false,known=0}){
 let tone='offline',icon='cloud-off',label='离线',busy=false;
 if(error){tone='error';icon='alert-circle';label='需处理';}
 else if(!ready&&connecting){tone='busy';icon='refresh-cw';label='连接中';busy=true;}
 else if(ready&&(preparing||receiving||uploads||downloads||unknown)){tone='busy';icon='refresh-cw';label=preparing?'准备中':receiving?'接收中':'同步中';busy=true;}
 else if(ready&&!confirmed){tone='waiting';icon='clock';label='待确认';}
 else if(ready){tone='confirmed';icon='check';label='已确认';}
 const counts=tone==='confirmed'?known+'项':(uploads||downloads||unknown?'↑'+(unknown?'?':uploads)+' ↓'+downloads:'');
 return {tone,icon,label,busy,counts,description:label+'；库内'+known+'个路径；待上传或确认'+(unknown?'数量待核对':uploads)+'；当前接收'+downloads+'。点击查看同步详情。服务器确认不等于其他设备已收到。'};
}
export const badgeCSS=`
.view-header .rl-sync-badge{display:inline-flex!important;align-items:center;gap:5px;width:auto;height:auto;flex-shrink:0;max-width:190px;min-height:28px;margin-inline-end:5px;padding:4px 9px;border:1px solid var(--background-modifier-border);border-radius:999px;background:var(--background-secondary);color:var(--text-muted);font-size:11px;font-weight:550;line-height:1.2;white-space:nowrap;cursor:pointer;box-shadow:0 1px 2px rgb(0 0 0 / 3%);transition:background .15s,border-color .15s}
.rl-sync-badge .rl-sync-icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}
.rl-sync-badge .rl-sync-icon svg{width:14px;height:14px;stroke-width:1.8}
.rl-sync-badge .rl-sync-label{overflow:hidden;text-overflow:ellipsis}
.rl-sync-badge .rl-sync-counts{padding-inline-start:5px;border-inline-start:1px solid var(--background-modifier-border);color:var(--text-muted);font-size:10px;font-variant-numeric:tabular-nums;letter-spacing:.2px}
.view-header .rl-sync-badge[data-tone=confirmed]{color:var(--color-green,#38966d);background:color-mix(in srgb,var(--color-green,#38966d) 7%,var(--background-primary))}
.view-header .rl-sync-badge[data-tone=busy]{color:var(--interactive-accent);background:color-mix(in srgb,var(--interactive-accent) 7%,var(--background-primary))}
.view-header .rl-sync-badge[data-tone=error]{color:var(--text-error);background:color-mix(in srgb,var(--text-error) 7%,var(--background-primary))}
.view-header .rl-sync-badge:hover{border-color:var(--interactive-accent);background:var(--background-modifier-hover)}
.view-header .rl-sync-badge:focus-visible{outline:2px solid var(--interactive-accent);outline-offset:2px}
.rl-sync-badge[data-busy=true] .rl-sync-icon svg{animation:rl-sync-spin 1.5s linear infinite}
body.is-mobile .view-header .rl-sync-badge{min-height:32px;padding:5px 8px;gap:4px;margin-inline-end:3px;max-width:170px}
.rl-sync-details-note{color:var(--text-muted);font-size:var(--font-ui-small);line-height:1.6}
@keyframes rl-sync-spin{to{transform:rotate(360deg)}}
@media(prefers-reduced-motion:reduce){.rl-sync-badge .rl-sync-icon svg{animation:none!important}.view-header .rl-sync-badge{transition:none}}
`;
