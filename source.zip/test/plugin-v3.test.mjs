import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {build} from 'esbuild';
import WebSocket from 'ws';
import {createVaultServerV3} from '../src/v3/server.mjs';
import {VaultClientV3} from '../src/v3/client.mjs';
import {put,content,remove} from '../src/v3/model.mjs';
const mock=`export const Platform={isMacOS:true};export class Plugin {registerEvent(){} registerInterval(id){id.unref?.()} registerDomEvent(target,event,cb){(this.domEvents??={})[event]=cb} addCommand(){} addSettingTab(){} addStatusBarItem(){return {setText(){}}} async loadData(){return null} async saveData(s){this.saved=structuredClone(s)}} export class TFile{constructor(path,size=0){this.path=path;this.stat={size}}} export const setIcon=(el,name)=>el.setAttribute("data-icon",name); export class MarkdownView{} export class App{} export class Modal{} export class Notice{constructor(s){}} export class Setting{} export class PluginSettingTab{constructor(app){this.app=app}} export const normalizePath=p=>p; export async function requestUrl(o){const r=await fetch(o.url,{method:o.method,headers:o.headers,body:o.body});return {status:r.status,headers:Object.fromEntries(r.headers),arrayBuffer:await r.arrayBuffer()}};`;
const output=new URL('./.plugin-v3-under-test.mjs',import.meta.url);
globalThis.WebSocket=WebSocket;globalThis.window=globalThis;
const wait=async f=>{for(let i=0;i<300;i++){if(f())return;await new Promise(r=>setTimeout(r,10));}throw Error('Timeout');};
function vault(){const data=new Map(),files=new Map(),folders=new Set(),events={};let writes=0,binaryReads=0,maxChunk=0;const v={getName:()=> 'Realtime-Lab-V3-Files-Integration',getFiles:()=>[...files.values()],getAbstractFileByPath:p=>files.get(p)||(folders.has(p)?{path:p}:null),on:(event,cb)=>{(events[event]??=[]).push(cb);return {};},adapter:{stat:async p=>({size:typeof data.get(p)==='string'?new TextEncoder().encode(data.get(p)).length:data.get(p)?.byteLength||0}),list:async p=>({files:[...data.keys()].filter(k=>k.startsWith(p+'/')&&!k.slice(p.length+1).includes('/')),folders:[...folders].filter(k=>k.startsWith(p+'/')&&!k.slice(p.length+1).includes('/'))}),exists:async p=>data.has(p)||folders.has(p),mkdir:async p=>{folders.add(p)},read:async p=>{if(p==='realtime-lab-v3-files.json')return '{"isolatedLab":true,"protocol":3,"capability":"versioned-files-v1"}';return data.get(p);},write:async(p,s)=>{data.set(p,s);writes++;},writeBinary:async(p,s)=>{data.set(p,s);writes++;},readBinary:async p=>{const b=data.get(p);maxChunk=Math.max(maxChunk,b.byteLength);return b;}},read:async f=>data.get(f.path),readBinary:async f=>{binaryReads++;const d=data.get(f.path);return typeof d==='string'?new TextEncoder().encode(d).buffer:d},createFolder:async p=>{folders.add(p)},async create(p,s){const f={path:p,stat:{size:s.length??s.byteLength}};Object.setPrototypeOf(f,fileProto);files.set(p,f);data.set(p,s);for(const cb of events.create||[])cb(f);writes++;return f;},async createBinary(p,s){return this.create(p,s)},async modify(f,s){data.set(f.path,s);f.stat.size=s.length??s.byteLength;for(const cb of events.modify||[])cb(f);writes++;},async modifyBinary(f,s){return this.modify(f,s)},async rename(f,next){const old=f.path;const moved=[...files.values()].filter(x=>x.path===old||x.path.startsWith(old+'/'));for(const x of moved){const from=x.path,to=next+from.slice(old.length),value=data.get(from);files.delete(from);data.delete(from);x.path=to;files.set(to,x);data.set(to,value);}f.path=next;for(const cb of events.rename||[])cb(f,old);},async trash(f){for(const key of [...files.keys()])if(key===f.path||key.startsWith(f.path+'/')){files.delete(key);data.delete(key);}for(const cb of events.delete||[])cb(f);writes++;}};return {v,data,files,get writes(){return writes},get binaryReads(){return binaryReads},get maxChunk(){return maxChunk}};}
const source=fs.readFileSync(new URL('../src/v3/plugin.ts',import.meta.url),'utf8')+'\nexport {TFile,MarkdownView};';
await build({stdin:{contents:source,loader:'ts',resolveDir:new URL('../src/v3',import.meta.url).pathname},outfile:output.pathname,bundle:true,platform:'node',format:'esm',packages:'external',plugins:[{name:'stub',setup(b){b.onResolve({filter:/^obsidian$/},()=>({path:'mock',namespace:'stub'}));b.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:mock,loader:'js'}));}}]});
const bundle=await import(output.href+'?bridge');fs.unlinkSync(output);const fileProto=bundle.TFile.prototype;globalThis.document={hidden:false};
const bytesSource=b=>({size:b.length,read:async(p,n)=>b.subarray(p,p+n)});
async function env(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'v3-plugin-')),token='synthetic-native-v3-'.repeat(3),server=await createVaultServerV3({dir,token}),other=new VaultClientV3({url:'ws://127.0.0.1:'+server.port,token,WebSocketImpl:WebSocket}),mem=vault(),p=new bundle.default();p.app={vault:mem.v,plugins:{enabledPlugins:new Set()},workspace:{events:{},on(event,cb){this.events[event]=cb;return {};},onLayoutReady(cb){this.layoutReady=cb;},getLeavesOfType:()=>[]}};await p.onload();p.settings.url=other.url;p.settings.token=token;t.after(async()=>{await p.stop();await other.close();await p.queue;await server.close();fs.rmSync(dir,{recursive:true,force:true});});other.connect();await wait(()=>other.ready);return {p,other,mem,server};}
test('V3 plugin adapter receives image via chunk cache and text updates do not reread original binary',async t=>{const {p,other,mem}=await env(t);const bytes=new Uint8Array(32768*3+7).fill(61),ref=await other.putImage('图片/手机.png',bytesSource(bytes));put(other.doc,'文字.md',{kind:'text',data:'first'});await p.start();await wait(()=>mem.files.has('图片/手机.png')&&mem.data.get('文字.md')==='first');assert.deepEqual(new Uint8Array(mem.data.get('图片/手机.png')),bytes);const reads=mem.binaryReads;for(let i=0;i<5;i++){put(other.doc,'文字.md',{kind:'text',data:'文字'+i});await wait(()=>mem.data.get('文字.md')==='文字'+i);}assert.equal(mem.binaryReads,reads);assert(mem.maxChunk<=32768);assert.equal(content(p.client.doc,'图片/手机.png').hash,ref.hash);assert(p.saved.protocol===3);});
test('V3 plugin reads local source once, uploads refs and keeps binary out of settings',async t=>{const {p,other,mem,server}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce);const bytes=new Uint8Array(32768*2+9).fill(47),before=mem.binaryReads;await mem.v.createBinary('电脑.png',bytes.buffer);await wait(()=>content(other.doc,'电脑.png'));assert.equal(mem.binaryReads-before,1);await p.stop();assert(p.saved.state.length<5000);assert(!p.saved.state.includes('Ly8vLy8v'));assert(server.blobs.has(content(other.doc,'电脑.png').hash,bytes.length));assert(mem.maxChunk<=32768);});
test('V3 plugin backs up binary before remote deletion and excludes private cache paths',async t=>{const {p,other,mem,server}=await env(t);const bytes=new Uint8Array([1,3,5,7]);await other.putImage('恢复.png',bytesSource(bytes));await p.start();await wait(()=>mem.files.has('恢复.png'));remove(other.doc,'恢复.png');await wait(()=>!mem.files.has('恢复.png'));assert([...mem.data].some(([k,v])=>k.startsWith('.realtime-lab-v3-recovery/')&&v instanceof ArrayBuffer&&new Uint8Array(v).length===4));assert([...server.doc.getMap('files').keys()].every(k=>!k.startsWith('.')));});
test('V3 plugin refuses legacy settings and V2 markers; explicit rejected-settings backup preserves old state',async t=>{const {p,mem}=await env(t);const old={state:'old-encoded-state',token:'synthetic-legacy-only',url:'ws://127.0.0.1:1'};p.legacyConfig=old;await p.start();assert.equal(p.client,null);await assert.rejects(p.persistConfig(),/拒绝覆盖/);await p.backupRejectedState();assert.equal(p.legacyConfig,null);assert.equal(p.saved.protocol,3);assert([...mem.data].some(([k,v])=>k.includes('rejected-old-settings')&&JSON.parse(v).state===old.state));mem.data.set('realtime-lab-v2.json','{"isolatedLab":true,"protocol":2}');assert.equal(await p.allowed(),false);await p.start();assert.equal(p.client,null);});
test('mobile-compatible chunk cache survives reopen with partial progress and checks quota before writing',async()=>{const {ObsidianBlobCache}=await import('../src/v3/obsidian-cache.mjs'),{hashSource}=await import('../src/v3/sha256.mjs'),m=vault(),b=new Uint8Array(32768*2+7).fill(17),ref={hash:await hashSource(bytesSource(b)),size:b.length};let cache=new ObsidianBlobCache(m.v.adapter);await cache.sink(ref).write(0,b.subarray(0,32768));cache=new ObsidianBlobCache(m.v.adapter);assert.equal(await cache.sink(ref).length(),32768);await cache.sink(ref).write(32768,b.subarray(32768,65536));await cache.sink(ref).write(65536,b.subarray(65536));await cache.sink(ref).commit();assert.deepEqual(new Uint8Array(await cache.materialize(ref)),b);assert(m.maxChunk<=32768);m.data.set('.realtime-lab-v3-cache/quota/state.json',JSON.stringify({size:5*1024*1024}));for(let i=0;i<52;i++){await m.v.adapter.mkdir('.realtime-lab-v3-cache/quota'+i);m.data.set('.realtime-lab-v3-cache/quota'+i+'/state.json',JSON.stringify({size:5*1024*1024}));}await assert.rejects(cache.stage(bytesSource(new Uint8Array([1]))),/quota/);});
test('V3 plugin cold restart publishes offline image edits from private chunk cache',async t=>{const {p,mem,other,server}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce);const f=await mem.v.createBinary('重启.png',new Uint8Array([1,2,3]).buffer);await wait(()=>content(other.doc,'重启.png'));p.client.stopped=true;p.client.ws.close();await wait(()=>!p.client.ready);await mem.v.modifyBinary(f,new Uint8Array([4,5,6]).buffer);await p.queue;assert(p.settings.pending?.items.length);await p.stop();const next=new bundle.default();next.app=p.app;await next.onload();next.settings=structuredClone(p.saved);t.after(async()=>{await next.stop();await next.queue;});await next.start();await wait(()=>next.client?.ready&&next.syncedOnce&&next.settings.pending.items.length===0);const ref=content(other.doc,'重启.png');await wait(()=>content(server.doc,'重启.png')?.hash===content(next.client.doc,'重启.png')?.hash);assert.deepEqual([...server.blobs.read(content(server.doc,'重启.png').hash,0)],[4,5,6]);assert([...mem.data.keys()].some(k=>k.startsWith('.realtime-lab-v3-cache/')));});
test('V3 plugin missing pending-only image asks explicit deletion direction before restart publication',async t=>{const {p,mem,other,server}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce);p.client.stopped=true;p.client.ws.close();await wait(()=>!p.client.ready);const f=await mem.v.createBinary('待传删除.png',new Uint8Array([8,7,6]).buffer);await p.queue;assert(p.settings.pending?.items.length);await p.stop();mem.files.delete(f.path);mem.data.delete(f.path);const next=new bundle.default();next.app=p.app;await next.onload();next.settings=structuredClone(p.saved);let asked=false;next.resolveMissing=async paths=>{asked=true;assert(paths.includes(f.path));return 'delete';};t.after(async()=>{await next.stop();await next.queue;});await next.start();await wait(()=>next.client?.ready&&next.syncedOnce);assert(asked);assert.equal(content(server.doc,f.path),null);assert.equal(mem.files.has(f.path),false);assert.equal(next.settings.pending.items.length,0);});
test('Files plugin uses whole-file mode for ordinary Markdown and PDF while retaining inline test-note policy',async t=>{const {p,mem,other}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce);await mem.v.create('普通.md','整文件文字');await wait(()=>content(other.doc,'普通.md')?.kind==='file');assert.equal(other.doc.getText('text:普通.md').length,0);await mem.v.createBinary('附件.pdf',new TextEncoder().encode('%PDF synthetic').buffer);await wait(()=>content(other.doc,'附件.pdf')?.kind==='file');await mem.v.create('实时协作测试.md','逐字协作');await wait(()=>content(other.doc,'实时协作测试.md')?.kind==='text');assert.equal(content(other.doc,'实时协作测试.md').data,'逐字协作');});
test('Files plugin reflects whole-file Markdown and backs up its previous bytes before replacement',async t=>{const {p,mem,other}=await env(t),a=new TextEncoder().encode('整篇第一版'),b=new TextEncoder().encode('整篇第二版');await other.putFile('整篇.md',bytesSource(a));await p.start();await wait(()=>mem.data.get('整篇.md')==='整篇第一版');await other.putFile('整篇.md',bytesSource(b));await wait(()=>mem.data.get('整篇.md')==='整篇第二版');assert([...mem.data].some(([k,v])=>k.startsWith('.realtime-lab-v3-recovery/')&&v instanceof ArrayBuffer&&new TextDecoder().decode(v)==='整篇第一版'));});
test('Files plugin coalesces repeated file events while an upload is blocked instead of queuing one read per event',async t=>{const {p,mem,other}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce);let release,entered=false;const original=p.upload.bind(p),gate=new Promise(r=>release=r);p.upload=async f=>{if(!entered){entered=true;await gate;}return original(f);};t.after(()=>release?.());const f=await mem.v.create('连续.md','v0');await wait(()=>entered);const before=mem.binaryReads;for(let i=1;i<=100;i++)await mem.v.modify(f,'v'+i);assert.equal(p.dirtyFiles.size,1);release();await wait(()=>content(other.doc,'连续.md')?.kind==='file'&&p.dirtyFiles.size===0);await p.queue;assert(mem.binaryReads-before<=2);const ref=content(other.doc,'连续.md');const bytes=await p.cache.materialize(ref);assert.equal(new TextDecoder().decode(bytes),'v100');});

test('Files mobile editor without CM binding uploads while initial file reflection is blocked',async t=>{
 const {p,mem,other,server}=await env(t);
 put(other.doc,'实时协作测试.md',{kind:'text',data:'base'});
 await wait(()=>content(server.doc,'实时协作测试.md')?.data==='base');
 const f=await mem.v.create('实时协作测试.md','base');
 let release,entered=false;const gate=new Promise(r=>release=r),reflect=p.reflect.bind(p);
 p.reflect=async()=>{entered=true;await gate;return reflect();};t.after(()=>release?.());
 await p.start();await wait(()=>entered&&p.syncedOnce);assert(p.initializing);
 const change=p.app.workspace.events['editor-change'];if(typeof change!=='function'){release();await p.queue;}assert.equal(typeof change,'function','mobile editor requires a public editor-change fallback');
 await mem.v.modify(f,'base 手机初始下载期间输入');
 change({getValue:()=> 'base 手机初始下载期间输入'},{file:f});
 await wait(()=>content(server.doc,f.path)?.data==='base 手机初始下载期间输入');
 release();await p.queue;assert.equal(mem.data.get(f.path),'base 手机初始下载期间输入');
});

test('Files cold update recovers an existing unsent phone text file without new input or state reset',async t=>{
 const {p,mem,server,other}=await env(t);put(other.doc,'实时协作测试.md',{kind:'text',data:'base'});
 await wait(()=>content(server.doc,'实时协作测试.md')?.data==='base');await p.start();await wait(()=>p.syncedOnce&&mem.data.get('实时协作测试.md')==='base');
 await p.stop();await p.queue;const saved=structuredClone(p.saved),id=saved.serverId;
 // A suspended old mobile plugin saved the file but missed its editor event.
 mem.data.set('实时协作测试.md','base 新版实时验证 1016');mem.files.get('实时协作测试.md').stat.size=32;
 const next=new bundle.default();next.app=p.app;await next.onload();next.settings=saved;t.after(async()=>{await next.stop();await next.queue;});
 await next.start();await wait(()=>next.syncedOnce&&content(server.doc,'实时协作测试.md')?.data==='base 新版实时验证 1016');
 assert.equal(next.settings.serverId,id);assert.equal(mem.data.get('实时协作测试.md'),'base 新版实时验证 1016');
 assert([...mem.data].some(([k,v])=>k.startsWith('.realtime-lab-v3-recovery/')&&v==='base 新版实时验证 1016'));
});

test('Files visibility resume preserves the live document and automatically sends existing offline edits',async t=>{
 const {p,mem,server,other}=await env(t);put(other.doc,'实时协作测试.md',{kind:'text',data:'base'});await wait(()=>content(server.doc,'实时协作测试.md')?.data==='base');
 await p.start();await wait(()=>p.syncedOnce&&mem.data.get('实时协作测试.md')==='base');const old=p.client.ws,doc=p.client.doc,id=p.client.serverId;
 old.send=()=>{};p.app.workspace.events['editor-change']({getValue:()=> 'base 手机已存文字'},{file:mem.files.get('实时协作测试.md')});assert.equal(content(server.doc,'实时协作测试.md').data,'base');
 p.domEvents.visibilitychange();await wait(()=>p.client.ready&&p.client.ws!==old&&content(server.doc,'实时协作测试.md')?.data==='base 手机已存文字');
 assert.equal(p.client.doc,doc);assert.equal(p.client.serverId,id);
});

test('Files failed online upload retains durable blob and visible retry path until successful retry',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.syncedOnce);const upload=p.client.blobs.upload.bind(p.client.blobs);let fail=true;p.client.blobs.upload=async(...args)=>{if(fail)throw Error('Synthetic upload interruption');return upload(...args);};
 await mem.v.createBinary('队列重试.png',new Uint8Array([21,22,23]).buffer);await p.queue;
 assert(p.fileFailures.has('队列重试.png'));assert(p.dirtyFiles.has('队列重试.png'));assert.equal(p.settings.pending.items.length,1);assert(p.pendingRows().some(r=>r.path==='队列重试.png'&&r.state==='失败，可重试'));
 fail=false;await p.retryQueue();await p.queue;await wait(()=>content(other.doc,'队列重试.png'));assert.equal(p.settings.pending.items.length,0);assert.equal(p.fileFailures.size,0);assert.equal(p.dirtyFiles.size,0);await p.client.confirmUploads();assert.equal(p.pendingRows().length,0);
});
test('Files startup honors existing auto-connect choice without resetting content or identity',async t=>{
 const {p,mem,server}=await env(t);p.settings.enabled=false;p.app.workspace.layoutReady();assert.equal(p.client,null);
 p.settings.enabled=true;p.app.workspace.layoutReady();await wait(()=>p.syncedOnce);const id=p.settings.serverId;assert.equal(id,server.serverId);assert.equal(p.settings.enabled,true);
 await mem.v.create('自动连接保留.md','content retained');await p.queue;await p.stop();assert.equal(mem.data.get('自动连接保留.md'),'content retained');assert.equal(p.settings.serverId,id);assert.equal(p.settings.enabled,true);
});

test('Files status never equates socket readiness with confirmed upload completion',async t=>{
 const {p,server}=await env(t);await p.start();await wait(()=>p.syncedOnce);await p.client.confirmUploads();assert.equal(p.summaryStatus(),'已提交服务器');
 const old=p.client.ws;old.send=()=>{};put(p.client.doc,'待确认.md',{kind:'text',data:'not acknowledged'});assert.match(p.summaryStatus(),/待上传或确认/);assert(!content(server.doc,'待确认.md'));p.fileFailures.set('失败.md','synthetic');assert.match(p.summaryStatus(),/失败项目/);
});


test('header badge follows connection and queue without duplication in reading and editing views',async t=>{
 const {JSDOM}=await import('jsdom');const dom=new JSDOM('<div class="view-header"></div>');const proto=dom.window.HTMLElement.prototype;
 proto.empty=function(){this.replaceChildren()};proto.addClass=function(...c){this.classList.add(...c)};proto.setText=function(s){this.textContent=s};proto.createSpan=function(o){const e=dom.window.document.createElement('span');e.className=o.cls;this.append(e);return e};
 const {p}=await env(t);const oldDocument=globalThis.document;globalThis.document=dom.window.document;t.after(()=>{globalThis.document=oldDocument});let opened=0;p.openSyncDetails=()=>opened++;
 const header=dom.window.document.querySelector('div'),view=new bundle.MarkdownView();view.file=new bundle.TFile('实时协作测试.md');view.addAction=(icon,title,cb)=>{const el=dom.window.document.createElement('div');el.addEventListener('click',cb);header.append(el);return el};
 view.contentEl=dom.window.document.createElement('div');header.after(view.contentEl);let leaves=[{view}];p.app.workspace.getLeavesOfType=()=>leaves;p.app.workspace.getActiveViewOfType=()=>view;
 p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-badge').length,1);assert.equal(dom.window.document.querySelector('.rl-sync-badge').dataset.tone,'offline');
 dom.window.document.body.classList.add('is-mobile');view.containerEl=dom.window.document.body;header.getBoundingClientRect=()=>({bottom:96,height:44});p.syncBadges();assert.equal(dom.window.document.querySelector('.rl-sync-row').style.top,'100px','mobile row anchored below the actual toolbar, not viewport top');
 const background=new bundle.MarkdownView();background.file=new bundle.TFile('后台.md');background.containerEl=view.containerEl;background.contentEl=dom.window.document.createElement('div');header.after(background.contentEl);leaves.push({view:background});p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-row').length,1,'background mobile tabs must not overlay the active status');
 p.app.workspace.getActiveViewOfType=()=>background;p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-row').length,1,'switching mobile tabs replaces the previous status');p.app.workspace.getActiveViewOfType=()=>null;p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-row').length,0,'no active Markdown view hides the floating status');p.app.workspace.getActiveViewOfType=()=>view;
 p.dirtyFiles.set('a.md',new bundle.TFile('a.md'));p.syncBadges();assert.match(dom.window.document.body.textContent,/↑1 ↓0/);
 p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-badge').length,1);dom.window.document.querySelector('.rl-sync-badge').dispatchEvent(new dom.window.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));assert.equal(opened,1);
 dom.window.document.querySelector('.rl-sync-row').remove();p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-badge').length,1,'recreated reading/editing header');
 p.fileFailures.set('a.md','failure');p.syncBadges();assert.equal(dom.window.document.querySelector('.rl-sync-badge').dataset.tone,'error');
 leaves=[];p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-badge').length,0);dom.window.close();
});

test('automatic reconnect drains retained dirty files and clears transient queue failures without typing',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce&&!p.initializing);
 const upload=p.client.blobs.upload.bind(p.client.blobs);let fail=true;p.client.blobs.upload=async(...args)=>{if(fail)throw new TypeError('Failed to fetch');return upload(...args)};
 await mem.v.create('自动补传.md','existing offline words');await wait(()=>p.fileFailures.has('自动补传.md'));await p.queue;assert(p.settings.pending.items.length);
 fail=false;p.client.resume();await wait(()=>p.client.ready&&!p.initializing&&content(other.doc,'自动补传.md'));await p.queue;
 assert.equal(p.dirtyFiles.size,0);assert.equal(p.fileFailures.size,0);await p.client.confirmUploads();assert.equal(p.pendingRows().length,0);
});

test('foreground recovery retries transient HTTP upload failures but leaves storage failures for explicit action',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.client?.ready&&p.syncedOnce&&!p.initializing);
 const upload=p.client.blobs.upload.bind(p.client.blobs);let fail=true;p.client.blobs.upload=async(...args)=>{if(fail)throw Error('Blob request failed (503)');return upload(...args)};
 await mem.v.create('联网自动恢复.md','no repeated typing');await wait(()=>p.fileFailures.size);await p.queue;
 fail=false;await p.recoverQueue();await wait(()=>content(other.doc,'联网自动恢复.md'));await p.queue;await p.client.confirmUploads();assert.equal(p.pendingRows().length,0);
 p.fileFailures.set('磁盘.md','Local storage quota exceeded');p.operationError='Local storage quota exceeded';let tried=false;p.retryQueue=async()=>{tried=true};await p.recoverQueue();assert.equal(tried,false);assert(p.fileFailures.has('磁盘.md'));
});


test('folder rename moves Markdown and images with recoverable old paths and no lost local updates',async t=>{
 const {p,mem,other,server}=await env(t);await p.start();await wait(()=>p.syncedOnce&&!p.initializing);
 const f=await mem.v.create('批量/笔记.md','folder text');await mem.v.createBinary('批量/图片.png',new Uint8Array([1,8,2]).buffer);await p.queue;await wait(()=>content(other.doc,'批量/图片.png'));
 await mem.v.rename({path:'批量'},'重命名');await p.queue;await wait(()=>content(other.doc,'重命名/图片.png'));
 assert.equal(content(other.doc,'批量/图片.png'),null);assert.equal(content(other.doc,'批量/笔记.md'),null);assert(content(other.doc,'重命名/笔记.md'));assert((await p.client.request('history',{path:'批量/图片.png'})).some(v=>!v.deleted));assert.equal(mem.data.get('重命名/笔记.md'),'folder text');await mem.v.trash({path:'重命名'});await p.queue;await wait(()=>content(other.doc,'重命名/图片.png')===null);assert.equal(content(other.doc,'重命名/笔记.md'),null);assert((await p.client.request('history',{path:'重命名/图片.png'})).some(v=>!v.deleted));
});
test('one failed image download does not block another file and failed local uploads are not overwritten',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.syncedOnce&&!p.initializing);
 const bad=await other.blobs.upload(bytesSource(new Uint8Array([11,12]))),good=await other.blobs.upload(bytesSource(new Uint8Array([13,14])));const download=p.client.blobs.download.bind(p.client.blobs);let fail=true;p.client.blobs.download=async(ref,...args)=>{if(fail&&ref.hash===bad.hash)throw new TypeError('Failed to fetch');return download(ref,...args)};
 await other.batchFiles(async()=>{put(other.doc,'失败.png',{kind:'image',...bad});put(other.doc,'继续.png',{kind:'image',...good});});await wait(()=>mem.files.has('继续.png'));assert(p.fileFailures.has('失败.png'));assert(!mem.files.has('失败.png'));
 fail=false;await p.retryQueue();await p.queue;assert(mem.files.has('失败.png'));assert(!p.fileFailures.has('失败.png'));
 const note=await mem.v.create('本地保留.md','original');await p.queue;const upload=p.client.blobs.upload.bind(p.client.blobs);p.client.blobs.upload=async()=>{throw new TypeError('Failed to fetch')};await mem.v.modify(note,'local unsent');await p.queue;await p.reflect();assert.equal(mem.data.get(note.path),'local unsent');assert(p.dirtyFiles.has(note.path));p.client.blobs.upload=upload;await p.retryQueue();await p.queue;assert.equal(mem.data.get(note.path),'local unsent');
});
test('history restore backs up current bytes, refuses unsent changes, and copy leaves source intact',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.syncedOnce&&!p.initializing);const f=await mem.v.create('历史恢复.md','first');await p.queue;const versions=await p.client.request('history',{path:f.path}),id=versions.find(v=>!v.deleted).id;
 await mem.v.modify(f,'second');await p.queue;await p.client.confirmUploads();const expected=content(p.client.doc,f.path);await p.restoreVersion(f.path,id,'恢复副本/历史.md',null);await wait(()=>mem.data.get('恢复副本/历史.md')==='first');assert.equal(mem.data.get(f.path),'second');
 p.dirtyFiles.set(f.path,f);await assert.rejects(p.restoreVersion(f.path,id,f.path,expected),/待传/);p.dirtyFiles.delete(f.path);await p.restoreVersion(f.path,id,f.path,expected);await wait(()=>mem.data.get(f.path)==='first');assert([...mem.data].some(([k,v])=>k.startsWith('.realtime-lab-v3-recovery/')&&v instanceof ArrayBuffer&&new TextDecoder().decode(v)==='second'));
});

test('renamed image keeps newer unsent bytes through network failure and retry without resurrecting old path',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.syncedOnce&&!p.initializing);const f=await mem.v.createBinary('原图.png',new Uint8Array([1,2]).buffer);await p.queue;const upload=p.client.blobs.upload.bind(p.client.blobs);let fail=true;p.client.blobs.upload=async(...args)=>{if(fail)throw new TypeError('Failed to fetch');return upload(...args)};
 await mem.v.modifyBinary(f,new Uint8Array([9,8,7]).buffer);await p.queue;await mem.v.rename(f,'子目录/新图.png');await p.queue;assert(p.dirtyFiles.has(f.path));await p.reflect();assert.deepEqual([...new Uint8Array(mem.data.get(f.path))],[9,8,7]);fail=false;await p.retryQueue();await p.queue;await wait(()=>content(other.doc,f.path)?.size===3);assert.equal(content(other.doc,'原图.png'),null);assert.equal(p.pendingRows().length,0);
});

test('plugin exposes conflict count, refuses decisions with pending edits, and keeps all variants as copies',async t=>{
 const {p,mem,other}=await env(t);await p.start();await wait(()=>p.syncedOnce&&!p.initializing);const f=await mem.v.create('冲突处理.md','base');await p.queue;const base=content(other.doc,f.path);await mem.v.modify(f,'Mac branch');await p.queue;await other.putFile(f.path,bytesSource(new TextEncoder().encode('offline branch')),{base});await p.queue;await p.refreshConflicts();assert.equal(p.conflicts.length,1);assert.match(p.summaryStatus(),/冲突/);assert.match(p.badgeModel().display,/冲突1/);const review=p.conflicts[0],expected=content(p.client.doc,f.path);p.dirtyFiles.set(f.path,f);await assert.rejects(p.resolveConflict(review,'keep-both',undefined,expected),/待传/);p.dirtyFiles.delete(f.path);await p.resolveConflict(review,'keep-both',undefined,expected);assert.equal(p.conflicts.length,0);assert.equal([...mem.files.keys()].filter(p=>p.startsWith('冲突副本/')).length,2);assert.equal(content(p.client.doc,f.path).hash,expected.hash);
});

test('hot update removes orphan status and unloaded callbacks cannot recreate it',async t=>{
 const {JSDOM}=await import('jsdom');const dom=new JSDOM('<div class="view-header"></div><div class="view-content"></div>');const proto=dom.window.HTMLElement.prototype;
 proto.addClass=function(...c){this.classList.add(...c)};proto.setText=function(s){this.textContent=s};proto.createSpan=function(o){const e=dom.window.document.createElement('span');e.className=o.cls;this.append(e);return e};
 const prior=globalThis.document;globalThis.document=dom.window.document;t.after(()=>{globalThis.document=prior;dom.window.close()});
 const p=new bundle.default(),view=new bundle.MarkdownView();view.file=new bundle.TFile('实时协作测试.md');view.containerEl=dom.window.document.body;view.contentEl=dom.window.document.querySelector('.view-content');dom.window.document.body.classList.add('is-mobile');dom.window.document.querySelector('.view-header').getBoundingClientRect=()=>({height:44,bottom:96});
 p.app={vault:{getName:()=> 'Realtime-Lab-V3-Files-HotUpdate'},workspace:{getLeavesOfType:()=>[{view}],getActiveViewOfType:()=>view}};
 const orphan=dom.window.document.createElement('div');orphan.className='rl-sync-row';orphan.textContent='Sync: ○ 离线';dom.window.document.body.append(orphan);
 p.syncBadges();assert.equal(dom.window.document.querySelectorAll('.rl-sync-row').length,1,'new instance removes old orphan row');
 const delayedOrphan=orphan.cloneNode(true);dom.window.document.body.append(delayedOrphan);await new Promise(r=>setTimeout(r,0));assert.equal(dom.window.document.querySelectorAll('.rl-sync-row').length,1,'late legacy row from the replaced build is removed without waiting for new sync traffic');
 p.onunload();p.setConnectionStatus('late close callback');p.updateProgress();p.renderProgress();p.syncBadges();
 await new Promise(r=>setTimeout(r,150));assert.equal(dom.window.document.querySelectorAll('.rl-sync-row').length,0,'late asynchronous callbacks cannot recreate an unloaded status');
});

test('plugin reports anonymous queue counts without paths or credentials and preserves diagnostic identity',async t=>{
 const {p,server}=await env(t),id=p.settings.deviceId;assert.match(id,/^[a-f0-9-]{36}$/);await p.start();await wait(()=>p.syncedOnce&&!p.initializing);await p.client.confirmUploads();await p.reportDiagnostic();let result=await p.client.request('device-diagnostics');const row=result.devices.find(d=>d.deviceId===id);assert(row);assert.equal(row.platform,'macos');assert.equal(row.queued,0);assert(!JSON.stringify(result).includes(p.settings.token));assert(!JSON.stringify(result).includes('实时协作测试.md'));p.dirtyFiles.set('private-name.md',new bundle.TFile('private-name.md'));await p.reportDiagnostic();result=await p.client.request('device-diagnostics');assert.equal(result.devices.find(d=>d.deviceId===id).dirty,1);assert.equal(result.devices.find(d=>d.deviceId===id).completeAtReport,false);assert(!JSON.stringify(result).includes('private-name'));p.dirtyFiles.clear();await p.persistConfig();assert.equal(p.saved.deviceId,id);assert(server.writeCount>=1);
});

test('diagnostics does not mark complete while remote contents are still being written locally',async t=>{
 const {p,other,mem}=await env(t);put(other.doc,'实时协作测试.md',{kind:'text',data:'before'});await p.start();await wait(()=>mem.data.get('实时协作测试.md')==='before'&&!p.initializing);await p.client.confirmUploads();let release,entered=false;const gate=new Promise(r=>release=r),modify=mem.v.modify;mem.v.modify=async(f,s)=>{entered=true;await gate;return modify(f,s)};t.after(()=>release());put(other.doc,'实时协作测试.md',{kind:'text',data:'after'});await wait(()=>entered);await p.reportDiagnostic();const row=(await p.client.request('device-diagnostics')).devices.find(d=>d.deviceId===p.settings.deviceId);assert(row.busy);assert.equal(row.completeAtReport,false);release();await p.queue;await wait(()=>mem.data.get('实时协作测试.md')==='after');
});
