import test from 'node:test';
import assert from 'node:assert/strict';
import {badgeState} from '../src/v3/sync-badge.mjs';
test('badge never claims confirmation merely because the queue is empty',()=>{
 assert.equal(badgeState({}).tone,'offline');assert.equal(badgeState({ready:true}).tone,'waiting');
 assert.equal(badgeState({ready:true,confirmed:true,known:7}).counts,'↑0 ↓0');
 assert.equal(badgeState({ready:true,confirmed:true,uploads:2,downloads:1}).counts,'↑2 ↓1');
 assert.equal(badgeState({ready:true,confirmed:true,unknown:true}).counts,'↑? ↓0');
 assert.equal(badgeState({ready:true,confirmed:true,error:true}).tone,'error');
 assert.match(badgeState({ready:true,confirmed:true}).description,/服务器确认不等于其他设备已收到/);
});
test('protected path review is shown as waiting for confirmation, not as active sync or a green completion',()=>{const state=badgeState({ready:true,confirmed:true,protectedCount:5});assert.equal(state.tone,'waiting');assert.match(state.display,/待确认5/);});
