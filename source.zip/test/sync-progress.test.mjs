import test from 'node:test';
import assert from 'node:assert/strict';
import * as Y from 'yjs';
import {changedPaths,queueRows} from '../src/v3/sync-progress.mjs';
import {put} from '../src/v3/model.mjs';
test('queue metadata detects inline edits and reference changes without storing file content',()=>{
 const doc=new Y.Doc(),seen=[];doc.on('afterTransaction',t=>seen.push(...changedPaths(doc,t)));
 put(doc,'实时协作测试.md',{kind:'text',data:'a'});doc.getText('text:实时协作测试.md').insert(1,'b');assert(seen.includes('实时协作测试.md'));doc.destroy();
});
test('queue view deduplicates path and prioritizes retry failure over awaiting confirmation',()=>{
 const rows=queueRows({metadata:['a.md','b.md'],files:[{path:'a.md',size:3}],dirty:['a.md'],failures:[['a.md','retry']],downloads:['c.pdf']});assert.equal(rows.length,3);assert.deepEqual(rows.find(r=>r.path==='a.md'),{path:'a.md',state:'失败，可重试',error:'retry'});
});
